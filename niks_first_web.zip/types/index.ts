/**
 * Global Type Definitions
 * Shared types across the application
 */

export interface NavItem {
  title: string;
  href: string;
  description?: string;
  disabled?: boolean;
  external?: boolean;
}

export interface SiteMetadata {
  title: string;
  description: string;
  keywords?: string[];
  ogImage?: string;
  noIndex?: boolean;
}

export interface ContactFormData {
  name: string;
  email: string;
  phone?: string;
  service?: string;
  message: string;
}

export interface Service {
  id: string;
  slug: string;
  title: string;
  description: string;
  shortDescription?: string;
  icon?: string;
  features?: string[];
  pricing?: {
    startingAt?: number;
    currency?: string;
  };
}

export interface Client {
  id: string;
  name: string;
  email: string;
  phone?: string;
  company?: string;
  status: "active" | "inactive" | "prospect";
  createdAt: Date;
  updatedAt: Date;
}

export interface Project {
  id: string;
  clientId: string;
  title: string;
  description: string;
  status: "planning" | "in-progress" | "completed" | "on-hold";
  startDate?: Date;
  endDate?: Date;
  createdAt: Date;
  updatedAt: Date;
}

