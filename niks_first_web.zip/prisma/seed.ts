/**
 * Prisma Seed File
 * Creates initial admin user and sample data
 */

import { PrismaClient, UserRole, ContentStatus } from "@prisma/client";
import * as bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding database...");

  // Create admin user
  const hashedPassword = await bcrypt.hash("admin123", 10);

  const admin = await prisma.user.upsert({
    where: { email: "admin@moonrockfintax.com" },
    update: {},
    create: {
      email: "admin@moonrockfintax.com",
      name: "Admin User",
      password: hashedPassword,
      role: UserRole.SUPER_ADMIN,
      status: "ACTIVE",
    },
  });

  console.log("✅ Created admin user:", admin.email);

  // Create sample services
  const services = await Promise.all([
    prisma.service.upsert({
      where: { slug: "tax-planning" },
      update: {},
      create: {
        title: "Tax Planning & Preparation",
        slug: "tax-planning",
        shortDescription: "Strategic tax planning to minimize liabilities and maximize savings",
        description: "Comprehensive tax planning and preparation services for individuals and businesses.",
        category: "Tax Services",
        featured: true,
        order: 1,
        status: ContentStatus.PUBLISHED,
        publishedAt: new Date(),
        authorId: admin.id,
        metaTitle: "Tax Planning & Preparation Services | Moonrock Fintax",
        metaDescription: "Expert tax planning and preparation services to minimize your tax burden and maximize savings.",
      },
    }),
    prisma.service.upsert({
      where: { slug: "financial-consulting" },
      update: {},
      create: {
        title: "Financial Consulting",
        slug: "financial-consulting",
        shortDescription: "Comprehensive financial analysis and strategic planning",
        description: "Expert financial consulting services to help you make informed decisions.",
        category: "Financial Services",
        featured: true,
        order: 2,
        status: ContentStatus.PUBLISHED,
        publishedAt: new Date(),
        authorId: admin.id,
        metaTitle: "Financial Consulting Services | Moonrock Fintax",
        metaDescription: "Professional financial consulting to optimize your financial performance.",
      },
    }),
  ]);

  console.log("✅ Created services:", services.length);

  // Create sample page
  const aboutPage = await prisma.page.upsert({
    where: { slug: "about" },
    update: {},
    create: {
      title: "About Us",
      slug: "about",
      content: "About page content goes here...",
      excerpt: "Learn about Moonrock Fintax Consulting",
      status: ContentStatus.PUBLISHED,
      publishedAt: new Date(),
      authorId: admin.id,
      metaTitle: "About Us | Moonrock Fintax Consulting",
      metaDescription: "Learn about Moonrock Fintax Consulting and our team of financial experts.",
    },
  });

  console.log("✅ Created about page");

  // Create sample testimonial
  const testimonial = await prisma.testimonial.create({
    data: {
      quote: "Moonrock Fintax helped us save thousands on our taxes. Highly recommended!",
      authorName: "John Smith",
      authorTitle: "CEO",
      companyName: "Tech Corp",
      rating: 5,
      featured: true,
      status: ContentStatus.PUBLISHED,
      publishedAt: new Date(),
      authorId: admin.id,
    },
  });

  console.log("✅ Created testimonial");

  console.log("🎉 Seeding completed!");
}

main()
  .catch((e) => {
    console.error("❌ Seeding failed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

