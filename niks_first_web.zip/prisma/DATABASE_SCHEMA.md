# Moonrock Fintax Consulting - Database Schema Documentation

## Overview

Production-ready Prisma schema with NextAuth integration, comprehensive SEO fields, and Role-Based Access Control (RBAC).

## Models

### 1. User (Admin)
**Purpose**: Admin users with authentication and authorization

**Key Fields**:
- `id`: Unique identifier (CUID)
- `email`: Unique email (used for login)
- `password`: Hashed password (for credentials provider)
- `role`: RBAC role (SUPER_ADMIN, ADMIN, EDITOR, VIEWER)
- `status`: User status (ACTIVE, INACTIVE, SUSPENDED)

**NextAuth Integration**:
- `accounts`: OAuth accounts (Google, GitHub, etc.)
- `sessions`: Active sessions
- `emailVerified`: Email verification timestamp

**Relations**:
- Owns: Pages, Services, Blogs, CaseStudies, Testimonials (author)
- Has: Accounts, Sessions (NextAuth)

---

### 2. Page
**Purpose**: Static pages (About, Contact, custom pages)

**Key Fields**:
- `slug`: URL-friendly identifier (unique)
- `content`: Full page content (rich text)
- `status`: DRAFT, PUBLISHED, ARCHIVED
- `publishedAt`: Publication timestamp

**SEO Fields**:
- `metaTitle`, `metaDescription`, `metaKeywords`
- `ogTitle`, `ogDescription`, `ogImage`
- `canonicalUrl`

**Relations**:
- Belongs to: User (author)
- Has: Media (featured image, media collection)

---

### 3. Service
**Purpose**: Service offerings (Tax Planning, Financial Consulting, etc.)

**Key Fields**:
- `slug`: URL-friendly identifier (unique)
- `shortDescription`: Brief description for listings
- `description`: Full service description
- `icon`: Icon identifier
- `featured`: Featured service flag
- `order`: Custom ordering for display
- `startingPrice`: Optional pricing

**SEO Fields**: Same as Page

**Relations**:
- Belongs to: User (author)
- Has: Media (featured image, media collection)
- Has: CaseStudies (related case studies)
- Has: Testimonials (service-specific testimonials)

---

### 4. Blog
**Purpose**: Blog posts and articles

**Key Fields**:
- `slug`: URL-friendly identifier (unique)
- `excerpt`: Short excerpt for listings
- `content`: Full blog content
- `category`: Blog category
- `tags`: Array of tags
- `readTime`: Estimated reading time (minutes)
- `viewCount`: Analytics tracking

**SEO Fields**: Same as Page

**Relations**:
- Belongs to: User (author)
- Has: Media (featured image, media collection)

---

### 5. CaseStudy
**Purpose**: Client success stories and case studies

**Key Fields**:
- `slug`: URL-friendly identifier (unique)
- `clientName`: Client name (optional for privacy)
- `clientIndustry`: Industry sector
- `challenge`: Problem statement
- `solution`: Solution provided
- `results`: Results achieved
- `metrics`: Flexible JSON for custom metrics

**SEO Fields**: Same as Page

**Relations**:
- Belongs to: User (author)
- Belongs to: Service (optional - related service)
- Has: Media (featured image, media collection)

---

### 6. Testimonial
**Purpose**: Client testimonials and reviews

**Key Fields**:
- `quote`: Testimonial text
- `authorName`: Client name
- `authorTitle`: Job title/role
- `companyName`: Company name
- `rating`: 1-5 star rating (optional)
- `featured`: Featured testimonial flag

**SEO Fields**: Basic SEO (for testimonial pages)

**Relations**:
- Belongs to: User (author)
- Belongs to: Service (optional - service-specific)
- Has: Media (author image)

---

### 7. Media
**Purpose**: Media library (images, videos, documents)

**Key Fields**:
- `filename`: Stored filename
- `originalName`: Original upload name
- `mimeType`: MIME type
- `size`: File size (bytes)
- `type`: IMAGE, VIDEO, DOCUMENT, AUDIO
- `url`: Full URL to file
- `width`, `height`: Dimensions (for images/videos)
- `alt`: Alt text (for images)

**Relations**:
- Featured in: All content types (one-to-many)
- Included in: All content types (many-to-many collections)

---

## Relations Explained

### User → Content (One-to-Many)
- Each content item has one author (User)
- Users can create multiple content items
- Used for: ownership, audit trail, permissions

### Content → Media (Many-to-One for Featured)
- Each content item can have one featured image
- Media can be featured in multiple content items
- Used for: featured images, thumbnails

### Content → Media (Many-to-Many for Collections)
- Content items can have multiple media items
- Media items can belong to multiple content items
- Used for: galleries, document attachments

### Service → CaseStudy (One-to-Many)
- Services can have multiple related case studies
- Case studies can optionally belong to a service
- Used for: showcasing service results

### Service → Testimonial (One-to-Many)
- Services can have multiple testimonials
- Testimonials can optionally be service-specific
- Used for: service-specific social proof

---

## NextAuth Strategy

### Supported Providers

1. **Credentials Provider** (Email/Password)
   - Uses `User.password` (hashed with bcrypt)
   - Email + password authentication
   - Session stored in `Session` table

2. **OAuth Providers** (Google, GitHub, etc.)
   - Uses `Account` table
   - Links OAuth accounts to User
   - Session stored in `Session` table

### Authentication Flow

```
1. User submits credentials
2. NextAuth validates:
   - Credentials: Check email + hashed password
   - OAuth: Verify OAuth token, find/create Account
3. Create/Update Session in database
4. Return session token to client
5. Middleware checks session for protected routes
```

### Session Management

- Sessions stored in `Session` table
- Automatic expiration handling
- Cascade delete on user deletion
- Session token is unique and secure

---

## RBAC (Role-Based Access Control)

### Roles

1. **SUPER_ADMIN**
   - Full system access
   - User management
   - System settings
   - All content CRUD

2. **ADMIN**
   - Content management (all types)
   - Media management
   - Can publish content
   - Cannot manage users

3. **EDITOR**
   - Create and edit content
   - Can save drafts
   - Cannot publish (requires approval)
   - Limited media access

4. **VIEWER**
   - Read-only access
   - View drafts and published content
   - Cannot create/edit

### Permission Checks

```typescript
// Example permission check
const canPublish = user.role === 'SUPER_ADMIN' || user.role === 'ADMIN';
const canEdit = ['SUPER_ADMIN', 'ADMIN', 'EDITOR'].includes(user.role);
const canView = true; // All authenticated users
```

### Implementation Notes

- Role stored in `User.role` field
- Check role in API routes and server actions
- Middleware can enforce role-based route access
- UI can conditionally show/hide based on role

---

## Data Flow

### Content Creation Flow

```
1. User (Editor/Admin) creates content
   ↓
2. Content saved with status: DRAFT
   ↓
3. Author assigned (current user)
4. SEO fields populated
5. Media attached (if any)
   ↓
6. Admin reviews and publishes
   ↓
7. Status changed to PUBLISHED
8. publishedAt timestamp set
   ↓
9. Content visible on public site
```

### Content Publishing Flow

```
1. Editor creates content → DRAFT
2. Editor requests review (optional workflow)
3. Admin reviews content
4. Admin publishes → PUBLISHED
5. Content appears on public site
6. SEO metadata used for search engines
```

### Media Upload Flow

```
1. User uploads file
2. File stored (local/S3/Cloudinary)
3. Media record created in database
4. Metadata extracted (dimensions, size, etc.)
5. Thumbnail generated (if image/video)
6. Media available in library
7. Can be attached to content
```

### Authentication Flow

```
1. User visits /admin/login
2. Submits credentials
3. NextAuth validates:
   - Check User.email
   - Verify password hash
4. Create Session record
5. Set session cookie
6. Redirect to /dashboard
7. Middleware checks session on each request
```

---

## SEO Strategy

### SEO Fields in All Content Models

- **metaTitle**: Page title (50-60 chars)
- **metaDescription**: Meta description (150-160 chars)
- **metaKeywords**: Array of keywords
- **ogTitle**: Open Graph title
- **ogDescription**: Open Graph description
- **ogImage**: Social sharing image
- **canonicalUrl**: Canonical URL for duplicate content

### Implementation

```typescript
// Example: Generate SEO metadata
const seoMetadata = {
  title: page.metaTitle || page.title,
  description: page.metaDescription || page.excerpt,
  keywords: page.metaKeywords,
  openGraph: {
    title: page.ogTitle || page.title,
    description: page.ogDescription || page.excerpt,
    images: page.ogImage ? [page.ogImage] : [],
  },
  alternates: {
    canonical: page.canonicalUrl || `${siteConfig.url}/${page.slug}`,
  },
};
```

---

## Indexes

All models include strategic indexes for:
- **Slugs**: Fast URL lookups
- **Status**: Filter published content
- **Author**: Find user's content
- **PublishedAt**: Sort by publication date
- **Featured**: Quick featured content queries

---

## Migration Strategy

1. **Initial Setup**:
   ```bash
   npx prisma migrate dev --name init
   ```

2. **Seed Database**:
   ```bash
   npx prisma db seed
   ```

3. **Production**:
   ```bash
   npx prisma migrate deploy
   ```

---

## Environment Variables

```env
DATABASE_URL="postgresql://user:password@localhost:5432/moonrock_fintax"
NEXTAUTH_SECRET="your-secret-key-here"
NEXTAUTH_URL="http://localhost:3000"
```

---

## Next Steps

1. Run migrations: `npx prisma migrate dev`
2. Generate Prisma Client: `npx prisma generate`
3. Create seed file for initial admin user
4. Set up NextAuth configuration
5. Implement RBAC middleware
6. Create API routes for content management

