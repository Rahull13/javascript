# Data Flow Documentation - Moonrock Fintax Consulting

## Overview

This document explains the data flow patterns for the Moonrock Fintax Consulting application, covering content management, authentication, and media handling.

---

## 1. Content Creation & Publishing Flow

### Draft Creation
```
User (Editor/Admin) → Creates Content
  ↓
Content saved with:
  - status: DRAFT
  - authorId: current user
  - createdAt: now()
  - publishedAt: null
  ↓
Content stored in database
  ↓
Visible only to:
  - Author
  - Admins
  - Editors (if permission allows)
```

### Publishing Workflow
```
Draft Content → Admin Review
  ↓
Admin approves/edits
  ↓
Status changed: DRAFT → PUBLISHED
  ↓
publishedAt: set to current timestamp
  ↓
Content becomes:
  - Visible on public site
  - Indexed by search engines
  - Accessible via slug URL
```

### Content Update Flow
```
Published Content → Editor updates
  ↓
New version saved
  ↓
updatedAt: updated
  ↓
If major changes:
  - Can revert to DRAFT
  - Requires re-approval
  ↓
If minor changes:
  - Remains PUBLISHED
  - Changes go live immediately
```

---

## 2. Authentication & Authorization Flow

### Login Flow (Credentials)
```
User visits /admin/login
  ↓
Submits: email + password
  ↓
NextAuth validates:
  1. Find User by email
  2. Verify password hash (bcrypt)
  3. Check user.status === ACTIVE
  ↓
If valid:
  - Create Session record
  - Generate sessionToken
  - Set HTTP-only cookie
  - Redirect to /dashboard
  ↓
If invalid:
  - Return error
  - Stay on login page
```

### OAuth Flow (Google/GitHub)
```
User clicks "Sign in with Google"
  ↓
Redirected to OAuth provider
  ↓
User authorizes application
  ↓
OAuth provider redirects back with code
  ↓
NextAuth exchanges code for tokens
  ↓
Find or create Account record
  ↓
Link Account to User (or create new User)
  ↓
Create Session
  ↓
Redirect to /dashboard
```

### Session Validation (Middleware)
```
Request to protected route
  ↓
Middleware checks:
  1. Extract sessionToken from cookie
  2. Find Session in database
  3. Verify session.expires > now()
  4. Load User from session.userId
  5. Check user.status === ACTIVE
  ↓
If valid:
  - Attach user to request
  - Allow access
  ↓
If invalid:
  - Clear cookie
  - Redirect to /admin/login
```

### Role-Based Access Control
```
User makes request
  ↓
Middleware loads user.role
  ↓
Check permissions:
  - SUPER_ADMIN: Full access
  - ADMIN: Content + media management
  - EDITOR: Create/edit content (no publish)
  - VIEWER: Read-only
  ↓
If authorized:
  - Process request
  ↓
If unauthorized:
  - Return 403 Forbidden
```

---

## 3. Media Management Flow

### Upload Flow
```
User uploads file
  ↓
File validation:
  - Check file type
  - Check file size
  - Verify MIME type
  ↓
File storage:
  - Save to storage (local/S3/Cloudinary)
  - Generate unique filename
  - Create thumbnail (if image/video)
  ↓
Create Media record:
  - Store metadata
  - Store file URL
  - Extract dimensions (if applicable)
  ↓
Media available in library
  ↓
Can be attached to content
```

### Media Attachment Flow
```
User creates/edits content
  ↓
Selects media from library
  ↓
For featured image:
  - Set content.featuredImageId
  - One-to-one relationship
  ↓
For media collection:
  - Add to content.media array
  - Many-to-many relationship
  ↓
Content saved with media references
  ↓
Media accessible via content
```

### Media Deletion Flow
```
User deletes media
  ↓
Check media usage:
  - Query all content using this media
  - Check featured images
  - Check media collections
  ↓
If in use:
  - Prevent deletion
  - Show warning with usage list
  ↓
If not in use:
  - Delete file from storage
  - Delete Media record
  - Cascade handled by Prisma
```

---

## 4. SEO Data Flow

### SEO Metadata Generation
```
Content created/updated
  ↓
SEO fields populated:
  - metaTitle (or auto-generated from title)
  - metaDescription (or from excerpt)
  - metaKeywords (array)
  - ogTitle (or use metaTitle)
  - ogDescription (or use metaDescription)
  - ogImage (from featuredImage)
  - canonicalUrl (auto-generated from slug)
  ↓
Metadata stored in database
  ↓
Used in:
  - Page metadata (Next.js Metadata API)
  - Sitemap generation
  - Open Graph tags
  - Twitter Cards
```

### Sitemap Generation Flow
```
Sitemap request (/sitemap.xml)
  ↓
Query all published content:
  - Pages (status: PUBLISHED)
  - Services (status: PUBLISHED)
  - Blogs (status: PUBLISHED)
  - CaseStudies (status: PUBLISHED)
  ↓
Generate sitemap entries:
  - URL: canonicalUrl or slug
  - lastModified: updatedAt
  - changeFrequency: based on content type
  - priority: based on featured/importance
  ↓
Return XML sitemap
  ↓
Search engines crawl sitemap
```

---

## 5. Service → Case Study Relationship

### Linking Case Study to Service
```
Admin creates CaseStudy
  ↓
Optionally selects related Service
  ↓
Set caseStudy.serviceId
  ↓
CaseStudy appears in:
  - Service detail page (related case studies)
  - Case study listing (filtered by service)
  ↓
Bidirectional relationship:
  - Service.caseStudies (all related)
  - CaseStudy.service (parent service)
```

### Service Testimonials
```
Testimonial created
  ↓
Optionally linked to Service
  ↓
Set testimonial.serviceId
  ↓
Testimonial appears:
  - On service detail page
  - In service-specific testimonial section
  - Can also be general (serviceId: null)
```

---

## 6. Content Query Patterns

### Public Content Queries
```typescript
// Get published content only
const publishedContent = await prisma.page.findMany({
  where: {
    status: 'PUBLISHED',
    publishedAt: { lte: new Date() }
  },
  orderBy: { publishedAt: 'desc' }
});
```

### Admin Content Queries
```typescript
// Get all content (including drafts) for admin
const allContent = await prisma.page.findMany({
  where: {
    OR: [
      { authorId: currentUser.id }, // User's own content
      { status: 'PUBLISHED' }    // Published content
    ]
  },
  include: {
    author: true,
    featuredImage: true
  }
});
```

### Featured Content Queries
```typescript
// Get featured content for homepage
const featured = await prisma.service.findMany({
  where: {
    status: 'PUBLISHED',
    featured: true
  },
  orderBy: { order: 'asc' },
  take: 6
});
```

---

## 7. Search & Filtering Flow

### Content Search
```
User searches for content
  ↓
Query database:
  - Search in: title, content, excerpt
  - Filter by: status (PUBLISHED only)
  - Filter by: publishedAt (past dates only)
  ↓
Return results with:
  - Relevance ranking
  - Snippet preview
  - Metadata
  ↓
Display results
```

### Content Filtering
```
User filters content
  ↓
Apply filters:
  - By category (services, blogs)
  - By author
  - By date range
  - By tags (blogs)
  ↓
Query with filters
  ↓
Return filtered results
  ↓
Paginate results
```

---

## 8. Analytics & Tracking

### View Count Tracking
```
User views blog post
  ↓
Increment blog.viewCount
  ↓
Update database:
  - Atomic increment
  - No need to reload full record
  ↓
Track for analytics:
  - Popular content
  - Engagement metrics
```

### Content Performance
```
Track metrics:
  - View counts
  - Time on page
  - Conversion events
  ↓
Store in analytics system
  ↓
Display in admin dashboard:
  - Top performing content
  - Engagement trends
  - Conversion rates
```

---

## 9. Data Integrity Patterns

### Slug Uniqueness
```
Content created with slug
  ↓
Check slug uniqueness:
  - Query existing content with same slug
  - If exists: append number or suggest alternative
  ↓
Ensure unique slug before save
  ↓
Slug used in URL generation
```

### Cascade Deletes
```
User deleted
  ↓
Prisma handles:
  - User.accounts (cascade delete)
  - User.sessions (cascade delete)
  - User content (authorId set to null or prevent delete)
  ↓
Media deleted
  ↓
Prisma handles:
  - Featured image relations (set to null)
  - Media collection relations (remove from arrays)
```

### Soft Deletes (Status-based)
```
Content archived instead of deleted
  ↓
Status changed to: ARCHIVED
  ↓
Content:
  - Not visible on public site
  - Still in database
  - Can be restored
  - Can be permanently deleted later
```

---

## 10. API Request Flow

### Content API Flow
```
Client → API Route (/api/pages)
  ↓
Middleware:
  - Authenticate user
  - Check permissions
  ↓
Server Action:
  - Validate input
  - Check user role
  - Perform operation
  ↓
Database Operation:
  - Create/Read/Update/Delete
  - Handle relations
  ↓
Return Response:
  - Success with data
  - Error with message
  ↓
Client updates UI
```

### File Upload Flow
```
Client uploads file
  ↓
API Route receives file
  ↓
Validate file:
  - Type, size, format
  ↓
Upload to storage:
  - Generate unique name
  - Save file
  - Generate thumbnail
  ↓
Create Media record
  ↓
Return media data
  ↓
Client can attach to content
```

---

## Summary

The data flow follows these principles:

1. **Separation of Concerns**: Content, auth, and media are separate domains
2. **Status-Based Publishing**: Draft → Published workflow
3. **Role-Based Access**: Permissions based on user role
4. **SEO-First**: All content includes comprehensive SEO fields
5. **Media Management**: Centralized media library with flexible attachments
6. **Audit Trail**: All content tracks author and timestamps
7. **Type Safety**: Prisma ensures type-safe database operations

This architecture supports:
- Scalable content management
- Multi-user collaboration
- SEO optimization
- Media organization
- Role-based permissions
- Analytics tracking

