import mongoose, { Schema, model, models, Document } from "mongoose";

/* ─── Shared SEO sub-schema ─── */
const SeoSchema = new Schema(
  {
    title: { type: String, trim: true, maxlength: 60 },
    description: { type: String, trim: true, maxlength: 160 },
    keywords: { type: [String], default: [] },
    ogImage: { type: String, trim: true },
  },
  { _id: false },
);

export interface ISeo {
  title?: string;
  description?: string;
  keywords: string[];
  ogImage?: string;
}

export interface IService extends Document {
  title: string;
  slug: string;
  category: "Digital Marketing" | "Digital Transformation";
  summary: string;
  shortDescription: string; // alias for summary
  content: string;
  seo: ISeo;
  // Legacy flat SEO fields (kept for backward compatibility)
  metaTitle?: string;
  metaDescription?: string;
  keywords: string[];
  status: "draft" | "published";
  imageUrl?: string;
  imagePublicId?: string;
  imageAlt?: string;
  ogImage?: string;
  createdAt: Date;
  updatedAt: Date;
}

const ServiceSchema = new Schema<IService>(
  {
    title: {
      type: String,
      required: true,
      trim: true,
    },
    slug: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    category: {
      type: String,
      enum: ["Digital Marketing", "Digital Transformation"],
      default: "Digital Marketing",
    },
    summary: {
      type: String,
      required: true,
      trim: true,
    },
    content: {
      type: String,
      required: true,
    },
    seo: {
      type: SeoSchema,
      default: () => ({}),
    },
    // Legacy flat SEO fields (backward compatibility with existing admin forms)
    metaTitle: {
      type: String,
      trim: true,
    },
    metaDescription: {
      type: String,
      trim: true,
    },
    keywords: {
      type: [String],
      default: [],
    },
    status: {
      type: String,
      enum: ["draft", "published"],
      default: "draft",
    },
    imageUrl: {
      type: String,
      trim: true,
    },
    imagePublicId: {
      type: String,
      trim: true,
    },
    imageAlt: {
      type: String,
      trim: true,
    },
    ogImage: {
      type: String,
      trim: true,
    },
  },
  {
    timestamps: true,
  },
);

// Virtual: shortDescription is an alias for summary
ServiceSchema.virtual("shortDescription").get(function () {
  return this.summary;
});

ServiceSchema.index({ slug: 1 });
ServiceSchema.index({ status: 1 });
ServiceSchema.index({ category: 1 });

const Service = models.Service || model<IService>("Service", ServiceSchema);

export default Service;
