import mongoose, { Schema, model, models, Document } from "mongoose";

/* ─── Shared SEO sub-schema ─── */
const SeoSchema = new Schema(
  {
    title: { type: String, trim: true, maxlength: 60 },
    description: { type: String, trim: true, maxlength: 160 },
    keywords: { type: [String], default: [] },
    ogImage: { type: String, trim: true },
  },
  { _id: false },
);

export interface ISeo {
  title?: string;
  description?: string;
  keywords: string[];
  ogImage?: string;
}

export interface IPage extends Document {
  title: string;
  slug: string;
  content: string;
  sections: Record<string, unknown>; // Flexible JSON for page sections
  seo: ISeo;
  // Legacy flat SEO fields (kept for backward compatibility)
  metaTitle?: string;
  metaDescription?: string;
  keywords: string[];
  status: "draft" | "published";
  createdAt: Date;
  updatedAt: Date;
}

const PageSchema = new Schema<IPage>(
  {
    title: {
      type: String,
      required: true,
      trim: true,
    },
    slug: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    content: {
      type: String,
      default: "",
    },
    sections: {
      type: Schema.Types.Mixed,
      default: {},
    },
    seo: {
      type: SeoSchema,
      default: () => ({}),
    },
    // Legacy flat SEO fields (backward compatibility with existing admin forms)
    metaTitle: {
      type: String,
      trim: true,
    },
    metaDescription: {
      type: String,
      trim: true,
    },
    keywords: {
      type: [String],
      default: [],
    },
    status: {
      type: String,
      enum: ["draft", "published"],
      default: "draft",
    },
  },
  {
    timestamps: true,
  },
);

PageSchema.index({ slug: 1 });
PageSchema.index({ status: 1 });

const Page = models.Page || model<IPage>("Page", PageSchema);

export default Page;
