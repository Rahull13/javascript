import mongoose, { Schema, model, models, Document } from "mongoose";

/* ─── Shared SEO sub-schema ─── */
const SeoSchema = new Schema(
  {
    title: { type: String, trim: true, maxlength: 60 },
    description: { type: String, trim: true, maxlength: 160 },
    keywords: { type: [String], default: [] },
    ogImage: { type: String, trim: true },
  },
  { _id: false },
);

/* ─── Image sub-schema for portfolio gallery ─── */
const PortfolioImageSchema = new Schema(
  {
    url: { type: String, required: true, trim: true },
    publicId: { type: String, trim: true },
    alt: { type: String, trim: true, default: "" },
  },
  { _id: false },
);

export interface ISeo {
  title?: string;
  description?: string;
  keywords: string[];
  ogImage?: string;
}

export interface IPortfolioImage {
  url: string;
  publicId?: string;
  alt?: string;
}

export interface IPortfolio extends Document {
  title: string;
  slug: string;
  description: string;
  images: IPortfolioImage[];
  client: string;
  industry: string;
  seo: ISeo;
  status: "draft" | "published";
  createdAt: Date;
  updatedAt: Date;
}

const PortfolioSchema = new Schema<IPortfolio>(
  {
    title: {
      type: String,
      required: true,
      trim: true,
    },
    slug: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    description: {
      type: String,
      default: "",
    },
    images: {
      type: [PortfolioImageSchema],
      default: [],
    },
    client: {
      type: String,
      trim: true,
      default: "",
    },
    industry: {
      type: String,
      trim: true,
      default: "",
    },
    seo: {
      type: SeoSchema,
      default: () => ({}),
    },
    status: {
      type: String,
      enum: ["draft", "published"],
      default: "draft",
    },
  },
  {
    timestamps: true,
  },
);

PortfolioSchema.index({ slug: 1 });
PortfolioSchema.index({ status: 1 });
PortfolioSchema.index({ industry: 1 });

const Portfolio =
  models.Portfolio || model<IPortfolio>("Portfolio", PortfolioSchema);

export default Portfolio;

