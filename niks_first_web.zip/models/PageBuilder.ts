import mongoose, { Schema, model, models, Document } from "mongoose";

export interface IPageSection {
  id: string;
  type: string;
  order: number;
  enabled: boolean;
  data: Record<string, any>;
}

export interface IPageBuilder extends Document {
  page: string; // e.g. "home", "about"
  sections: IPageSection[];
  createdAt: Date;
  updatedAt: Date;
}

const PageSectionSchema = new Schema<IPageSection>(
  {
    id: { type: String, required: true, trim: true },
    type: { type: String, required: true, trim: true },
    order: { type: Number, required: true },
    enabled: { type: Boolean, default: true },
    data: { type: Schema.Types.Mixed, default: {} },
  },
  { _id: false },
);

const PageBuilderSchema = new Schema<IPageBuilder>(
  {
    page: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
    },
    sections: {
      type: [PageSectionSchema],
      default: [],
    },
  },
  {
    timestamps: true,
  },
);

PageBuilderSchema.index({ page: 1 });

const PageBuilder =
  models.PageBuilder || model<IPageBuilder>("PageBuilder", PageBuilderSchema);

export default PageBuilder;

