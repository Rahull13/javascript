import mongoose, { Schema, model, models, Document } from "mongoose";

/* ─── Shared SEO sub-schema ─── */
const SeoSchema = new Schema(
  {
    title: { type: String, trim: true, maxlength: 60 },
    description: { type: String, trim: true, maxlength: 160 },
    keywords: { type: [String], default: [] },
    ogImage: { type: String, trim: true },
  },
  { _id: false },
);

export interface ISeo {
  title?: string;
  description?: string;
  keywords: string[];
  ogImage?: string;
}

export interface IBlog extends Document {
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  author: string;
  publishedAt?: Date;
  seo: ISeo;
  // Legacy flat SEO fields (kept for backward compatibility)
  metaTitle?: string;
  metaDescription?: string;
  keywords: string[];
  status: "draft" | "published";
  imageUrl?: string;
  imagePublicId?: string;
  imageAlt?: string;
  ogImage?: string;
  createdAt: Date;
  updatedAt: Date;
}

const BlogSchema = new Schema<IBlog>(
  {
    title: {
      type: String,
      required: true,
      trim: true,
    },
    slug: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    excerpt: {
      type: String,
      trim: true,
      default: "",
    },
    content: {
      type: String,
      required: true,
    },
    author: {
      type: String,
      trim: true,
      default: "",
    },
    publishedAt: {
      type: Date,
    },
    seo: {
      type: SeoSchema,
      default: () => ({}),
    },
    // Legacy flat SEO fields (backward compatibility with existing admin forms)
    metaTitle: {
      type: String,
      trim: true,
    },
    metaDescription: {
      type: String,
      trim: true,
    },
    keywords: {
      type: [String],
      default: [],
    },
    status: {
      type: String,
      enum: ["draft", "published"],
      default: "draft",
    },
    imageUrl: {
      type: String,
      trim: true,
    },
    imagePublicId: {
      type: String,
      trim: true,
    },
    imageAlt: {
      type: String,
      trim: true,
    },
    ogImage: {
      type: String,
      trim: true,
    },
  },
  {
    timestamps: true,
  },
);

BlogSchema.index({ slug: 1 });
BlogSchema.index({ status: 1 });
BlogSchema.index({ publishedAt: -1 });
BlogSchema.index({ author: 1 });

const Blog = models.Blog || model<IBlog>("Blog", BlogSchema);

export default Blog;
