import "dotenv/config";
import mongoose from "mongoose";
import User from "../models/User";
import bcrypt from "bcryptjs";

async function testLogin() {
  try {
    const MONGODB_URI = process.env.MONGODB_URI;
    if (!MONGODB_URI) {
      throw new Error("MONGODB_URI environment variable is not set");
    }

    // Connect to MongoDB
    if (Number(mongoose.connection.readyState) === 0) {
      await mongoose.connect(MONGODB_URI, {
        bufferCommands: false,
        serverSelectionTimeoutMS: 5000,
      });
    }

    const email = "admin@moonrockfintax.com";
    const password = "Admin@123";

    console.log("\n🔍 Testing login credentials...\n");

    // Find user
    const user = await User.findOne({ email: email.toLowerCase().trim() });
    
    if (!user) {
      console.log("❌ User not found in database!");
      console.log(`   Searched for: ${email.toLowerCase().trim()}`);
      console.log("\n💡 Run: npx tsx scripts/create-admin.ts\n");
      await mongoose.connection.close();
      process.exit(1);
    }

    console.log("✅ User found:");
    console.log(`   Email: ${user.email}`);
    console.log(`   Role: ${user.role}`);
    console.log(`   Name: ${user.name || "N/A"}`);
    console.log(`   Password hash: ${user.password.substring(0, 20)}...`);

    // Test password comparison
    console.log("\n🔐 Testing password comparison...");
    const isValid = await user.comparePassword(password);
    
    if (isValid) {
      console.log("✅ Password is VALID!");
    } else {
      console.log("❌ Password is INVALID!");
      console.log("\n💡 The password in database doesn't match 'Admin@123'");
      console.log("   You may need to recreate the admin user.\n");
    }

    // Also test direct bcrypt comparison
    console.log("\n🔐 Testing direct bcrypt comparison...");
    const directCompare = await bcrypt.compare(password, user.password);
    console.log(`   Direct bcrypt.compare result: ${directCompare ? "✅ VALID" : "❌ INVALID"}`);

    await mongoose.connection.close();
    process.exit(isValid ? 0 : 1);
  } catch (error: any) {
    console.error("❌ Error:", error.message);
    if (mongoose.connection.readyState !== 0) {
      await mongoose.connection.close().catch(() => {});
    }
    process.exit(1);
  }
}

testLogin();

