import "dotenv/config";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";

async function createAdminUser() {
  try {
    const MONGODB_URI = process.env.MONGODB_URI;
    if (!MONGODB_URI) {
      throw new Error("MONGODB_URI environment variable is not set");
    }

    // Connect to MongoDB - handle database case warnings gracefully
    // readyState: 0 = disconnected, 1 = connected, 2 = connecting, 3 = disconnecting
    if (Number(mongoose.connection.readyState) === 0) {
      try {
        await mongoose.connect(MONGODB_URI, {
          bufferCommands: false,
          serverSelectionTimeoutMS: 5000,
        });
      } catch (connectError: any) {
        // If it's a database case error, check if connection actually worked
        if (connectError.message && connectError.message.includes("already exists with different case")) {
          // Wait a moment and check if connection is actually established
          await new Promise(resolve => setTimeout(resolve, 500));
          if (Number(mongoose.connection.readyState) === 1) {
            // Connection is actually working, just a case warning
            console.log("Connected to MongoDB (database case warning ignored)");
          } else {
            throw connectError;
          }
        } else {
          throw connectError;
        }
      }
    }

    if (Number(mongoose.connection.readyState) !== 1) {
      throw new Error("Failed to establish MongoDB connection");
    }

    console.log("Connected to MongoDB");

    const email = "admin@moonrockfintax.com";
    const password = "Admin@123";

    // Get database name from connection string
    const dbNameMatch = MONGODB_URI.match(/\/([^/?]+)(\?|$)/);
    let dbName = dbNameMatch ? dbNameMatch[1] : "moonrock-fintax";

    // If error mentions "Dashboard", use that exact name
    // MongoDB is case-sensitive for database names
    if (dbName.toLowerCase() === "dashboard") {
      dbName = "Dashboard"; // Use the exact case that exists
    }

    // Use the client directly to avoid database name case issues
    const client = mongoose.connection.getClient();
    const db = client.db(dbName);
    const usersCollection = db.collection("users");

    // Check if admin user already exists
    const existingAdmin = await usersCollection.findOne({ email: email.toLowerCase().trim() });
    if (existingAdmin) {
      console.log("\n⚠️  Admin user already exists!");
      console.log("\n📧 Existing Credentials:");
      console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
      console.log(`Email:    ${email}`);
      console.log("Password: (use existing password)");
      console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
      console.log("\n💡 To reset password, delete the user from database first.\n");
      await mongoose.connection.close();
      process.exit(0);
    }

    // Hash password manually
    const hashedPassword = await bcrypt.hash(password, 12);

    // Create new admin user directly in collection
    await usersCollection.insertOne({
      email: email.toLowerCase().trim(),
      password: hashedPassword,
      name: "Admin User",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    console.log("\n✅ Admin user created successfully!");
    console.log("\n📧 Login Credentials:");
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    console.log(`Email:    ${email}`);
    console.log(`Password: ${password}`);
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    console.log("\n⚠️  Please change the password after first login!");
    console.log("\n");

    await mongoose.connection.close();
    process.exit(0);
  } catch (error: any) {
    console.error("❌ Error creating admin user:", error.message);
    if (error.code === 11000) {
      console.error("   User with this email already exists!");
    }
    // Try to close connection if it exists
    // readyState: 0 = disconnected, 1 = connected, 2 = connecting, 3 = disconnecting
    if (Number(mongoose.connection.readyState) !== 0) {
      await mongoose.connection.close().catch(() => {});
    }
    process.exit(1);
  }
}

createAdminUser();
