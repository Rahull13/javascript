import mongoose from "mongoose";

const MONGODB_URI = process.env.MONGODB_URI;

if (!MONGODB_URI) {
  throw new Error("Please define the MONGODB_URI environment variable inside .env");
}

// Fix database name case sensitivity issue
// If connection string has "dashboard" (lowercase) but DB is "Dashboard" (capital D), fix it
function fixDatabaseName(uri: string): string {
  // Simple string replacement: replace "/dashboard" with "/Dashboard"
  // This handles the MongoDB case sensitivity issue where DB exists as "Dashboard" but URI has "dashboard"
  if (uri.includes("/dashboard") && !uri.includes("/Dashboard")) {
    // Use regex to replace only the database name part, not other occurrences
    return uri.replace(/\/(dashboard)(\?|$|\/)/g, "/Dashboard$2");
  }
  return uri;
}

const CORRECTED_MONGODB_URI = fixDatabaseName(MONGODB_URI);

interface MongooseCache {
  conn: typeof mongoose | null;
  promise: Promise<typeof mongoose> | null;
}

declare global {
  // eslint-disable-next-line no-var
  var mongoose: MongooseCache | undefined;
}

let cached: MongooseCache = global.mongoose || { conn: null, promise: null };

if (!global.mongoose) {
  global.mongoose = cached;
}

export async function connectToDatabase(): Promise<typeof mongoose> {
  if (cached.conn) {
    return cached.conn;
  }

  if (!cached.promise) {
    const opts = {
      bufferCommands: false,
    };

    // Use the corrected URI with proper database name case
    cached.promise = mongoose.connect(CORRECTED_MONGODB_URI, opts).then((mongoose) => {
      return mongoose;
    }).catch(async (error: any) => {
      // If still getting case error, try with original URI (fallback)
      if (error.message && error.message.includes("already exists with different case")) {
        // Wait a moment for connection to stabilize
        await new Promise(resolve => setTimeout(resolve, 300));
        
        // Check if connection is actually working despite the error
        if (Number(mongoose.connection.readyState) === 1) {
          // Connection is working, proceed with it
          return mongoose;
        }
      }
      throw error;
    });
  }

  try {
    cached.conn = await cached.promise;
  } catch (e: any) {
    // If it's a database case error but connection is working, proceed
    if (e.message && e.message.includes("already exists with different case")) {
      await new Promise(resolve => setTimeout(resolve, 300));
      if (Number(mongoose.connection.readyState) === 1) {
        // Connection is working, use it
        cached.conn = mongoose;
        return cached.conn;
      }
    }
    cached.promise = null;
    throw e;
  }

  return cached.conn;
}

