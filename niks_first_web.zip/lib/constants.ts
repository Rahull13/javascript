/**
 * Application Constants
 * Static data for the Videograph theme home page
 */

/* ─── Hero Slides ─── */
export const HERO_SLIDES = [
  {
    id: 1,
    subtitle: "For website and video editing",
    title: "Videographer's Portfolio",
    cta: "See more about us",
    ctaHref: "/about",
    image: "/images/hero/hero-1.jpg",
  },
  {
    id: 2,
    subtitle: "For website and video editing",
    title: "Videographer's Portfolio",
    cta: "See more about us",
    ctaHref: "/about",
    image: "/images/hero/hero-1.jpg",
  },
  {
    id: 3,
    subtitle: "For website and video editing",
    title: "Videographer's Portfolio",
    cta: "See more about us",
    ctaHref: "/about",
    image: "/images/hero/hero-1.jpg",
  },
] as const;

/* ─── Services ─── */
export const SERVICES = [
  {
    id: "scriptwriting",
    icon: "/images/icons/si-2.png",
    title: "Scriptwriting and editing",
    description:
      "Whether you're halfway through the editing process, or you haven't even started, our post production services can put the finishing touches.",
  },
  {
    id: "motion-graphics",
    icon: "/images/icons/si-1.png",
    title: "Motion graphics",
    description:
      "Whether you're halfway through the editing process, or you haven't even started, our post production services can put the finishing touches.",
  },
  {
    id: "post-production",
    icon: "/images/icons/si-2.png",
    title: "Post production",
    description:
      "Whether you're halfway through the editing process, or you haven't even started, our post production services can put the finishing touches.",
  },
  {
    id: "video-distribution",
    icon: "/images/icons/si-3.png",
    title: "Video distribution",
    description:
      "Whether you're halfway through the editing process, or you haven't even started, our post production services can put the finishing touches.",
  },
  {
    id: "video-hosting",
    icon: "/images/icons/si-4.png",
    title: "Video hosting",
    description:
      "Whether you're halfway through the editing process, or you haven't even started, our post production services can put the finishing touches.",
  },
  {
    id: "live-streaming",
    icon: "/images/icons/si-4.png",
    title: "Live streaming",
    description:
      "Whether you're halfway through the editing process, or you haven't even started, our post production services can put the finishing touches.",
  },
] as const;

/* ─── Work Gallery ─── */
export const WORK_ITEMS: Array<{
  id: number;
  image: string;
  videoUrl: string;
  title?: string;
  tags?: string[];
  size: "wide" | "small" | "large";
}> = [
  {
    id: 1,
    image: "/images/work/work-1.jpg",
    videoUrl: "https://www.youtube.com/watch?v=LXb3EKWsInQ",
    title: "VIP Auto Tires & Service",
    tags: ["eCommerce", "Magento"],
    size: "wide",
  },
  {
    id: 2,
    image: "/images/work/work-2.jpg",
    videoUrl: "https://www.youtube.com/watch?v=LXb3EKWsInQ",
    size: "small",
  },
  {
    id: 3,
    image: "/images/work/work-3.jpg",
    videoUrl: "https://www.youtube.com/watch?v=LXb3EKWsInQ",
    size: "small",
  },
  {
    id: 4,
    image: "/images/work/work-4.jpg",
    videoUrl: "https://www.youtube.com/watch?v=LXb3EKWsInQ",
    title: "VIP Auto Tires & Service",
    tags: ["eCommerce", "Magento"],
    size: "large",
  },
  {
    id: 5,
    image: "/images/work/work-5.jpg",
    videoUrl: "https://www.youtube.com/watch?v=LXb3EKWsInQ",
    size: "small",
  },
  {
    id: 6,
    image: "/images/work/work-6.jpg",
    videoUrl: "https://www.youtube.com/watch?v=LXb3EKWsInQ",
    size: "small",
  },
  {
    id: 7,
    image: "/images/work/work-7.jpg",
    videoUrl: "https://www.youtube.com/watch?v=LXb3EKWsInQ",
    title: "VIP Auto Tires & Service",
    tags: ["eCommerce", "Magento"],
    size: "wide",
  },
] ;

/* ─── Counter Stats ─── */
export const COUNTER_STATS = [
  { id: 1, icon: "/images/icons/ci-1.png", value: 230, label: "Completed Projects" },
  { id: 2, icon: "/images/icons/ci-2.png", value: 1068, label: "Happy clients" },
  { id: 3, icon: "/images/icons/ci-3.png", value: 230, label: "Perspective clients" },
  { id: 4, icon: "/images/icons/ci-4.png", value: 230, label: "Completed Projects" },
] as const;

/* ─── Team Members ─── */
export const TEAM_MEMBERS = [
  { id: 1, name: "AMANDA STONE", role: "Videographer", image: "/images/team/team-1.jpg" },
  { id: 2, name: "AMANDA STONE", role: "Videographer", image: "/images/team/team-2.jpg" },
  { id: 3, name: "AMANDA STONE", role: "Videographer", image: "/images/team/team-3.jpg" },
  { id: 4, name: "AMANDA STONE", role: "Videographer", image: "/images/team/team-4.jpg" },
] as const;

/* ─── Latest Blog Posts ─── */
export const BLOG_POSTS = [
  {
    id: 1,
    title: "What Makes Users Want to Share a Video on Social Media?",
    date: "Jan 03, 2020",
    comments: 5,
    excerpt:
      "We recently launched a new website for a Vital client and wanted to share some of the cool features we were able...",
    href: "/blog/share-video-social-media",
  },
  {
    id: 2,
    title: "Bumper Ads: How to Tell a Story in 6 Seconds",
    date: "Jan 03, 2020",
    comments: 5,
    excerpt:
      "We recently launched a new website for a Vital client and wanted to share some of the cool features we were able...",
    href: "/blog/bumper-ads-story",
  },
  {
    id: 3,
    title: "Recruitment Marketing for the Digital Age: A Definitive Guide",
    date: "Jan 03, 2020",
    comments: 5,
    excerpt:
      "We recently launched a new website for a Vital client and wanted to share some of the cool features we were able...",
    href: "/blog/recruitment-marketing-digital-age",
  },
  {
    id: 4,
    title: "Say Bonjour! Ola! & Guten Tag! to Our New Team Members",
    date: "Jan 03, 2020",
    comments: 5,
    excerpt:
      "We recently launched a new website for a Vital client and wanted to share some of the cool features we were able...",
    href: "/blog/new-team-members",
  },
  {
    id: 5,
    title: "Recruitment Marketing for the Digital Age: A Definitive Guide",
    date: "Jan 03, 2020",
    comments: 5,
    excerpt:
      "We recently launched a new website for a Vital client and wanted to share some of the cool features we were able...",
    href: "/blog/recruitment-marketing-guide",
  },
  {
    id: 6,
    title: "Pay-Per-Click Marketing: A 'Nuts & Bolts' Guide",
    date: "Jan 03, 2020",
    comments: 5,
    excerpt:
      "We recently launched a new website for a Vital client and wanted to share some of the cool features we were able...",
    href: "/blog/ppc-marketing-guide",
  },
  {
    id: 7,
    title: "Vital Launches New University Website Design for...",
    date: "Jan 03, 2020",
    comments: 5,
    excerpt:
      "We recently launched a new website for a Vital client and wanted to share some of the cool features we were able...",
    href: "/blog/university-website-design",
  },
  {
    id: 8,
    title: "How and When to Write a Press Release: Best Practices...",
    date: "Jan 03, 2020",
    comments: 5,
    excerpt:
      "We recently launched a new website for a Vital client and wanted to share some of the cool features we were able...",
    href: "/blog/press-release-best-practices",
  },
  {
    id: 9,
    title: "What Makes Users Want to Share a Video on Social Media?",
    date: "Jan 03, 2020",
    comments: 5,
    excerpt:
      "We recently launched a new website for a Vital client and wanted to share some of the cool features we were able...",
    href: "/blog/share-video-social-media-2",
  },
] as const;

/* ─── Testimonials ─── */
export const TESTIMONIALS = [
  {
    id: 1,
    text: "Delivers such a great service that it can benefit all kinds of people from any number of industries.",
    avatar: "/images/testimonial/ta-1.jpg",
    name: "Krista Attorn",
    role: "Web Designer",
  },
  {
    id: 2,
    text: "Videographer delivers such a great service that it can benefit all kinds of people from any number.",
    avatar: "/images/testimonial/ta-2.jpg",
    name: "Krista Attorn",
    role: "Web Designer",
  },
  {
    id: 3,
    text: "Videographer delivers such a great service that it can benefit all kinds of people from any number.",
    avatar: "/images/testimonial/ta-3.jpg",
    name: "Krista Attorn",
    role: "Web Designer",
  },
  {
    id: 4,
    text: "Delivers such a great service that it can benefit all kinds of people from any number of industries.",
    avatar: "/images/testimonial/ta-1.jpg",
    name: "Krista Attorn",
    role: "Web Designer",
  },
  {
    id: 5,
    text: "Videographer delivers such a great service that it can benefit all kinds of people from any number.",
    avatar: "/images/testimonial/ta-2.jpg",
    name: "Krista Attorn",
    role: "Web Designer",
  },
] as const;

/* ─── About Page Mini-Services ─── */
export const ABOUT_SERVICES = [
  {
    id: "video-distribution",
    icon: "/images/icons/si-3.png",
    title: "Video distribution",
    description: "Whether you're halfway through the editing process, or you.",
  },
  {
    id: "video-hosting",
    icon: "/images/icons/si-4.png",
    title: "Video hosting",
    description: "Whether you're halfway through the editing process, or you.",
  },
] as const;

/* ─── About Page Images ─── */
export const ABOUT_IMAGES = {
  large: "/images/about/about-1.jpg",
  smallTop: "/images/about/about-2.jpg",
  smallBottom: "/images/about/about-3.jpg",
} as const;

/* ─── Footer Quick Links ─── */
export const FOOTER_WHO_WE_ARE = [
  { label: "Team", href: "/about" },
  { label: "Careers", href: "/about" },
  { label: "Contact us", href: "/contact" },
  { label: "Locations", href: "/contact" },
] as const;

export const FOOTER_OUR_WORK = [
  { label: "Feature", href: "/portfolio" },
  { label: "Latest", href: "/blog" },
  { label: "Browse Archive", href: "/portfolio" },
  { label: "Video for web", href: "/services" },
] as const;

/* ─── Client Logos ─── */
export const CLIENT_LOGOS = [
  { id: 1, src: "/images/logo/logo-1.png", alt: "Client 1" },
  { id: 2, src: "/images/logo/logo-2.png", alt: "Client 2" },
  { id: 3, src: "/images/logo/logo-3.png", alt: "Client 3" },
  { id: 4, src: "/images/logo/logo-4.png", alt: "Client 4" },
  { id: 5, src: "/images/logo/logo-5.png", alt: "Client 5" },
  { id: 6, src: "/images/logo/logo-6.png", alt: "Client 6" },
] as const;

/* ─── Portfolio Filter Categories ─── */
export const PORTFOLIO_CATEGORIES = [
  "All",
  "Branding",
  "Digital Marketing",
  "Web",
  "Photography",
  "eCommerce",
] as const;

export type PortfolioCategory = (typeof PORTFOLIO_CATEGORIES)[number];

/* ─── Portfolio Items ─── */
export const PORTFOLIO_ITEMS = [
  {
    id: 1,
    title: "VIP Auto Tires & Service",
    slug: "vip-auto-tires",
    description:
      "Full branding and commercial video production for an auto-service franchise, including social media assets and broadcast spots.",
    coverImage: "/images/portfolio/portfolio-1.jpg",
    category: "Branding" as PortfolioCategory,
    tags: ["eCommerce", "Magento"],
  },
  {
    id: 2,
    title: "Urban Lens Photography",
    slug: "urban-lens-photography",
    description:
      "Lifestyle photography campaign capturing city energy for a boutique studio launch across digital platforms.",
    coverImage: "/images/portfolio/portfolio-2.jpg",
    category: "Photography" as PortfolioCategory,
    tags: ["Photography"],
  },
  {
    id: 3,
    title: "TechNova Product Launch",
    slug: "technova-product-launch",
    description:
      "End-to-end web design and promotional video for a SaaS product launch, featuring motion graphics and landing page build.",
    coverImage: "/images/portfolio/portfolio-3.jpg",
    category: "Web" as PortfolioCategory,
    tags: ["eCommerce", "Magento"],
  },
  {
    id: 4,
    title: "GreenLeaf Organics Rebrand",
    slug: "greenleaf-organics-rebrand",
    description:
      "Complete brand identity refresh including logo design, packaging, and corporate video for an organic food company.",
    coverImage: "/images/portfolio/portfolio-4.jpg",
    category: "Branding" as PortfolioCategory,
    tags: ["eCommerce", "Magento"],
  },
  {
    id: 5,
    title: "Skyline Digital Campaign",
    slug: "skyline-digital-campaign",
    description:
      "Multi-channel digital marketing campaign with video ads, social media content, and analytics dashboard integration.",
    coverImage: "/images/portfolio/portfolio-5.jpg",
    category: "Digital Marketing" as PortfolioCategory,
    tags: ["Photography"],
  },
  {
    id: 6,
    title: "Artisan Coffee eShop",
    slug: "artisan-coffee-eshop",
    description:
      "Responsive eCommerce storefront with product video walkthroughs and automated email marketing sequences.",
    coverImage: "/images/portfolio/portfolio-6.jpg",
    category: "eCommerce" as PortfolioCategory,
    tags: ["eCommerce", "Magento"],
  },
  {
    id: 7,
    title: "Momentum Fitness Web App",
    slug: "momentum-fitness-web-app",
    description:
      "Interactive web application with class booking, member portal, and promotional fitness video series.",
    coverImage: "/images/portfolio/portfolio-7.jpg",
    category: "Web" as PortfolioCategory,
    tags: ["eCommerce", "Magento"],
  },
  {
    id: 8,
    title: "Horizon Travel Diaries",
    slug: "horizon-travel-diaries",
    description:
      "Travel photography and videography series showcasing destinations, published across web and social channels.",
    coverImage: "/images/portfolio/portfolio-8.jpg",
    category: "Photography" as PortfolioCategory,
    tags: ["Photography"],
  },
  {
    id: 9,
    title: "NovaCraft Brand Identity",
    slug: "novacraft-brand-identity",
    description:
      "Strategic branding package including visual identity, animated logo reveal, and brand guidelines document.",
    coverImage: "/images/portfolio/portfolio-9.jpg",
    category: "eCommerce" as PortfolioCategory,
    tags: ["eCommerce", "Magento"],
  },
] as const;

/* ─── Service Detail (mock extended content keyed by slug) ─── */
export interface ServiceDetail {
  slug: string;
  icon: string;
  title: string;
  tagline: string;
  intro: string;
  description: string[];
  quote: { text: string; author: string };
  highlights: { label: string; value: string }[];
  process: { step: number; title: string; text: string }[];
}

const SERVICE_DETAIL_DEFAULTS: Omit<ServiceDetail, "slug" | "icon" | "title"> = {
  tagline: "Professional video production services tailored to your needs",
  intro:
    "Our team of experienced professionals delivers high-quality results that exceed expectations. We combine creative vision with technical expertise to bring your story to life.",
  description: [
    "Videos with a wow factor are always more impactful than those without. We specialise in crafting content that captures attention and drives engagement across every platform — from social media to broadcast television.",
    "With years of industry experience, our dedicated team understands the nuances of visual storytelling. We work closely with each client to ensure every frame communicates the right message.",
  ],
  quote: {
    text: "Create horizontal, square and vertical videos that are ready to be exported to your social media stories and posts. Perfect for any network!",
    author: "Max Desmarais",
  },
  highlights: [
    { label: "Projects Completed", value: "230+" },
    { label: "Client Satisfaction", value: "98%" },
    { label: "Years Experience", value: "14+" },
    { label: "Team Members", value: "25" },
  ],
  process: [
    {
      step: 1,
      title: "Discovery & Planning",
      text: "We start by understanding your goals, target audience, and brand identity to create a tailored production plan.",
    },
    {
      step: 2,
      title: "Production",
      text: "Our crew handles everything from filming to voice-overs, using state-of-the-art equipment for the best results.",
    },
    {
      step: 3,
      title: "Post Production",
      text: "Expert editing, colour grading, motion graphics, and sound design bring the final piece together.",
    },
    {
      step: 4,
      title: "Delivery & Support",
      text: "We deliver in all required formats and provide ongoing support for distribution and optimisation.",
    },
  ],
};

export function getServiceDetail(slug: string): ServiceDetail | null {
  const service = SERVICES.find((s) => s.id === slug);
  if (!service) return null;
  return {
    slug: service.id,
    icon: service.icon,
    title: service.title,
    ...SERVICE_DETAIL_DEFAULTS,
  };
}

/* ─── Blog Detail ─── */
export interface BlogDetail {
  slug: string;
  title: string;
  author: string;
  date: string;
  comments: number;
  heroImage: string;
  content: string[];
  quote: { text: string; author: string };
  description: string[];
  tags: string[];
  prevPost: { title: string; date: string; image: string; href: string } | null;
  nextPost: { title: string; date: string; image: string; href: string } | null;
  recentPosts: { title: string; date: string; image: string; href: string }[];
}

const BLOG_DETAIL_DEFAULTS: Omit<BlogDetail, "slug" | "title" | "date" | "comments" | "prevPost" | "nextPost"> = {
  author: "Krista Starkes",
  heroImage: "/images/blog/blog-hero.jpg",
  content: [
    "Videos with a wow factor are always more shareable than those without it. The wow factor is hard to define, but it generally refers to any content that makes viewers think, \"Wow!\" For example, consider those viral videos of athletes making insanely difficult basketball trick shots, such as shooting a basket while doing a backwards flip on a trampoline.",
    "That's the kind of catchy content that makes people want to share it with their friends. With a little clever marketing, you can put that wow factor to work for your business' videos.",
  ],
  quote: {
    text: "Create horizontal, square and vertical videos that are ready to be exported to your Instagram video stories and posts. Perfect for any social network!",
    author: "Max Desmarais",
  },
  description: [
    "An average Internet user watches about 1.5 hours of online video every day. This means that video can be a powerful marketing tool for getting your message before the eyes of millions of people. However, not all videos are created equal.",
    "Some of them are inherently more shareable on social media than others. Here's a quick look at how to make users want to share your videos on social media.",
  ],
  tags: ["Wedding", "Event", "Couple"],
  recentPosts: [
    {
      title: "What are the steps of a body lift procedure?",
      date: "Dec 06, 2019",
      image: "/images/blog/ri-1.jpg",
      href: "#",
    },
    {
      title: "What are the steps of a body lift procedure?",
      date: "Dec 06, 2019",
      image: "/images/blog/ri-2.jpg",
      href: "#",
    },
    {
      title: "How to shop for a cosm surgery procedure",
      date: "Dec 06, 2019",
      image: "/images/blog/ri-3.jpg",
      href: "#",
    },
  ],
};

export function getBlogDetail(slug: string): BlogDetail | null {
  const postIndex = BLOG_POSTS.findIndex(
    (p) => p.href === `/blog/${slug}`
  );
  if (postIndex === -1) return null;

  const post = BLOG_POSTS[postIndex];
  const prev = postIndex > 0 ? BLOG_POSTS[postIndex - 1] : null;
  const next =
    postIndex < BLOG_POSTS.length - 1 ? BLOG_POSTS[postIndex + 1] : null;

  return {
    slug,
    title: post.title,
    date: post.date,
    comments: post.comments,
    ...BLOG_DETAIL_DEFAULTS,
    prevPost: prev
      ? {
          title: "Looking for Music & Sounds for my new Android...",
          date: "Nov 27, 2019",
          image: "/images/blog/prev.jpg",
          href: prev.href,
        }
      : null,
    nextPost: next
      ? {
          title: "Looking for Music & Sounds for my new Android...",
          date: "Nov 27, 2019",
          image: "/images/blog/next.jpg",
          href: next.href,
        }
      : null,
  };
}

/* ─── Portfolio Detail ─── */
export interface PortfolioDetail {
  slug: string;
  title: string;
  description: string;
  coverImage: string;
  category: string;
  tags: readonly string[];
  client: string;
  industry: string;
  images: { src: string; alt: string }[];
  overview: string[];
  highlights: { label: string; value: string }[];
  relatedItems: typeof PORTFOLIO_ITEMS[number][];
}

export function getPortfolioDetail(slug: string): PortfolioDetail | null {
  const item = PORTFOLIO_ITEMS.find((p) => p.slug === slug);
  if (!item) return null;

  // Use all available portfolio images for the gallery (cycling through them)
  const galleryImages = [
    { src: item.coverImage, alt: `${item.title} — Cover` },
    {
      src: `/images/portfolio/portfolio-${((item.id % 9) + 1)}.jpg`,
      alt: `${item.title} — Detail 1`,
    },
    {
      src: `/images/portfolio/portfolio-${(((item.id + 1) % 9) + 1)}.jpg`,
      alt: `${item.title} — Detail 2`,
    },
  ];

  // Get 3 related items (exclude current, different category preferred)
  const related = PORTFOLIO_ITEMS.filter((p) => p.slug !== slug).slice(0, 3);

  return {
    slug: item.slug,
    title: item.title,
    description: item.description,
    coverImage: item.coverImage,
    category: item.category,
    tags: item.tags,
    client: `${item.title.split(" ")[0]} Corp`,
    industry: item.category === "All" ? "Technology" : item.category,
    images: galleryImages,
    overview: [
      "This project showcased our ability to deliver end-to-end creative solutions that align with brand vision and market goals. From initial concept through to final delivery, every element was crafted to maximise impact.",
      "Working closely with the client's team, we developed a comprehensive strategy that spanned multiple channels and formats, ensuring consistency and engagement across all touchpoints.",
    ],
    highlights: [
      { label: "Duration", value: "3 Months" },
      { label: "Team Size", value: "8 People" },
      { label: "Deliverables", value: "12 Assets" },
      { label: "Satisfaction", value: "100%" },
    ],
    relatedItems: [...related],
  };
}
