import React from "react";
import { Metadata } from "next";
import { siteConfig } from "@/config/site";

export interface SEOData {
  title?: string;
  description?: string;
  keywords?: string[];
  summary?: string; // AI-search optimized summary
  image?: string;
  url?: string;
  type?: "website" | "article" | "service";
  publishedTime?: string;
  modifiedTime?: string;
  author?: string;
  geoLocation?: string; // Default from config or override
}

export interface FAQItem {
  question: string;
  answer: string;
}

interface GeoConfig {
  defaultLocation: string;
  modifierPrefix: string;
}

const defaultGeoConfig: GeoConfig = {
  defaultLocation: "US",
  modifierPrefix: "geo",
};

/**
 * Generate dynamic metadata for pages
 */
export function generateMetadata(data: SEOData): Metadata {
  const {
    title,
    description,
    keywords,
    image,
    url,
    type = "website",
    publishedTime,
    modifiedTime,
  } = data;

  const metaTitle = title || siteConfig.name;
  const metaDescription = description || siteConfig.description;
  const metaKeywords = keywords?.join(", ");
  const metaImage = image || siteConfig.ogImage;
  const metaUrl = url || siteConfig.url;

  return {
    title: metaTitle,
    description: metaDescription,
    keywords: metaKeywords,
    openGraph: {
      title: metaTitle,
      description: metaDescription,
      type: type === "article" ? "article" : "website",
      url: metaUrl,
      images: [
        {
          url: metaImage,
          width: 1200,
          height: 630,
          alt: metaTitle,
        },
      ],
      ...(publishedTime && { publishedTime }),
      ...(modifiedTime && { modifiedTime }),
    },
    twitter: {
      card: "summary_large_image",
      title: metaTitle,
      description: metaDescription,
    },
    alternates: {
      canonical: metaUrl,
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        "max-video-preview": -1,
        "max-image-preview": "large",
        "max-snippet": -1,
      },
    },
  };
}

/**
 * Generate keyword meta tags for SEO/AEO/GEO/AIO
 */
export function generateKeywordMetaTags(
  keywords: string[],
  geoConfig: GeoConfig = defaultGeoConfig
): React.JSX.Element[] {
  if (!keywords || keywords.length === 0) return [];

  const tags: React.JSX.Element[] = [];

  // Standard keywords meta tag
  tags.push(
    <meta key="keywords" name="keywords" content={keywords.join(", ")} />
  );

  // Geo modifiers for GEO optimization
  keywords.forEach((keyword, index) => {
    const geoKey = `${geoConfig.modifierPrefix}.${keyword.toLowerCase().replace(/\s+/g, "-")}`;
    tags.push(
      <meta key={`geo-${index}`} name={geoKey} content={geoConfig.defaultLocation} />
    );
  });

  return tags;
}

/**
 * Generate AI-search optimized summary (structured data)
 */
export function generateAISummary(data: {
  title: string;
  description: string;
  summary?: string;
  keywords?: string[];
  url: string;
  type?: string;
}): React.JSX.Element {
  const { title, description, summary, keywords, url, type = "WebPage" } = data;

  const structuredData = {
    "@context": "https://schema.org",
    "@type": type,
    name: title,
    description: summary || description,
    url: url,
    ...(keywords && keywords.length > 0 && { keywords: keywords.join(", ") }),
    mainEntity: {
      "@type": "FinancialService",
      name: siteConfig.name,
      description: siteConfig.description,
    },
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{
        __html: JSON.stringify(structuredData),
      }}
    />
  );
}

/**
 * Generate FAQ schema (Schema.org FAQPage)
 */
export function generateFAQSchema(faqs: FAQItem[], url: string): React.JSX.Element {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.answer,
      },
    })),
    url: url,
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{
        __html: JSON.stringify(structuredData),
      }}
    />
  );
}

/**
 * Generate FAQ HTML with schema markup
 */
export function generateFAQHTML(faqs: FAQItem[]): React.JSX.Element {
  return (
    <div itemScope itemType="https://schema.org/FAQPage" className="space-y-6">
      {faqs.map((faq, index) => (
        <div
          key={index}
          itemScope
          itemType="https://schema.org/Question"
          className="bg-gray-50 rounded-lg p-6"
        >
          <h3 itemProp="name" className="text-lg font-semibold text-gray-900 mb-2">
            {faq.question}
          </h3>
          <div
            itemScope
            itemType="https://schema.org/Answer"
            itemProp="acceptedAnswer"
            className="text-gray-600"
          >
            <p itemProp="text">{faq.answer}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

/**
 * Complete SEO component generator
 */
export function generateSEOComponents(data: SEOData & {
  faqs?: FAQItem[];
  geoConfig?: GeoConfig;
}): {
  metadata: Metadata;
  keywordTags: React.JSX.Element[];
  aiSummary: React.JSX.Element | null;
  faqSchema: React.JSX.Element | null;
  faqHTML: React.JSX.Element | null;
} {
  const {
    faqs,
    geoConfig = defaultGeoConfig,
    summary,
    keywords,
    url = siteConfig.url,
    title,
    description,
    type = "website",
  } = data;

  return {
    metadata: generateMetadata(data),
    keywordTags: keywords ? generateKeywordMetaTags(keywords, geoConfig) : [],
    aiSummary: summary || description
      ? generateAISummary({
          title: title || siteConfig.name,
          description: description || siteConfig.description,
          summary: summary,
          keywords: keywords,
          url: url,
          type: type === "article" ? "BlogPosting" : "WebPage",
        })
      : null,
    faqSchema: faqs && faqs.length > 0 ? generateFAQSchema(faqs, url) : null,
    faqHTML: faqs && faqs.length > 0 ? generateFAQHTML(faqs) : null,
  };
}

