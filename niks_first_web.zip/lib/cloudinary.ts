import { v2 as cloudinary } from "cloudinary";

// Cloudinary configuration from environment variables
const CLOUDINARY_CLOUD_NAME = process.env.CLOUDINARY_CLOUD_NAME;
const CLOUDINARY_API_KEY = process.env.CLOUDINARY_API_KEY;
const CLOUDINARY_API_SECRET = process.env.CLOUDINARY_API_SECRET;

if (!CLOUDINARY_CLOUD_NAME) {
  throw new Error("Please define the CLOUDINARY_CLOUD_NAME environment variable inside .env");
}

if (!CLOUDINARY_API_KEY) {
  throw new Error("Please define the CLOUDINARY_API_KEY environment variable inside .env");
}

if (!CLOUDINARY_API_SECRET) {
  throw new Error("Please define the CLOUDINARY_API_SECRET environment variable inside .env");
}

// Configure Cloudinary
cloudinary.config({
  cloud_name: CLOUDINARY_CLOUD_NAME,
  api_key: CLOUDINARY_API_KEY,
  api_secret: CLOUDINARY_API_SECRET,
  secure: true, // Use HTTPS
});

// Export the configured Cloudinary instance
// This file is server-only and should never be imported in client components
export default cloudinary;

/**
 * Upload an image to Cloudinary
 * @param file - File object or Buffer containing the image data
 * @param folder - Optional folder path in Cloudinary (e.g., "blogs", "services")
 * @returns Promise with secure_url and public_id
 */
export async function uploadImage(
  file: File | Buffer,
  folder?: string
): Promise<{ secure_url: string; public_id: string }> {
  try {
    // Convert File to Buffer if needed
    let buffer: Buffer;
    if (file instanceof File) {
      const arrayBuffer = await file.arrayBuffer();
      buffer = Buffer.from(arrayBuffer);
    } else {
      buffer = file;
    }

    // Upload to Cloudinary using upload_stream
    return new Promise((resolve, reject) => {
      const uploadOptions: {
        folder?: string;
        resource_type: "image" | "auto";
        overwrite?: boolean;
      } = {
        resource_type: "image",
        overwrite: false,
      };

      if (folder) {
        uploadOptions.folder = folder;
      }

      const uploadStream = cloudinary.uploader.upload_stream(
        uploadOptions,
        (error, result) => {
          if (error) {
            reject(new Error(`Cloudinary upload failed: ${error.message}`));
            return;
          }

          if (!result || !result.secure_url || !result.public_id) {
            reject(new Error("Cloudinary upload returned invalid result"));
            return;
          }

          resolve({
            secure_url: result.secure_url,
            public_id: result.public_id,
          });
        }
      );

      uploadStream.end(buffer);
    });
  } catch (error: any) {
    throw new Error(`Failed to upload image: ${error.message}`);
  }
}

/**
 * Delete an image from Cloudinary
 * @param publicId - Cloudinary public_id of the image to delete
 * @returns Promise with success status
 */
export async function deleteImage(publicId: string): Promise<{ success: boolean }> {
  try {
    if (!publicId || publicId.trim() === "") {
      throw new Error("Public ID is required");
    }

    return new Promise((resolve, reject) => {
      cloudinary.uploader.destroy(publicId, { resource_type: "image" }, (error, result) => {
        if (error) {
          reject(new Error(`Cloudinary delete failed: ${error.message}`));
          return;
        }

        if (!result) {
          reject(new Error("Cloudinary delete returned invalid result"));
          return;
        }

        // Cloudinary returns { result: "ok" } or { result: "not found" }
        if (result.result === "ok" || result.result === "not found") {
          resolve({ success: true });
        } else {
          reject(new Error(`Cloudinary delete failed: ${result.result}`));
        }
      });
    });
  } catch (error: any) {
    throw new Error(`Failed to delete image: ${error.message}`);
  }
}

