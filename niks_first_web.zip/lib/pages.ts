/**
 * Server-side data layer for fetching published pages from MongoDB.
 * Used by frontend pages (/, /about).
 * This file is server-only — never import in Client Components.
 */

import { connectToDatabase } from "./mongodb";
import Page from "@/models/Page";
import { cache } from "react";

/* ─── Section Data Types ─── */

export interface HeroSlide {
  subtitle: string;
  title: string;
  cta: string;
  ctaHref: string;
  image: string;
}

export interface CounterStat {
  icon: string;
  value: number;
  label: string;
}

export interface WorkItem {
  image: string;
  videoUrl: string;
  title?: string;
  tags?: string[];
  size: "wide" | "small" | "large";
}

export interface TeamMember {
  name: string;
  role: string;
  image: string;
}

export interface CtaData {
  title: string;
  tagline: string;
  buttonText: string;
  buttonHref: string;
  backgroundImage: string;
}

export interface ServicesSectionData {
  subtitle: string;
  title: string;
  description: string;
  buttonText: string;
}

export interface Testimonial {
  text: string;
  avatar: string;
  name: string;
  role: string;
}

export interface AboutImagesData {
  large: string;
  smallTop: string;
  smallBottom: string;
}

export interface AboutServiceItem {
  icon: string;
  title: string;
  description: string;
}

export interface AboutSectionData {
  subtitle: string;
  title: string;
  description: string;
  images: AboutImagesData;
  services: AboutServiceItem[];
}

/* ─── Page Data (raw from DB) ─── */

export interface PublishedPage {
  slug: string;
  title: string;
  content: string;
  sections: Record<string, unknown>;
  // Legacy flat SEO fields (still used by current admin form UI)
  metaTitle?: string;
  metaDescription?: string;
  keywords?: string[];
  seo?: {
    title?: string;
    description?: string;
    keywords?: string[];
    ogImage?: string;
  };
}

/* ─── Typed section extractors ─── */

/**
 * Safely extract an array from sections JSON, with type guard.
 */
function safeArray<T>(value: unknown, validator: (item: unknown) => item is T): T[] {
  if (!Array.isArray(value)) return [];
  return value.filter(validator);
}

function isHeroSlide(item: unknown): item is HeroSlide {
  return (
    typeof item === "object" &&
    item !== null &&
    typeof (item as any).title === "string" &&
    typeof (item as any).image === "string"
  );
}

function isCounterStat(item: unknown): item is CounterStat {
  return (
    typeof item === "object" &&
    item !== null &&
    typeof (item as any).value === "number" &&
    typeof (item as any).label === "string"
  );
}

function isWorkItem(item: unknown): item is WorkItem {
  return (
    typeof item === "object" &&
    item !== null &&
    typeof (item as any).image === "string" &&
    typeof (item as any).size === "string"
  );
}

function isTeamMember(item: unknown): item is TeamMember {
  return (
    typeof item === "object" &&
    item !== null &&
    typeof (item as any).name === "string" &&
    typeof (item as any).image === "string"
  );
}

function isTestimonial(item: unknown): item is Testimonial {
  return (
    typeof item === "object" &&
    item !== null &&
    typeof (item as any).text === "string" &&
    typeof (item as any).name === "string"
  );
}

function isAboutService(item: unknown): item is AboutServiceItem {
  return (
    typeof item === "object" &&
    item !== null &&
    typeof (item as any).title === "string" &&
    typeof (item as any).icon === "string"
  );
}

/**
 * Extract typed section data from the raw sections JSON.
 * Returns undefined if the section is missing or malformed — callers fall back to defaults.
 */
export function extractHeroSlides(sections: Record<string, unknown>): HeroSlide[] | undefined {
  const hero = sections.hero as any;
  if (!hero?.slides) return undefined;
  const slides = safeArray(hero.slides, isHeroSlide);
  return slides.length > 0 ? slides : undefined;
}

export function extractCounterStats(sections: Record<string, unknown>): CounterStat[] | undefined {
  const counter = sections.counter as any;
  if (!counter?.stats) return undefined;
  const stats = safeArray(counter.stats, isCounterStat);
  return stats.length > 0 ? stats : undefined;
}

export function extractWorkItems(sections: Record<string, unknown>): WorkItem[] | undefined {
  const work = sections.work as any;
  if (!work?.items) return undefined;
  const items = safeArray(work.items, isWorkItem);
  return items.length > 0 ? items : undefined;
}

export function extractTeamMembers(sections: Record<string, unknown>): TeamMember[] | undefined {
  const team = sections.team as any;
  if (!team?.members) return undefined;
  const members = safeArray(team.members, isTeamMember);
  return members.length > 0 ? members : undefined;
}

export function extractCta(sections: Record<string, unknown>): CtaData | undefined {
  const cta = sections.cta as any;
  if (!cta || typeof cta.title !== "string") return undefined;
  return {
    title: cta.title,
    tagline: cta.tagline ?? "",
    buttonText: cta.buttonText ?? "Start your stories",
    buttonHref: cta.buttonHref ?? "/contact",
    backgroundImage: cta.backgroundImage ?? "/images/callto-bg.jpg",
  };
}

export function extractServicesSectionData(
  sections: Record<string, unknown>,
): ServicesSectionData | undefined {
  const svc = sections.services as any;
  if (!svc || typeof svc !== "object") return undefined;
  return {
    subtitle: svc.subtitle ?? "Our services",
    title: svc.title ?? "What We do?",
    description: svc.description ?? "",
    buttonText: svc.buttonText ?? "View all services",
  };
}

export function extractTestimonials(sections: Record<string, unknown>): Testimonial[] | undefined {
  const testimonials = sections.testimonials as any;
  if (!Array.isArray(testimonials)) return undefined;
  const items = safeArray(testimonials, isTestimonial);
  return items.length > 0 ? items : undefined;
}

export function extractAboutData(sections: Record<string, unknown>): AboutSectionData | undefined {
  const about = sections.about as any;
  if (!about || typeof about !== "object") return undefined;
  return {
    subtitle: about.subtitle ?? "About videograph",
    title: about.title ?? "WHo we are?",
    description: about.description ?? "",
    images: about.images ?? {
      large: "/images/about/about-1.jpg",
      smallTop: "/images/about/about-2.jpg",
      smallBottom: "/images/about/about-3.jpg",
    },
    services: Array.isArray(about.services)
      ? safeArray(about.services, isAboutService)
      : [],
  };
}

/* ─── Queries (React-cached for deduplication within a single render) ─── */

/**
 * Fetch a published page by slug. Returns null if not found or draft.
 */
export const getPublishedPage = cache(
  async (slug: string): Promise<PublishedPage | null> => {
    try {
      await connectToDatabase();
      const page = await Page.findOne({ slug, status: "published" })
        .select("slug title content sections seo metaTitle metaDescription keywords")
        .lean();

      if (!page) return null;

      return {
        slug: page.slug,
        title: page.title,
        content: page.content ?? "",
        sections: (page.sections as Record<string, unknown>) ?? {},
        metaTitle: (page as any).metaTitle || undefined,
        metaDescription: (page as any).metaDescription || undefined,
        keywords:
          (page as any).keywords && Array.isArray((page as any).keywords) && (page as any).keywords.length > 0
            ? [...(page as any).keywords]
            : undefined,
        seo: page.seo
          ? {
              title: page.seo.title || undefined,
              description: page.seo.description || undefined,
              keywords:
                page.seo.keywords && page.seo.keywords.length > 0
                  ? [...page.seo.keywords]
                  : undefined,
              ogImage: page.seo.ogImage || undefined,
            }
          : undefined,
      };
    } catch (error) {
      console.error(`Failed to fetch page "${slug}":`, error);
      return null;
    }
  },
);
