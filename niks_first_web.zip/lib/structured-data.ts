import { siteConfig } from "@/config/site";

type JsonLdValue =
  | string
  | number
  | boolean
  | undefined
  | null
  | JsonLdObject
  | JsonLdValue[];

export type JsonLdObject = { [key: string]: JsonLdValue };

function absUrl(pathOrUrl: string): string {
  if (/^https?:\/\//i.test(pathOrUrl)) return pathOrUrl;
  const base = siteConfig.url.replace(/\/+$/, "");
  const path = pathOrUrl.startsWith("/") ? pathOrUrl : `/${pathOrUrl}`;
  return `${base}${path}`;
}

function absUrlOpt(pathOrUrl?: string): string | undefined {
  if (!pathOrUrl) return undefined;
  return absUrl(pathOrUrl);
}

function stripUndefined<T extends JsonLdObject>(obj: T): T {
  return JSON.parse(
    JSON.stringify(obj, (_k, v) => (v === undefined ? undefined : v)),
  ) as T;
}

export function organizationJsonLd(): JsonLdObject {
  const logo = absUrlOpt("/images/logo.png") || absUrlOpt(siteConfig.ogImage);
  const contact = siteConfig.contact;

  return stripUndefined({
    "@context": "https://schema.org",
    "@type": "Organization",
    name: siteConfig.name,
    url: absUrl(siteConfig.url),
    logo,
    areaServed: contact?.address?.country ? [contact.address.country] : undefined,
    contactPoint: contact?.phone
      ? [
          stripUndefined({
            "@type": "ContactPoint",
            telephone: contact.phone,
            contactType: "customer support",
            email: contact.email || undefined,
          }),
        ]
      : undefined,
    address: contact?.address
      ? stripUndefined({
          "@type": "PostalAddress",
          streetAddress: contact.address.street || undefined,
          addressLocality: contact.address.city || undefined,
          postalCode: contact.address.zip || undefined,
          addressCountry: contact.address.country || undefined,
        })
      : undefined,
  });
}

export function localBusinessJsonLd(): JsonLdObject {
  const contact = siteConfig.contact;
  const logo = absUrlOpt("/images/logo.png") || absUrlOpt(siteConfig.ogImage);
  const url = absUrl(siteConfig.url);

  return stripUndefined({
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    name: siteConfig.name,
    url,
    image: absUrlOpt(siteConfig.ogImage),
    logo,
    telephone: contact?.phone || undefined,
    email: contact?.email || undefined,
    address: contact?.address
      ? stripUndefined({
          "@type": "PostalAddress",
          streetAddress: contact.address.street || undefined,
          addressLocality: contact.address.city || undefined,
          postalCode: contact.address.zip || undefined,
          addressCountry: contact.address.country || undefined,
        })
      : undefined,
    areaServed: contact?.address?.country ? [contact.address.country] : undefined,
  });
}

export function serviceJsonLd(input: {
  name: string;
  description?: string;
  slug: string;
  image?: string;
}): JsonLdObject {
  return stripUndefined({
    "@context": "https://schema.org",
    "@type": "Service",
    name: input.name,
    description: input.description || undefined,
    url: absUrl(`/services/${input.slug}`),
    image: absUrlOpt(input.image),
    provider: {
      "@type": "Organization",
      name: siteConfig.name,
      url: absUrl(siteConfig.url),
      logo: absUrlOpt("/images/logo.png") || absUrlOpt(siteConfig.ogImage),
    },
  });
}

export function articleJsonLd(input: {
  headline: string;
  description?: string;
  slug: string;
  image?: string;
  authorName?: string;
  datePublished?: string; // ISO preferred
  dateModified?: string; // ISO preferred
}): JsonLdObject {
  return stripUndefined({
    "@context": "https://schema.org",
    "@type": "Article",
    headline: input.headline,
    description: input.description || undefined,
    image: absUrlOpt(input.image),
    url: absUrl(`/blog/${input.slug}`),
    datePublished: input.datePublished || undefined,
    dateModified: input.dateModified || undefined,
    author: input.authorName
      ? { "@type": "Person", name: input.authorName }
      : undefined,
    publisher: {
      "@type": "Organization",
      name: siteConfig.name,
      url: absUrl(siteConfig.url),
      logo: {
        "@type": "ImageObject",
        url: absUrlOpt("/images/logo.png") || absUrlOpt(siteConfig.ogImage),
      },
    },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": absUrl(`/blog/${input.slug}`),
    },
  });
}

export function creativeWorkJsonLd(input: {
  name: string;
  description?: string;
  slug: string;
  images?: string[];
}): JsonLdObject {
  const images = input.images?.map((img) => absUrlOpt(img)).filter(Boolean) as
    | string[]
    | undefined;

  return stripUndefined({
    "@context": "https://schema.org",
    "@type": "CreativeWork",
    name: input.name,
    description: input.description || undefined,
    url: absUrl(`/portfolio/${input.slug}`),
    image: images && images.length > 0 ? images : undefined,
    creator: {
      "@type": "Organization",
      name: siteConfig.name,
      url: absUrl(siteConfig.url),
    },
  });
}

export function faqPageJsonLd(input: {
  url: string;
  faqs: { question: string; answer: string }[];
}): JsonLdObject {
  return stripUndefined({
    "@context": "https://schema.org",
    "@type": "FAQPage",
    url: absUrl(input.url),
    mainEntity: input.faqs.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: f.answer,
      },
    })),
  });
}

