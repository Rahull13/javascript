/**
 * Server-side data layer for fetching published blogs from MongoDB.
 * Used by frontend pages (/blog, /blog/[slug]).
 * This file is server-only — never import in Client Components.
 */

import { connectToDatabase } from "./mongodb";
import Blog from "@/models/Blog";
import { cache } from "react";

/* ─── Types ─── */

export interface PublishedBlogListItem {
  slug: string;
  title: string;
  excerpt: string;
  author: string;
  publishedAt: string; // formatted date string e.g. "Dec 06, 2024"
  imageUrl?: string;
  imageAlt?: string;
}

export interface PublishedBlogDetail {
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  publishedAt: string;
  publishedAtIso?: string;
  updatedAtIso?: string;
  imageUrl?: string;
  imageAlt?: string;
  keywords: string[];
  seo?: {
    title?: string;
    description?: string;
    keywords?: string[];
    ogImage?: string;
  };
}

export interface AdjacentPost {
  title: string;
  slug: string;
  imageUrl?: string;
  publishedAt: string;
}

/* ─── Helpers ─── */

function formatDate(date: Date | string): string {
  const d = new Date(date);
  return d.toLocaleDateString("en-US", {
    month: "short",
    day: "2-digit",
    year: "numeric",
  });
}

/* ─── Queries (React-cached for deduplication within a single render) ─── */

/**
 * Fetch all published blogs, sorted by publishedAt (newest first).
 */
export const getPublishedBlogs = cache(
  async (): Promise<PublishedBlogListItem[]> => {
    try {
      await connectToDatabase();
      const blogs = await Blog.find({ status: "published" })
        .sort({ publishedAt: -1, createdAt: -1 })
        .select("slug title excerpt author publishedAt imageUrl imageAlt")
        .lean();

      return blogs.map((b) => ({
        slug: b.slug,
        title: b.title,
        excerpt: b.excerpt ?? "",
        author: b.author ?? "Admin",
        publishedAt: b.publishedAt
          ? formatDate(b.publishedAt)
          : formatDate(b.createdAt),
        imageUrl: b.imageUrl || undefined,
        imageAlt: b.imageAlt || undefined,
      }));
    } catch (error) {
      console.error("Failed to fetch published blogs:", error);
      return [];
    }
  },
);

/**
 * Fetch a single published blog by slug.
 * Returns null if not found or not published.
 */
export const getPublishedBlogBySlug = cache(
  async (slug: string): Promise<PublishedBlogDetail | null> => {
    try {
      await connectToDatabase();
      const blog = await Blog.findOne({ slug, status: "published" })
        .select(
          "slug title excerpt content author publishedAt imageUrl imageAlt keywords seo createdAt updatedAt",
        )
        .lean();

      if (!blog) return null;

      return {
        slug: blog.slug,
        title: blog.title,
        excerpt: blog.excerpt ?? "",
        content: blog.content,
        author: blog.author ?? "Admin",
        publishedAt: blog.publishedAt
          ? formatDate(blog.publishedAt)
          : formatDate(blog.createdAt),
        publishedAtIso: (blog.publishedAt || blog.createdAt)
          ? new Date(blog.publishedAt || blog.createdAt).toISOString()
          : undefined,
        updatedAtIso: blog.updatedAt ? new Date(blog.updatedAt).toISOString() : undefined,
        imageUrl: blog.imageUrl || undefined,
        imageAlt: blog.imageAlt || undefined,
        keywords: blog.keywords ? [...blog.keywords] : [],
        seo: blog.seo
          ? {
              title: blog.seo.title || undefined,
              description: blog.seo.description || undefined,
              keywords:
                blog.seo.keywords && blog.seo.keywords.length > 0
                  ? [...blog.seo.keywords]
                  : undefined,
              ogImage: blog.seo.ogImage || undefined,
            }
          : undefined,
      };
    } catch (error) {
      console.error(`Failed to fetch blog "${slug}":`, error);
      return null;
    }
  },
);

/**
 * Fetch adjacent (prev/next) published blogs relative to a given slug.
 * Used for prev/next navigation on the blog detail page.
 */
export const getAdjacentBlogs = cache(
  async (
    currentSlug: string,
  ): Promise<{ prev: AdjacentPost | null; next: AdjacentPost | null }> => {
    try {
      await connectToDatabase();

      // Get the current blog's publishedAt for comparison
      const current = await Blog.findOne({
        slug: currentSlug,
        status: "published",
      })
        .select("publishedAt createdAt")
        .lean();

      if (!current) return { prev: null, next: null };

      const currentDate = current.publishedAt || current.createdAt;

      // Previous = older (publishedAt < current, ordered desc → first match)
      const prev = await Blog.findOne({
        status: "published",
        slug: { $ne: currentSlug },
        $or: [
          { publishedAt: { $lt: currentDate } },
          {
            publishedAt: currentDate,
            createdAt: { $lt: current.createdAt },
          },
        ],
      })
        .sort({ publishedAt: -1, createdAt: -1 })
        .select("slug title imageUrl publishedAt createdAt")
        .lean();

      // Next = newer (publishedAt > current, ordered asc → first match)
      const next = await Blog.findOne({
        status: "published",
        slug: { $ne: currentSlug },
        $or: [
          { publishedAt: { $gt: currentDate } },
          {
            publishedAt: currentDate,
            createdAt: { $gt: current.createdAt },
          },
        ],
      })
        .sort({ publishedAt: 1, createdAt: 1 })
        .select("slug title imageUrl publishedAt createdAt")
        .lean();

      return {
        prev: prev
          ? {
              title: prev.title,
              slug: prev.slug,
              imageUrl: prev.imageUrl || undefined,
              publishedAt: prev.publishedAt
                ? formatDate(prev.publishedAt)
                : formatDate(prev.createdAt),
            }
          : null,
        next: next
          ? {
              title: next.title,
              slug: next.slug,
              imageUrl: next.imageUrl || undefined,
              publishedAt: next.publishedAt
                ? formatDate(next.publishedAt)
                : formatDate(next.createdAt),
            }
          : null,
      };
    } catch (error) {
      console.error("Failed to fetch adjacent blogs:", error);
      return { prev: null, next: null };
    }
  },
);

/**
 * Fetch recent published blogs (excluding a given slug).
 * Used for "Recent Posts" sidebar on blog detail page.
 */
export const getRecentBlogs = cache(
  async (
    excludeSlug: string,
    limit = 3,
  ): Promise<
    { title: string; slug: string; imageUrl?: string; publishedAt: string }[]
  > => {
    try {
      await connectToDatabase();
      const blogs = await Blog.find({
        status: "published",
        slug: { $ne: excludeSlug },
      })
        .sort({ publishedAt: -1, createdAt: -1 })
        .limit(limit)
        .select("slug title imageUrl publishedAt createdAt")
        .lean();

      return blogs.map((b) => ({
        title: b.title,
        slug: b.slug,
        imageUrl: b.imageUrl || undefined,
        publishedAt: b.publishedAt
          ? formatDate(b.publishedAt)
          : formatDate(b.createdAt),
      }));
    } catch (error) {
      console.error("Failed to fetch recent blogs:", error);
      return [];
    }
  },
);
