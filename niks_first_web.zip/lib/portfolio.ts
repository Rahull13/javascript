/**
 * Server-side data layer for fetching published portfolios from MongoDB.
 * Used by frontend pages (/portfolio, /portfolio/[slug]).
 * This file is server-only — never import in Client Components.
 */

import { connectToDatabase } from "./mongodb";
import Portfolio from "@/models/Portfolio";
import { cache } from "react";

/* ─── Types ─── */

export interface PortfolioImage {
  url: string;
  publicId?: string;
  alt?: string;
}

export interface PublishedPortfolioListItem {
  slug: string;
  title: string;
  description: string;
  client: string;
  industry: string;
  coverImage: string; // first image URL or placeholder
  images: PortfolioImage[];
}

export interface PublishedPortfolioDetail {
  slug: string;
  title: string;
  description: string;
  client: string;
  industry: string;
  images: PortfolioImage[];
  seo?: {
    title?: string;
    description?: string;
    keywords?: string[];
    ogImage?: string;
  };
}

/* ─── Queries (React-cached for deduplication within a single render) ─── */

/**
 * Fetch all published portfolio items, sorted by creation date (newest first).
 */
export const getPublishedPortfolios = cache(
  async (): Promise<PublishedPortfolioListItem[]> => {
    try {
      await connectToDatabase();
      const portfolios = await Portfolio.find({ status: "published" })
        .sort({ createdAt: -1 })
        .select("slug title description client industry images")
        .lean();

      return portfolios.map((p) => {
        const imgs = p.images
          ? p.images.map((img: any) => ({
              url: img.url ?? "",
              publicId: img.publicId || undefined,
              alt: img.alt || undefined,
            }))
          : [];

        return {
          slug: p.slug,
          title: p.title,
          description: p.description ?? "",
          client: p.client ?? "",
          industry: p.industry ?? "",
          coverImage:
            imgs.length > 0 ? imgs[0].url : "/images/portfolio/portfolio-1.jpg",
          images: imgs,
        };
      });
    } catch (error) {
      console.error("Failed to fetch published portfolios:", error);
      return [];
    }
  },
);

/**
 * Fetch a single published portfolio by slug.
 * Returns null if not found or not published.
 */
export const getPublishedPortfolioBySlug = cache(
  async (slug: string): Promise<PublishedPortfolioDetail | null> => {
    try {
      await connectToDatabase();
      const portfolio = await Portfolio.findOne({
        slug,
        status: "published",
      })
        .select("slug title description client industry images seo")
        .lean();

      if (!portfolio) return null;

      return {
        slug: portfolio.slug,
        title: portfolio.title,
        description: portfolio.description ?? "",
        client: portfolio.client ?? "",
        industry: portfolio.industry ?? "",
        images: portfolio.images
          ? portfolio.images.map((img: any) => ({
              url: img.url ?? "",
              publicId: img.publicId || undefined,
              alt: img.alt || undefined,
            }))
          : [],
        seo: portfolio.seo
          ? {
              title: portfolio.seo.title || undefined,
              description: portfolio.seo.description || undefined,
              keywords:
                portfolio.seo.keywords && portfolio.seo.keywords.length > 0
                  ? [...portfolio.seo.keywords]
                  : undefined,
              ogImage: portfolio.seo.ogImage || undefined,
            }
          : undefined,
      };
    } catch (error) {
      console.error(`Failed to fetch portfolio "${slug}":`, error);
      return null;
    }
  },
);

/**
 * Get unique industries from published portfolios (for filter tabs).
 */
export const getPortfolioIndustries = cache(
  async (): Promise<string[]> => {
    try {
      await connectToDatabase();
      const industries = await Portfolio.distinct("industry", {
        status: "published",
        industry: { $ne: "" },
      });
      return industries.sort();
    } catch (error) {
      console.error("Failed to fetch portfolio industries:", error);
      return [];
    }
  },
);
