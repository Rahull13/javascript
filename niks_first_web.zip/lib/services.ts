/**
 * Server-side data layer for fetching published services from MongoDB.
 * Used by frontend pages (/services, /services/[slug]).
 * This file is server-only — never import in Client Components.
 */

import { connectToDatabase } from "./mongodb";
import Service from "@/models/Service";
import { cache } from "react";

/* ─── Types ─── */

export interface PublishedServiceListItem {
  slug: string;
  title: string;
  category: string;
  summary: string;
  imageUrl?: string;
  imageAlt?: string;
}

export interface PublishedServiceDetail {
  slug: string;
  title: string;
  category: string;
  summary: string;
  content: string;
  imageUrl?: string;
  imageAlt?: string;
  seo?: {
    title?: string;
    description?: string;
    keywords?: string[];
    ogImage?: string;
  };
}

/* ─── Default service icons (fallback when no image uploaded) ─── */
const DEFAULT_ICONS = [
  "/images/icons/si-1.png",
  "/images/icons/si-2.png",
  "/images/icons/si-3.png",
  "/images/icons/si-4.png",
];

export function getDefaultIcon(index: number): string {
  return DEFAULT_ICONS[index % DEFAULT_ICONS.length];
}

/* ─── Queries (React-cached for deduplication within a single render) ─── */

/**
 * Fetch all published services, sorted by creation date (newest first).
 */
export const getPublishedServices = cache(
  async (): Promise<PublishedServiceListItem[]> => {
    try {
      await connectToDatabase();
      const services = await Service.find({ status: "published" })
        .sort({ createdAt: -1 })
        .select("slug title category summary imageUrl imageAlt")
        .lean();

      return services.map((s) => ({
        slug: s.slug,
        title: s.title,
        category: s.category,
        summary: s.summary,
        imageUrl: s.imageUrl || undefined,
        imageAlt: s.imageAlt || undefined,
      }));
    } catch (error) {
      console.error("Failed to fetch published services:", error);
      return [];
    }
  },
);

/**
 * Fetch a single published service by slug.
 * Returns null if not found or not published.
 */
export const getPublishedServiceBySlug = cache(
  async (slug: string): Promise<PublishedServiceDetail | null> => {
    try {
      await connectToDatabase();
      const service = await Service.findOne({
        slug,
        status: "published",
      })
        .select(
          "slug title category summary content imageUrl imageAlt seo",
        )
        .lean();

      if (!service) return null;

      return {
        slug: service.slug,
        title: service.title,
        category: service.category,
        summary: service.summary,
        content: service.content,
        imageUrl: service.imageUrl || undefined,
        imageAlt: service.imageAlt || undefined,
        seo: service.seo
          ? {
              title: service.seo.title || undefined,
              description: service.seo.description || undefined,
              keywords:
                service.seo.keywords && service.seo.keywords.length > 0
                  ? service.seo.keywords
                  : undefined,
              ogImage: service.seo.ogImage || undefined,
            }
          : undefined,
      };
    } catch (error) {
      console.error(`Failed to fetch service "${slug}":`, error);
      return null;
    }
  },
);
