/**
 * SEO Utility Usage Examples
 * 
 * This file demonstrates how to use the SEO utility functions
 * in your Next.js pages and components.
 */

import { Metadata } from "next";
import {
  generateMetadata,
  generateKeywordMetaTags,
  generateAISummary,
  generateFAQSchema,
  generateFAQHTML,
  generateSEOComponents,
  type SEOData,
  type FAQItem,
} from "@/lib/seo";
import { siteConfig } from "@/config/site";

// ============================================================================
// Example 1: Basic Page Metadata
// ============================================================================

export async function example1_BasicMetadata(): Promise<Metadata> {
  const seoData: SEOData = {
    title: "Our Services | Moonrock Fintax",
    description: "Comprehensive financial consulting and tax advisory services",
    keywords: ["financial services", "tax consulting", "business advisory"],
    url: `${siteConfig.url}/services`,
  };

  return generateMetadata(seoData);
}

// ============================================================================
// Example 2: Article/Blog Post with Dates
// ============================================================================

export async function example2_ArticleMetadata(): Promise<Metadata> {
  const seoData: SEOData = {
    title: "Tax Planning Strategies for 2024",
    description: "Expert tips on tax planning strategies to maximize your savings",
    keywords: ["tax planning", "tax strategies", "financial planning"],
    type: "article",
    publishedTime: "2024-01-15T10:00:00Z",
    modifiedTime: "2024-01-20T14:30:00Z",
    url: `${siteConfig.url}/blog/tax-planning-strategies-2024`,
  };

  return generateMetadata(seoData);
}

// ============================================================================
// Example 3: Keyword Meta Tags (Client Component)
// ============================================================================

export function example3_KeywordTags() {
  const keywords = ["tax planning", "financial consulting", "business advisory"];
  const keywordTags = generateKeywordMetaTags(keywords);

  return (
    <>
      {keywordTags}
      {/* Rest of your component */}
    </>
  );
}

// ============================================================================
// Example 4: AI-Search Summary
// ============================================================================

export function example4_AISummary() {
  return generateAISummary({
    title: "Tax Planning Services",
    description: "Expert tax planning to minimize your tax burden",
    summary: "Our tax planning services help businesses and individuals reduce tax liability through strategic planning, compliance management, and optimization techniques. We analyze your financial situation to identify opportunities for tax savings while ensuring full regulatory compliance.",
    keywords: ["tax planning", "tax optimization", "tax compliance"],
    url: `${siteConfig.url}/services/tax-planning`,
    type: "Service",
  });
}

// ============================================================================
// Example 5: FAQ Schema Only
// ============================================================================

export function example5_FAQSchema() {
  const faqs: FAQItem[] = [
    {
      question: "What is tax planning?",
      answer: "Tax planning is the process of analyzing your financial situation to minimize tax liability while ensuring compliance with tax laws.",
    },
    {
      question: "How much can I save with tax planning?",
      answer: "Tax savings vary based on individual circumstances, but our clients typically save 15-30% on their tax liability.",
    },
  ];

  return generateFAQSchema(faqs, `${siteConfig.url}/services/tax-planning`);
}

// ============================================================================
// Example 6: FAQ HTML with Schema Markup
// ============================================================================

export function example6_FAQHTML() {
  const faqs: FAQItem[] = [
    {
      question: "What services do you offer?",
      answer: "We offer comprehensive financial consulting, tax planning, business advisory, and accounting services.",
    },
    {
      question: "How do I get started?",
      answer: "Contact us for a free consultation to discuss your financial needs and goals.",
    },
  ];

  return (
    <section className="py-12">
      <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
      {generateFAQHTML(faqs)}
    </section>
  );
}

// ============================================================================
// Example 7: Complete SEO Setup (Recommended)
// ============================================================================

export async function example7_CompleteSEO() {
  const seoData: SEOData = {
    title: "Tax Planning Services | Moonrock Fintax",
    description: "Expert tax planning services to minimize your tax burden",
    summary: "Our comprehensive tax planning services help businesses and individuals reduce tax liability through strategic planning, compliance management, and optimization techniques. We analyze your financial situation to identify opportunities for tax savings while ensuring full regulatory compliance with federal, state, and local tax laws.",
    keywords: ["tax planning", "tax optimization", "tax compliance", "tax strategy"],
    url: `${siteConfig.url}/services/tax-planning`,
    type: "service",
  };

  const faqs: FAQItem[] = [
    {
      question: "What is included in tax planning services?",
      answer: "Tax planning includes strategic analysis, quarterly planning, compliance review, and optimization recommendations tailored to your situation.",
    },
    {
      question: "How long does tax planning take?",
      answer: "The timeline varies based on complexity, but we typically provide initial recommendations within 2-3 weeks of consultation.",
    },
  ];

  const geoConfig = {
    defaultLocation: "US",
    modifierPrefix: "geo",
  };

  const seo = generateSEOComponents({
    ...seoData,
    faqs,
    geoConfig,
  });

  // In your page component:
  return {
    metadata: seo.metadata, // Export this as metadata
    // In your JSX:
    // {seo.keywordTags}
    // {seo.aiSummary}
    // {seo.faqSchema}
    // {seo.faqHTML}
  };
}

// ============================================================================
// Example 8: Page Component Usage
// ============================================================================

// app/services/tax-planning/page.tsx
//
// import { Metadata } from "next";
// import { generateSEOComponents, type SEOData, type FAQItem } from "@/lib/seo";
// import { siteConfig } from "@/config/site";
//
// // Fetch your data
// async function getServiceData() {
//   // ... fetch from database
//   return {
//     title: "Tax Planning Services",
//     description: "Expert tax planning...",
//     summary: "Comprehensive tax planning...",
//     keywords: ["tax planning", "tax optimization"],
//     slug: "tax-planning",
//   };
// }
//
// export async function generateMetadata(): Promise<Metadata> {
//   const data = await getServiceData();
//   const seoData: SEOData = { ... };
//   const seo = generateSEOComponents({ ...seoData });
//   return seo.metadata;
// }
//
// export default async function TaxPlanningPage() {
//   const data = await getServiceData();
//   const seo = generateSEOComponents({ ...seoData, faqs });
//   return (
//     <>
//       {seo.keywordTags}
//       {seo.aiSummary}
//       {seo.faqSchema}
//       <article><h1>{data.title}</h1></article>
//       <section>{seo.faqHTML}</section>
//     </>
//   );
// }

