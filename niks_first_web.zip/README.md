# Moonrock Fintax Consulting Website

A modern, professional Next.js website for Moonrock Fintax Consulting - a financial and tax advisory firm. Built with TypeScript, Tailwind CSS, and Next.js 16 with App Router.

## Features

- ✅ **Modern UI/UX Design** - Beautiful, responsive design with gradients, animations, and smooth transitions
- ✅ **SEO Optimized** - Complete SEO setup with metadata, sitemap, robots.txt, and structured data
- ✅ **Marketing Focused** - Content optimized for conversions with clear CTAs and value propositions
- ✅ **Fully Responsive** - Mobile-first design that works perfectly on all devices
- ✅ **TypeScript** - Type-safe codebase for better development experience
- ✅ **Performance Optimized** - Fast loading times with Next.js optimizations

## Pages

- **Homepage** (`/`) - Hero section, services overview, features, and CTAs
- **Services** (`/services`) - Overview of all services offered
- **Individual Service Pages** (`/services/[service-name]`) - Detailed service pages
- **About** (`/about`) - Company story, values, mission, and vision
- **Resources** (`/resources`) - Financial guides, tools, and articles
- **Contact** (`/contact`) - Contact form and business information

## Getting Started

### Prerequisites

- Node.js 18+ installed
- npm or yarn package manager

### Installation

1. Navigate to the project directory:
```bash
cd moonrock-fintax
```

2. Install dependencies:
```bash
npm install
```

3. Run the development server:
```bash
npm run dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

### Build for Production

```bash
npm run build
npm start
```

## Project Structure

```
moonrock-fintax/
├── app/
│   ├── components/          # Reusable components
│   │   ├── Header.tsx      # Navigation header
│   │   └── Footer.tsx      # Site footer
│   ├── services/           # Service pages
│   │   ├── page.tsx        # Services overview
│   │   └── tax-planning/   # Individual service pages
│   ├── about/              # About page
│   ├── contact/            # Contact page
│   ├── resources/          # Resources page
│   ├── layout.tsx          # Root layout with SEO
│   ├── page.tsx            # Homepage
│   ├── globals.css         # Global styles
│   ├── sitemap.ts          # Sitemap generation
│   └── robots.ts           # Robots.txt
├── public/                 # Static assets
└── package.json
```

## SEO Features

- **Metadata**: Comprehensive metadata for all pages
- **Sitemap**: Auto-generated sitemap.xml
- **Robots.txt**: Search engine directives
- **Open Graph**: Social media sharing optimization
- **Structured Data**: Ready for schema markup
- **Semantic HTML**: Proper HTML5 semantic elements

## Customization

### Update Company Information

1. **Contact Details**: Update in `app/components/Header.tsx` and `app/components/Footer.tsx`
2. **Business Address**: Update in `app/components/Footer.tsx` and `app/contact/page.tsx`
3. **Social Media**: Update links in `app/components/Footer.tsx`

### Update Content

- Homepage: `app/page.tsx`
- Services: `app/services/page.tsx`
- About: `app/about/page.tsx`
- Contact: `app/contact/page.tsx`

### Update SEO Metadata

- Root metadata: `app/layout.tsx`
- Page-specific metadata: Each page's `metadata` export

### Colors & Styling

- Primary colors: Blue (#2563eb) and Purple (#9333ea)
- Update in Tailwind classes throughout components
- Global styles: `app/globals.css`

## Technologies Used

- **Next.js 16** - React framework with App Router
- **TypeScript** - Type safety
- **Tailwind CSS** - Utility-first CSS framework
- **Lucide React** - Icon library
- **Framer Motion** - Animation library (installed, ready to use)

## Performance

- Optimized images with Next.js Image component
- Code splitting and lazy loading
- Minimal JavaScript bundle
- Fast page loads with static generation

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Deployment

### Vercel (Recommended)

1. Push code to GitHub
2. Import project in Vercel
3. Deploy automatically

### Other Platforms

The site can be deployed to any platform that supports Next.js:
- Netlify
- AWS Amplify
- DigitalOcean App Platform
- Self-hosted with Node.js

## License

© 2024 Moonrock Fintax Consulting. All rights reserved.

## Support

For questions or support, contact: info@moonrockfintax.com
