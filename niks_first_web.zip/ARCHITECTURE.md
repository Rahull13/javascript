# Moonrock Fintax Consulting - Architecture Documentation

## Folder Structure

```
moonrock-fintax/
├── app/                          # Next.js App Router
│   ├── (public)/                 # Public routes group
│   │   ├── page.tsx              # Homepage
│   │   ├── about/
│   │   ├── services/
│   │   ├── resources/
│   │   └── contact/
│   ├── (admin)/                  # Admin routes group
│   │   ├── dashboard/
│   │   ├── clients/
│   │   ├── projects/
│   │   └── settings/
│   ├── api/                      # API routes
│   │   ├── auth/
│   │   ├── clients/
│   │   └── projects/
│   ├── components/               # App-specific components
│   │   ├── layout/               # Layout components
│   │   │   ├── Header.tsx
│   │   │   ├── Footer.tsx
│   │   │   └── Sidebar.tsx
│   │   └── blocks/                # Reusable content blocks
│   │       ├── CTA.tsx
│   │       ├── Hero.tsx
│   │       └── Stats.tsx
│   ├── layout.tsx                # Root layout
│   ├── globals.css               # Global styles + design tokens
│   ├── sitemap.ts                # SEO sitemap
│   └── robots.ts                 # SEO robots.txt
│
├── components/                   # Shared components
│   ├── ui/                       # shadcn/ui components
│   │   ├── button.tsx
│   │   ├── card.tsx
│   │   └── ...
│   └── providers/                # Context providers
│       └── theme-provider.tsx
│
├── lib/                          # Utility libraries
│   ├── utils.ts                  # Utility functions
│   ├── constants.ts              # App constants
│   ├── validations.ts            # Zod schemas
│   └── api/                      # API client functions
│       ├── client.ts
│       └── endpoints.ts
│
├── hooks/                        # Custom React hooks
│   ├── use-media-query.ts
│   └── use-scroll-position.ts
│
├── types/                        # TypeScript types
│   ├── index.ts
│   ├── client.ts
│   └── api.ts
│
├── config/                       # Configuration files
│   ├── site.ts                   # Site metadata
│   └── routes.ts                 # Route definitions
│
└── public/                       # Static assets
    ├── images/
    ├── icons/
    └── fonts/
```

## Routing Strategy

### Public Routes (`(public)`)
- `/` - Homepage
- `/about` - About page
- `/services` - Services listing
- `/services/[slug]` - Individual service pages
- `/resources` - Resources/blog
- `/resources/[slug]` - Individual resource pages
- `/contact` - Contact page

### Admin Routes (`(admin)`)
- `/dashboard` - Admin dashboard
- `/dashboard/clients` - Client management
- `/dashboard/clients/[id]` - Client detail
- `/dashboard/projects` - Project management
- `/dashboard/projects/[id]` - Project detail
- `/dashboard/settings` - Settings

### API Routes (`api/`)
- `/api/auth/*` - Authentication endpoints
- `/api/clients/*` - Client CRUD operations
- `/api/projects/*` - Project CRUD operations
- `/api/analytics/*` - Analytics endpoints

## Design System

### Colors
- **Primary**: Blue (#2563eb) - Main brand color
- **Secondary**: Purple (#9333ea) - Accent color
- **Neutral**: Gray scale for text and backgrounds
- **Semantic**: Success, Error, Warning, Info

### Typography Scale
- Display 1: 3.75rem (60px) - Hero headlines
- Display 2: 3rem (48px) - Section headlines
- Heading 1: 2.25rem (36px) - Page titles
- Heading 2: 1.875rem (30px) - Section titles
- Heading 3: 1.5rem (24px) - Subsection titles
- Body Large: 1.25rem (20px) - Large body text
- Body: 1rem (16px) - Default body text
- Body Small: 0.875rem (14px) - Small body text
- Caption: 0.75rem (12px) - Captions and labels

### Spacing Scale
- xs: 0.25rem (4px)
- sm: 0.5rem (8px)
- md: 1rem (16px)
- lg: 1.5rem (24px)
- xl: 2rem (32px)
- 2xl: 3rem (48px)
- 3xl: 4rem (64px)

### Border Radius
- sm: 0.25rem (4px)
- md: 0.5rem (8px)
- lg: 1rem (16px)
- xl: 1.5rem (24px)
- full: 9999px

## Component Architecture

### Layout Components
- **Header**: Main navigation with mobile menu
- **Footer**: Site footer with links and info
- **Sidebar**: Admin sidebar navigation

### Block Components
- **Hero**: Hero section with CTA
- **CTA**: Call-to-action blocks
- **Stats**: Statistics display
- **Features**: Feature grid
- **Testimonials**: Testimonial carousel

### UI Components (shadcn/ui)
- Button, Card, Input, Select, etc.
- All components are composable and accessible

## State Management

- **Server State**: React Server Components + Server Actions
- **Client State**: React hooks (useState, useReducer)
- **Global State**: Context API (if needed)
- **Form State**: React Hook Form + Zod validation

## Performance Optimizations

- Image optimization with Next.js Image
- Code splitting with dynamic imports
- Static generation where possible
- ISR for dynamic content
- Edge caching for API routes

## SEO Strategy

- Metadata API for all pages
- Structured data (JSON-LD)
- Sitemap generation
- Robots.txt configuration
- Open Graph tags
- Twitter Cards

