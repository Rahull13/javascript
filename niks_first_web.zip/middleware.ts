import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // 1️⃣ Exclude public admin pages (login, forgot-password)
  if (pathname === "/admin/login") {
    // Add pathname to headers so server components can access it
    const response = NextResponse.next();
    response.headers.set("x-pathname", pathname);
    return response;
  }

  // 2️⃣ Protect all other admin routes
  // Note: We do a basic cookie check here, but the admin layout will do a proper session check
  if (pathname.startsWith("/admin")) {
    // Check for any NextAuth session cookie
    const hasSessionCookie = 
      request.cookies.has("next-auth.session-token") ||
      request.cookies.has("__Secure-next-auth.session-token") ||
      request.cookies.has("authjs.session-token") ||
      request.cookies.has("__Secure-authjs.session-token");

    // If no session cookie at all, redirect to login
    // The admin layout will do a proper session validation
    if (!hasSessionCookie) {
      return NextResponse.redirect(
        new URL("/admin/login", request.url)
      );
    }
    
    // Add pathname to headers for other admin routes
    const response = NextResponse.next();
    response.headers.set("x-pathname", pathname);
    return response;
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*"],
};
