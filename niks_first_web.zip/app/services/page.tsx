/**
 * Services Listing Page — /services
 * Fetches published services from MongoDB and displays them in a grid.
 * Falls back gracefully when no services are available.
 */

import type { Metadata } from "next";
import { Breadcrumb } from "@/app/components/ui/Breadcrumb";
import { ServicesGrid } from "@/app/components/sections/ServicesGrid";
import { ServicesCTA } from "@/app/components/sections/ServicesCTA";
import { ClientLogos } from "@/app/components/sections/ClientLogos";
import { getPublishedServices } from "@/lib/services";

export const runtime = "nodejs";

export const metadata: Metadata = {
  title: "Our Services",
  description:
    "Explore our full range of video production services including motion graphics, scriptwriting, distribution, and hosting.",
};

export default async function ServicesPage() {
  const services = await getPublishedServices();

  return (
    <>
      {/* Breadcrumb Hero Banner */}
      <Breadcrumb
        title="Our Services"
        items={[
          { label: "Home", href: "/" },
          { label: "Services" },
        ]}
      />

      {/* Services Grid — dynamic from MongoDB */}
      <ServicesGrid services={services} />

      {/* CTA Banner (centered, contained background) */}
      <ServicesCTA />

      {/* Client / Partner Logos Carousel */}
      <ClientLogos />
    </>
  );
}
