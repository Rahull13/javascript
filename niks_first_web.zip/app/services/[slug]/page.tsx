/**
 * Service Detail Page — /services/[slug]
 * Fetches a single published service from MongoDB by slug.
 * Returns 404 if the service doesn't exist or is in draft status.
 */

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Breadcrumb } from "@/app/components/ui/Breadcrumb";
import { ServiceDetailContent } from "@/app/components/sections/ServiceDetailContent";
import { RelatedServices } from "@/app/components/sections/RelatedServices";
import { ServicesCTA } from "@/app/components/sections/ServicesCTA";
import { JsonLd } from "@/app/components/seo/JsonLd";
import {
  getPublishedServiceBySlug,
  getPublishedServices,
} from "@/lib/services";
import { generateMetadata as buildMetadata } from "@/lib/seo";
import { siteConfig } from "@/config/site";
import { serviceJsonLd } from "@/lib/structured-data";

export const runtime = "nodejs";

interface ServiceDetailPageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata(
  props: ServiceDetailPageProps,
): Promise<Metadata> {
  const { slug } = await props.params;
  const service = await getPublishedServiceBySlug(slug);
  if (!service) return {};

  const title = service.seo?.title || service.title;
  const description = service.seo?.description || service.summary || undefined;
  const keywords = service.seo?.keywords || undefined;
  const image = service.seo?.ogImage || service.imageUrl || siteConfig.ogImage;

  return buildMetadata({
    title,
    description,
    keywords,
    image,
    url: `${siteConfig.url}/services/${service.slug}`,
    type: "service",
  });
}

export default async function ServiceDetailPage({
  params,
}: ServiceDetailPageProps) {
  const { slug } = await params;
  const service = await getPublishedServiceBySlug(slug);

  if (!service) {
    notFound();
  }

  // Fetch other published services for the "Related" section (exclude current)
  const allServices = await getPublishedServices();
  const relatedServices = allServices
    .filter((s) => s.slug !== slug)
    .slice(0, 3);

  return (
    <>
      <JsonLd
        data={serviceJsonLd({
          name: service.title,
          description: service.seo?.description || service.summary || undefined,
          slug: service.slug,
          image: service.seo?.ogImage || service.imageUrl || siteConfig.ogImage,
        })}
      />
      {/* Breadcrumb Hero Banner */}
      <Breadcrumb
        title={service.title}
        items={[
          { label: "Home", href: "/" },
          { label: "Services", href: "/services" },
          { label: service.title },
        ]}
      />

      {/* Service Detail Content */}
      <ServiceDetailContent service={service} />

      {/* CTA Banner */}
      <ServicesCTA />

      {/* Related / Other Services */}
      <RelatedServices services={relatedServices} />
    </>
  );
}
