import { Metadata } from 'next';
import Link from 'next/link';
import { CheckCircle, Calculator, FileText, Shield, TrendingUp, ArrowRight, Phone } from 'lucide-react';

export const metadata: Metadata = {
  title: "Tax Planning & Preparation Services | Moonrock Fintax",
  description: "Expert tax planning and preparation services for individuals and businesses. Minimize tax liabilities, maximize savings, and ensure full compliance with our comprehensive tax solutions.",
  keywords: ["tax planning", "tax preparation", "tax services", "tax strategy", "tax compliance", "IRS audit support"],
};

export default function TaxPlanningPage() {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Tax Planning & Preparation Services
            </h1>
            <p className="text-xl text-blue-100">
              Strategic tax planning to minimize liabilities and maximize your savings while ensuring full compliance
            </p>
          </div>
        </div>
      </section>

      {/* Overview Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="prose prose-lg max-w-none">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Comprehensive Tax Solutions</h2>
              <p className="text-lg text-gray-600 mb-6">
                At Moonrock Fintax, we understand that effective tax planning is crucial for both individuals and businesses. Our team of certified tax professionals works year-round to help you minimize your tax burden while ensuring full compliance with all federal, state, and local tax regulations.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                Whether you're an individual looking to optimize your personal tax situation or a business seeking strategic tax planning, we provide personalized solutions tailored to your unique circumstances and financial goals.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Offered */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-12 text-center">
              Our Tax Planning Services
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {taxServices.map((service, index) => (
                <div key={index} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center text-white mb-4">
                    {service.icon}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                  <p className="text-gray-600">{service.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8 text-center">
              Why Choose Our Tax Planning Services?
            </h2>
            <div className="space-y-4">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-start gap-4 bg-white border-2 border-gray-100 rounded-xl p-6 hover:border-blue-200 transition-all">
                  <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2">{benefit.title}</h3>
                    <p className="text-gray-600">{benefit.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-12 text-center">
              Our Tax Planning Process
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {processSteps.map((step, index) => (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">
                    {index + 1}
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-white text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Ready to Optimize Your Tax Strategy?
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              Schedule a free consultation with our tax experts today
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/contact"
                className="inline-block bg-white text-blue-600 px-8 py-4 rounded-full font-semibold hover:shadow-xl transition-all transform hover:scale-105"
              >
                Get Free Consultation
              </Link>
              <a
                href="tel:+1234567890"
                className="inline-flex items-center justify-center gap-2 border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition-all"
              >
                <Phone className="w-5 h-5" />
                Call Us Now
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

const taxServices = [
  {
    icon: <Calculator className="w-6 h-6" />,
    title: "Individual Tax Returns",
    description: "Comprehensive preparation and filing of individual tax returns with maximum deductions."
  },
  {
    icon: <FileText className="w-6 h-6" />,
    title: "Business Tax Returns",
    description: "Expert handling of corporate, partnership, and LLC tax returns."
  },
  {
    icon: <TrendingUp className="w-6 h-6" />,
    title: "Tax Strategy Development",
    description: "Year-round tax planning to minimize liabilities and maximize savings."
  },
  {
    icon: <Shield className="w-6 h-6" />,
    title: "IRS Audit Support",
    description: "Professional representation and support during IRS audits and inquiries."
  },
  {
    icon: <FileText className="w-6 h-6" />,
    title: "Quarterly Tax Planning",
    description: "Ongoing tax planning throughout the year to avoid surprises."
  },
  {
    icon: <CheckCircle className="w-6 h-6" />,
    title: "Tax Compliance Review",
    description: "Comprehensive review to ensure full compliance with all tax regulations."
  }
];

const benefits = [
  {
    title: "Maximize Your Savings",
    description: "Our strategic approach helps identify all eligible deductions and credits to minimize your tax burden."
  },
  {
    title: "Ensure Compliance",
    description: "Stay compliant with all federal, state, and local tax regulations with our expert guidance."
  },
  {
    title: "Year-Round Support",
    description: "We're here for you throughout the year, not just during tax season, providing ongoing tax planning."
  },
  {
    title: "Expert Knowledge",
    description: "Our certified tax professionals stay current with the latest tax laws and regulations."
  },
  {
    title: "Peace of Mind",
    description: "Rest easy knowing your taxes are handled by experienced professionals who prioritize accuracy."
  }
];

const processSteps = [
  {
    title: "Initial Consultation",
    description: "We review your financial situation and tax history"
  },
  {
    title: "Strategy Development",
    description: "We create a customized tax planning strategy"
  },
  {
    title: "Implementation",
    description: "We help you implement tax-saving strategies"
  },
  {
    title: "Ongoing Support",
    description: "We provide year-round support and adjustments"
  }
];

