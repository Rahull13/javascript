"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Menu, X, ChevronDown } from "lucide-react";
import { NAV_ITEMS, SOCIAL_LINKS } from "@/config/navigation";
import { SocialIcons } from "@/app/components/ui/SocialIcons";

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState<string | null>(null);

  return (
    <header className="absolute left-0 top-0 w-full bg-transparent border-b border-white/10 z-50">
      <div className="container mx-auto">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="py-7">
            <Link href="/">
              <Image
                src="/images/logo.png"
                alt="Videograph"
                width={130}
                height={30}
                priority
              />
            </Link>
          </div>

          {/* Desktop Navigation + Social */}
          <div className="hidden lg:flex items-center gap-0">
            <nav className="inline-flex mr-10">
              <ul className="flex items-center gap-10">
                {NAV_ITEMS.map((item) => (
                  <li
                    key={item.title}
                    className="relative group"
                    onMouseEnter={() =>
                      item.children ? setDropdownOpen(item.title) : undefined
                    }
                    onMouseLeave={() => setDropdownOpen(null)}
                  >
                    <Link
                      href={item.href}
                      className="text-[15px] font-heading text-white uppercase block py-1.5 relative
                        after:absolute after:left-0 after:bottom-0 after:w-full after:h-[2px]
                        after:bg-vg-primary after:scale-x-0 after:origin-left
                        after:transition-transform after:duration-300
                        hover:after:scale-x-100"
                    >
                      {item.title}
                      {item.children && (
                        <ChevronDown className="inline w-3 h-3 ml-1" />
                      )}
                    </Link>

                    {/* Dropdown */}
                    {item.children && dropdownOpen === item.title && (
                      <ul className="absolute left-0 top-full mt-0 w-40 bg-white py-1 shadow-lg z-50">
                        {item.children.map((child) => (
                          <li key={child.title}>
                            <Link
                              href={child.href}
                              className="block px-5 py-2 text-sm text-[#111] capitalize hover:text-vg-primary transition-colors"
                            >
                              {child.title}
                            </Link>
                          </li>
                        ))}
                      </ul>
                    )}
                  </li>
                ))}
              </ul>
            </nav>

            {/* Divider + Social */}
            <div className="relative pl-12 before:absolute before:left-0 before:top-1 before:h-3 before:w-px before:bg-white/20">
              <SocialIcons links={SOCIAL_LINKS} />
            </div>
          </div>

          {/* Mobile Toggle */}
          <button
            className="lg:hidden text-white p-2"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <div className="lg:hidden bg-[#222] py-4 px-4 -mx-4 animate-fade-in">
            <ul className="flex flex-col gap-1">
              {NAV_ITEMS.map((item) => (
                <li key={item.title}>
                  <Link
                    href={item.href}
                    className="block py-2 text-white font-semibold text-sm uppercase"
                    onClick={() => setMobileOpen(false)}
                  >
                    {item.title}
                  </Link>
                  {item.children && (
                    <ul className="pl-6 pb-2">
                      {item.children.map((child) => (
                        <li key={child.title}>
                          <Link
                            href={child.href}
                            className="block py-1.5 text-white/70 text-sm"
                            onClick={() => setMobileOpen(false)}
                          >
                            {child.title}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  )}
                </li>
              ))}
            </ul>
            <div className="mt-4 pt-4 border-t border-white/10">
              <SocialIcons links={SOCIAL_LINKS} />
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
