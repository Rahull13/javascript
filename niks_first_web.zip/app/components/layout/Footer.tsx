/**
 * Footer — Site footer matching Videograph theme
 * Server Component
 */

import Link from "next/link";
import Image from "next/image";
import { siteConfig } from "@/config/site";
import { SOCIAL_LINKS } from "@/config/navigation";
import { FOOTER_WHO_WE_ARE, FOOTER_OUR_WORK } from "@/lib/constants";
import { SocialIcons } from "@/app/components/ui/SocialIcons";
import { NewsletterForm } from "@/app/components/ui/NewsletterForm";

export function Footer() {
  return (
    <footer className="bg-vg-darker" style={{ backgroundColor: '#0a0119' }}>
      <div className="container mx-auto">
        {/* Top Bar: Logo + Social */}
        <div className="flex flex-col md:flex-row items-center justify-between py-7 border-b border-white/10">
          <div className="mb-4 md:mb-0">
            <Link href="/">
              <Image
                src="/images/logo.png"
                alt={siteConfig.shortName}
                width={130}
                height={30}
              />
            </Link>
          </div>
          <div className="flex gap-1.5">
            {SOCIAL_LINKS.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={link.name}
                className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white text-sm hover:bg-vg-primary transition-colors"
              >
                {/* Using first letter as fallback — SocialIcons could be used instead */}
                <SocialIconInline icon={link.icon} />
              </Link>
            ))}
          </div>
        </div>

        {/* Footer Options: 4 Columns */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-[2fr_1fr_1fr_2fr] gap-8 pt-[75px] pb-9">
          {/* About */}
          <div className="mb-9">
            <h5 className="text-white font-heading font-bold mb-8">About us</h5>
            <p className="text-vg-para font-light mb-5">
              {siteConfig.description.slice(0, 120)}...
            </p>
            {(siteConfig.contact?.address || siteConfig.contact?.phone || siteConfig.contact?.email) && (
              <address className="not-italic text-vg-para font-light mb-5 text-sm leading-6">
                {siteConfig.contact?.address?.street && (
                  <div>{siteConfig.contact.address.street}</div>
                )}
                {(siteConfig.contact?.address?.city ||
                  siteConfig.contact?.address?.zip) && (
                  <div>
                    {[siteConfig.contact?.address?.city, siteConfig.contact?.address?.zip]
                      .filter(Boolean)
                      .join(" ")}
                  </div>
                )}
                {siteConfig.contact?.address?.country && (
                  <div>{siteConfig.contact.address.country}</div>
                )}
                {siteConfig.contact?.phone && (
                  <div>
                    <span className="sr-only">Phone</span>
                    <a
                      href={`tel:${siteConfig.contact.phone}`}
                      className="hover:text-white transition-colors"
                    >
                      {siteConfig.contact.phone}
                    </a>
                  </div>
                )}
                {siteConfig.contact?.email && (
                  <div>
                    <span className="sr-only">Email</span>
                    <a
                      href={`mailto:${siteConfig.contact.email}`}
                      className="hover:text-white transition-colors"
                    >
                      {siteConfig.contact.email}
                    </a>
                  </div>
                )}
              </address>
            )}
            <Link
              href="/about"
              className="text-white text-base inline-flex items-center gap-2"
            >
              Read more{" "}
              <span className="opacity-50 text-lg relative top-0.5">→</span>
            </Link>
          </div>

          {/* Who We Are */}
          <div className="mb-9">
            <h5 className="text-white font-heading font-bold mb-8">Who we are</h5>
            <ul className="space-y-1">
              {FOOTER_WHO_WE_ARE.map((item) => (
                <li key={item.label}>
                  <Link
                    href={item.href}
                    className="text-vg-para text-base font-light leading-8 hover:text-white transition-colors"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Our Work */}
          <div className="mb-9">
            <h5 className="text-white font-heading font-bold mb-8">Our work</h5>
            <ul className="space-y-1">
              {FOOTER_OUR_WORK.map((item) => (
                <li key={item.label}>
                  <Link
                    href={item.href}
                    className="text-vg-para text-base font-light leading-8 hover:text-white transition-colors"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div className="mb-9">
            <h5 className="text-white font-heading font-bold mb-8">Newsletter</h5>
            <p className="text-vg-para font-light mb-5">
              Stay up to date with our latest video production insights and news.
            </p>
            <NewsletterForm />
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-white/10 py-7 text-center">
          <p className="text-vg-para font-light text-base mb-0">
            Copyright &copy; {new Date().getFullYear()} All rights reserved |{" "}
            {siteConfig.name}
          </p>
        </div>
      </div>
    </footer>
  );
}

/* Small helper to render lucide icons by name inline */
function SocialIconInline({ icon }: { icon: string }) {
  // Using simple SVG paths for the footer circle icons
  const icons: Record<string, React.ReactNode> = {
    facebook: (
      <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
        <path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z" />
      </svg>
    ),
    twitter: (
      <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
        <path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z" />
      </svg>
    ),
    dribbble: (
      <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="2" />
        <path d="M8.56 2.75c4.37 6.03 6.02 9.42 8.03 17.72M19.13 5.09C15.22 9.14 10.93 10.44 2.64 10.96M21.75 12.84c-6.62-1.41-12.14 1-16.38 6.32" fill="none" stroke="currentColor" strokeWidth="2" />
      </svg>
    ),
    instagram: (
      <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
        <rect x="2" y="2" width="20" height="20" rx="5" ry="5" fill="none" stroke="currentColor" strokeWidth="2" />
        <circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" strokeWidth="2" />
        <circle cx="17.5" cy="6.5" r="1.5" />
      </svg>
    ),
    youtube: (
      <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
        <path d="M22.54 6.42a2.78 2.78 0 00-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 00-1.94 2A29 29 0 001 11.75a29 29 0 00.46 5.33A2.78 2.78 0 003.4 19.1C5.12 19.56 12 19.56 12 19.56s6.88 0 8.6-.46a2.78 2.78 0 001.94-2 29 29 0 00.46-5.25 29 29 0 00-.46-5.43z" />
        <polygon points="9.75,15.02 15.5,11.75 9.75,8.48" fill="white" />
      </svg>
    ),
  };
  return <>{icons[icon] || null}</>;
}
