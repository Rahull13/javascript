import React from "react";
import type { JsonLdObject } from "@/lib/structured-data";

function safeJsonStringify(value: JsonLdObject): string {
  // JSON-LD must be valid JSON (not JS) and should not include undefined.
  return JSON.stringify(value, (_key, v) => (v === undefined ? undefined : v));
}

export function JsonLd({ data }: { data: JsonLdObject }) {
  return (
    <script
      type="application/ld+json"
      // Server-rendered script tag (no hydration issues)
      dangerouslySetInnerHTML={{ __html: safeJsonStringify(data) }}
    />
  );
}

