/**
 * SectionTitle — Reusable section header with subtitle, heading, and accent bar
 * Server Component
 */

interface SectionTitleProps {
  subtitle: string;
  title: string;
  center?: boolean;
}

export function SectionTitle({ subtitle, title, center = false }: SectionTitleProps) {
  return (
    <div className={`section-title mb-12 ${center ? "center-title" : ""}`}>
      <span>{subtitle}</span>
      <h2>{title}</h2>
    </div>
  );
}

