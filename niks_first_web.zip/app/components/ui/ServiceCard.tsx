/**
 * ServiceCard — Service item with icon, title, and description
 * Server Component
 */

import Image from "next/image";

interface ServiceCardProps {
  icon: string;
  title: string;
  description: string;
}

export function ServiceCard({ icon, title, description }: ServiceCardProps) {
  return (
    <div className="mb-10 group">
      <div className="relative h-[70px] w-[70px] leading-[70px] text-center mb-0">
        {/* Animated border box */}
        <div className="absolute inset-0 border-2 border-vg-primary transition-transform duration-500 group-hover:rotate-45" />
        <Image
          src={icon}
          alt={title}
          width={36}
          height={36}
          className="inline-block relative z-10"
        />
      </div>
      <h4 className="text-white font-heading font-bold text-[22px] mt-6 mb-4">
        {title}
      </h4>
      <p className="text-vg-para text-base leading-relaxed mb-0">{description}</p>
    </div>
  );
}

