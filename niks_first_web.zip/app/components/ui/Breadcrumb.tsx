/**
 * Breadcrumb — Full-width hero banner with background image, page title, and breadcrumb links
 * Reusable across all inner pages. Server Component.
 */

import Link from "next/link";

interface BreadcrumbItem {
  label: string;
  href?: string;
}

interface BreadcrumbProps {
  title: string;
  items: BreadcrumbItem[];
  backgroundImage?: string;
  /**
   * Heading level for the page title.
   * Use "h1" for top-level page headings (default).
   */
  as?: "h1" | "h2";
}

export function Breadcrumb({
  title,
  items,
  backgroundImage = "/images/breadcrumb-bg.jpg",
  as = "h1",
}: BreadcrumbProps) {
  const HeadingTag = as;
  return (
    <div
      className="breadcrumb-banner set-bg"
      style={{ backgroundImage: `url(${backgroundImage})` }}
    >
      <div className="container mx-auto">
        <div className="text-center">
          <HeadingTag className="text-white font-heading font-bold text-[50px] mb-3">
            {title}
          </HeadingTag>
          <div className="flex items-center justify-center gap-0">
            {items.map((item, i) => {
              const isLast = i === items.length - 1;
              return isLast ? (
                <span
                  key={item.label}
                  className="text-vg-para text-base font-light inline-block"
                >
                  {item.label}
                </span>
              ) : (
                <Link
                  key={item.label}
                  href={item.href ?? "#"}
                  className="text-white text-base font-light inline-block mr-8 relative after:absolute after:-right-[22px] after:-top-[3px] after:content-['/'] after:text-vg-para after:text-xl"
                >
                  {item.label}
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

