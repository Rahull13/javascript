/**
 * PrimaryButton — Animated corner-border button from the Videograph theme
 * Server Component
 */

import Link from "next/link";

interface PrimaryButtonProps {
  children: React.ReactNode;
  href: string;
}

export function PrimaryButton({ children, href }: PrimaryButtonProps) {
  return (
    <Link href={href} className="primary-btn font-heading">
      {children}
    </Link>
  );
}

