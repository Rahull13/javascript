"use client";

/**
 * NewsletterForm — Client Component for the footer newsletter form.
 * Extracted so the parent Footer can remain a Server Component.
 */

import { Send } from "lucide-react";

export function NewsletterForm() {
  return (
    <form
      className="relative"
      onSubmit={(e) => {
        e.preventDefault();
        // TODO: wire up newsletter subscription logic
      }}
    >
      <input
        type="email"
        placeholder="Email"
        className="h-[50px] w-full pl-5 border border-[#544E5E] bg-transparent text-base text-vg-para placeholder:text-vg-para focus:outline-none focus:border-vg-primary transition-colors"
      />
      <button
        type="submit"
        className="absolute right-0 top-0 h-[50px] w-[50px] bg-vg-primary text-white text-xl flex items-center justify-center hover:opacity-90 transition-opacity"
      >
        <Send className="w-5 h-5" />
      </button>
    </form>
  );
}

