/**
 * SocialIcons — Reusable social media icon links
 * Server Component
 */

import Link from "next/link";
import {
  Facebook,
  Twitter,
  Dribbble,
  Instagram,
  Youtube,
} from "lucide-react";

const ICON_MAP: Record<string, React.ElementType> = {
  facebook: Facebook,
  twitter: Twitter,
  dribbble: Dribbble,
  instagram: Instagram,
  youtube: Youtube,
};

interface SocialIconsProps {
  links: readonly { name: string; icon: string; href: string }[];
  className?: string;
  iconClassName?: string;
}

export function SocialIcons({
  links,
  className = "",
  iconClassName = "w-4 h-4",
}: SocialIconsProps) {
  return (
    <div className={`flex items-center gap-4 ${className}`}>
      {links.map((link) => {
        const Icon = ICON_MAP[link.icon];
        if (!Icon) return null;
        return (
          <Link
            key={link.name}
            href={link.href}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={link.name}
            className="text-white/70 hover:text-white transition-colors"
          >
            <Icon className={iconClassName} />
          </Link>
        );
      })}
    </div>
  );
}

