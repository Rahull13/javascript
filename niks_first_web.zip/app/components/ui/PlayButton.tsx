/**
 * PlayButton — Circular play icon for video items
 * Server Component (visual only, click handled by parent)
 */

import { Play } from "lucide-react";

interface PlayButtonProps {
  className?: string;
}

export function PlayButton({ className = "" }: PlayButtonProps) {
  return (
    <span
      className={`inline-flex items-center justify-center w-[50px] h-[50px] rounded-full border border-white/70 text-white transition-all hover:bg-white/20 ${className}`}
    >
      <Play className="w-5 h-5 fill-white" />
    </span>
  );
}

