/**
 * BlogCard — Blog post card with hover background effect
 * Server Component
 */

import Link from "next/link";
import { ArrowRight } from "lucide-react";

interface BlogCardProps {
  title: string;
  date: string;
  comments: number;
  excerpt: string;
  href: string;
}

export function BlogCard({ title, date, comments, excerpt, href }: BlogCardProps) {
  return (
    <div className="blog-card group">
      <h4 className="text-white font-heading font-bold leading-8 mb-4 text-xl">
        {title}
      </h4>
      <ul className="flex gap-6 mb-5 text-sm text-[#777] font-light">
        <li className="relative after:content-['/'] after:absolute after:-right-4 after:top-0 group-hover:text-white transition-colors">
          {date}
        </li>
        <li className="group-hover:text-white transition-colors">
          {comments.toString().padStart(2, "0")} Comment
        </li>
      </ul>
      <p className="font-light leading-7 mb-5 group-hover:text-white transition-colors">
        {excerpt}
      </p>
      <Link
        href={href}
        className="text-white text-base inline-flex items-center gap-2"
      >
        Read more{" "}
        <ArrowRight className="w-4 h-4 opacity-50 relative top-0.5" />
      </Link>
    </div>
  );
}

