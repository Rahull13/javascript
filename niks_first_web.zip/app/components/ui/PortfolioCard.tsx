/**
 * PortfolioCard — Reusable card for portfolio grid items.
 * Matches the Videograph theme: background-image cover, hover underline on title,
 * tags separated by "/", and links to /portfolio/[slug].
 * Server Component.
 */

import Link from "next/link";

interface PortfolioCardProps {
  title: string;
  slug: string;
  coverImage: string;
  tags: readonly string[];
}

export function PortfolioCard({
  title,
  slug,
  coverImage,
  tags,
}: PortfolioCardProps) {
  return (
    <div className="portfolio-card mb-[35px]">
      {/* Cover image with overlay link */}
      <Link
        href={`/portfolio/${slug}`}
        className="portfolio-card-image set-bg block"
        style={{ backgroundImage: `url(${coverImage})` }}
        aria-label={`View ${title}`}
      >
        <span className="portfolio-play-btn">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="currentColor"
            className="w-5 h-5"
          >
            <path d="M8 5.14v14l11-7-11-7z" />
          </svg>
        </span>
      </Link>

      {/* Text below image */}
      <div className="text-center mt-7">
        <Link href={`/portfolio/${slug}`} className="group inline-block">
          <h4 className="text-white font-heading font-bold text-[22px] mb-2 relative inline-block after:absolute after:left-0 after:bottom-0 after:h-[1px] after:w-full after:bg-[#333] after:opacity-0 after:transition-opacity after:duration-300 group-hover:after:opacity-100">
            {title}
          </h4>
        </Link>
        {tags.length > 0 && (
          <ul className="flex items-center justify-center gap-0">
            {tags.map((tag, idx) => (
              <li
                key={tag}
                className={`text-vg-para text-base font-light inline-block ${
                  idx < tags.length - 1
                    ? "mr-6 relative after:absolute after:content-['/'] after:-right-4 after:top-0 after:text-vg-para"
                    : ""
                }`}
              >
                {tag}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

