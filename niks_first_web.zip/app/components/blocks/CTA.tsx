"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface CTAProps {
  title: string;
  description: string;
  primaryAction: {
    label: string;
    href: string;
  };
  secondaryAction?: {
    label: string;
    href: string;
  };
  variant?: "default" | "gradient" | "outline";
  className?: string;
}

export function CTA({
  title,
  description,
  primaryAction,
  secondaryAction,
  variant = "default",
  className,
}: CTAProps) {
  const variants = {
    default: "bg-primary text-primary-foreground",
    gradient: "bg-gradient-to-r from-primary to-purple-600 text-white",
    outline: "border-2 border-primary bg-transparent text-primary",
  };

  return (
    <section
      className={cn(
        "py-16 md:py-24",
        variant === "gradient" && "bg-gradient-to-r from-primary to-purple-600",
        variant === "default" && "bg-muted",
        className
      )}
    >
      <div className="container px-4">
        <div className="mx-auto max-w-3xl text-center">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-heading-2 mb-4"
          >
            {title}
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-body-large mb-8 text-muted-foreground"
          >
            {description}
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex flex-col items-center justify-center gap-4 sm:flex-row"
          >
            <Link
              href={primaryAction.href}
              className={cn(
                "flex items-center gap-2 rounded-full px-8 py-4 font-semibold transition-all hover:scale-105 hover:shadow-lg",
                variants[variant]
              )}
            >
              {primaryAction.label}
              <ArrowRight className="h-5 w-5" />
            </Link>
            {secondaryAction && (
              <Link
                href={secondaryAction.href}
                className="rounded-full border-2 border-border bg-background px-8 py-4 font-semibold transition-all hover:border-primary hover:text-primary"
              >
                {secondaryAction.label}
              </Link>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}

