"use client";

/**
 * TestimonialSlider — Client testimonials carousel on the About page
 * Uses Swiper for smooth sliding, responsive breakpoints, autoplay, and pagination.
 * Accepts CMS testimonials data; falls back to mock constants.
 */

import Image from "next/image";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";
import "swiper/css";
import "swiper/css/pagination";

import { SectionTitle } from "@/app/components/ui/SectionTitle";
import { TESTIMONIALS } from "@/lib/constants";
import type { Testimonial } from "@/lib/pages";

interface TestimonialSliderProps {
  testimonials?: Testimonial[];
}

export function TestimonialSlider({ testimonials }: TestimonialSliderProps) {
  const data = testimonials && testimonials.length > 0 ? testimonials : TESTIMONIALS;

  return (
    <section
      className="testimonial-section spad pb-[60px] set-bg overflow-hidden"
      style={{ backgroundImage: "url(/images/testimonial-bg.jpg)" }}
    >
      <div className="container mx-auto">
        {/* Title */}
        <SectionTitle
          subtitle="Loved By Clients"
          title="What clients say?"
          center
        />

        {/* Swiper Carousel */}
        <Swiper
          modules={[Autoplay, Pagination]}
          spaceBetween={30}
          slidesPerView={1}
          breakpoints={{
            640: { slidesPerView: 2 },
            1024: { slidesPerView: 3 },
          }}
          autoplay={{ delay: 5000, disableOnInteraction: false }}
          pagination={{
            clickable: true,
            el: ".testimonial-slider-dots",
            bulletClass: "testimonial-dot",
            bulletActiveClass: "testimonial-dot-active",
          }}
          className="testimonial-swiper"
        >
          {data.map((item, i) => (
            <SwiperSlide key={i}>
              {/* Quote box */}
              <div className="testimonial-quote-box">
                <p className="text-white text-lg font-light italic leading-[30px] mb-0">
                  {item.text}
                </p>
              </div>

              {/* Author */}
              <div className="pl-[30px] flex items-center gap-5">
                <Image
                  src={item.avatar}
                  alt={item.name}
                  width={50}
                  height={50}
                  className="rounded-full object-cover"
                />
                <div>
                  <h5 className="text-white font-bold mb-1">{item.name}</h5>
                  <span className="text-white text-sm font-light">
                    {item.role}
                  </span>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>

        {/* Custom pagination dots */}
        <div className="testimonial-slider-dots flex justify-center gap-2.5 mt-9" />
      </div>
    </section>
  );
}
