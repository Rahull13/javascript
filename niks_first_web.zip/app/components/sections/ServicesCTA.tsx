/**
 * ServicesCTA — Centered call-to-action banner used on the /services page
 * Different from the home page CTA: centered text, contained background, different image.
 * Server Component.
 */

import Link from "next/link";

export function ServicesCTA() {
  return (
    <section className="bg-vg-dark">
      <div className="container mx-auto">
        <div
          className="spad bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: "url(/images/calltos-bg.jpg)" }}
        >
          <div className="flex justify-center">
            <div className="max-w-[830px] text-center px-6">
              <h2 className="text-white font-heading font-bold text-2xl md:text-[42px] md:leading-[55px] mb-5">
                CREATE AWESOME VIDEOS WITH WIDEO&apos;S POWERFUL FEATURES
              </h2>
              <p className="text-white/70 text-[15px] mb-14">
                Wideo combines all the features you need to easily create
                professional videos and presentations
              </p>
              <Link
                href="/contact"
                className="inline-block bg-vg-primary text-white font-heading font-bold text-[15px] tracking-[2px] uppercase px-8 py-3.5 hover:opacity-90 transition-opacity"
              >
                Start your stories
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

