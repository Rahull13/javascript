"use client";

/**
 * ContactForm — Interactive contact form with client-side validation.
 * No backend submission — UI only.
 * Client Component.
 */

import { useState, type FormEvent } from "react";

interface FormState {
  name: string;
  email: string;
  website: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  message?: string;
}

export function ContactForm() {
  const [form, setForm] = useState<FormState>({
    name: "",
    email: "",
    website: "",
    message: "",
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitted, setSubmitted] = useState(false);

  function validate(): FormErrors {
    const errs: FormErrors = {};
    if (!form.name.trim()) errs.name = "Name is required";
    if (!form.email.trim()) {
      errs.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      errs.email = "Enter a valid email";
    }
    if (!form.message.trim()) errs.message = "Message is required";
    return errs;
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length === 0) {
      setSubmitted(true);
      setForm({ name: "", email: "", website: "", message: "" });
      setTimeout(() => setSubmitted(false), 4000);
    }
  }

  const inputClass =
    "h-[50px] w-full border bg-transparent text-base text-vg-para pl-5 font-light placeholder:text-vg-para mb-5 transition-colors duration-300 focus:outline-none";

  return (
    <div>
      <h3 className="text-white font-heading font-bold uppercase mb-9">
        Get in touch
      </h3>

      <form onSubmit={handleSubmit} noValidate>
        {/* Name */}
        <input
          type="text"
          placeholder="Name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className={`${inputClass} ${
            errors.name
              ? "border-red-500 focus:border-red-400"
              : "border-white/50 focus:border-white"
          }`}
        />
        {errors.name && (
          <p className="text-red-400 text-sm -mt-3 mb-4">{errors.name}</p>
        )}

        {/* Email */}
        <input
          type="email"
          placeholder="Email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          className={`${inputClass} ${
            errors.email
              ? "border-red-500 focus:border-red-400"
              : "border-white/50 focus:border-white"
          }`}
        />
        {errors.email && (
          <p className="text-red-400 text-sm -mt-3 mb-4">{errors.email}</p>
        )}

        {/* Website */}
        <input
          type="text"
          placeholder="Website"
          value={form.website}
          onChange={(e) => setForm({ ...form, website: e.target.value })}
          className={`${inputClass} border-white/50 focus:border-white`}
        />

        {/* Message */}
        <textarea
          placeholder="Message"
          rows={4}
          value={form.message}
          onChange={(e) => setForm({ ...form, message: e.target.value })}
          className={`w-full border bg-transparent text-base text-vg-para pt-3 pl-5 font-light placeholder:text-vg-para resize-none mb-4 transition-colors duration-300 focus:outline-none ${
            errors.message
              ? "border-red-500 focus:border-red-400"
              : "border-white/50 focus:border-white"
          }`}
        />
        {errors.message && (
          <p className="text-red-400 text-sm -mt-2 mb-4">{errors.message}</p>
        )}

        {/* Submit */}
        <button
          type="submit"
          className="w-full bg-vg-primary text-white font-heading font-bold text-[15px] tracking-[2px] uppercase py-4 hover:opacity-90 transition-opacity"
        >
          Send Message
        </button>

        {/* Success feedback */}
        {submitted && (
          <p className="text-green-400 text-sm mt-4">
            Thank you! Your message has been sent (placeholder).
          </p>
        )}
      </form>
    </div>
  );
}

