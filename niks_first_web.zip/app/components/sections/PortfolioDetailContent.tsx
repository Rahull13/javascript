/**
 * PortfolioDetailContent — Main content area for a portfolio detail page.
 * Works with real MongoDB data: renders description as HTML,
 * shows client/industry in sidebar.
 * Server Component.
 */

import type { PublishedPortfolioDetail } from "@/lib/portfolio";
import Link from "next/link";

interface PortfolioDetailContentProps {
  portfolio: PublishedPortfolioDetail;
}

export function PortfolioDetailContent({
  portfolio,
}: PortfolioDetailContentProps) {
  return (
    <section className="spad bg-vg-dark">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* ── Left Column: Project Overview ── */}
          <div className="lg:w-2/3">
            {/* Section title */}
            <div className="mb-10">
              <span className="text-vg-primary font-heading text-[15px] tracking-[2px] uppercase block mb-3">
                Project Overview
              </span>
              <h2 className="text-white font-heading font-bold text-2xl md:text-[36px] leading-tight">
                {portfolio.title}
              </h2>
            </div>

            {/* Description (rendered as HTML) */}
            <div
              className="portfolio-detail-body text-vg-para text-[15px] leading-[28px]"
              dangerouslySetInnerHTML={{ __html: portfolio.description }}
            />

            {/* Semantic internal links (lightweight, non-disruptive) */}
            <nav
              aria-label="Explore more content"
              className="mt-12 pt-8 border-t border-white/10"
            >
              <h2 className="text-white font-heading font-bold uppercase mb-4">
                Explore more
              </h2>
              <div className="flex flex-wrap items-center gap-4 text-sm">
                <Link
                  href="/portfolio"
                  className="text-white/90 hover:text-vg-primary transition-colors underline underline-offset-4"
                >
                  All Portfolio
                </Link>
                <Link
                  href="/services"
                  className="text-white/90 hover:text-vg-primary transition-colors underline underline-offset-4"
                >
                  Services
                </Link>
                <Link
                  href="/blog"
                  className="text-white/90 hover:text-vg-primary transition-colors underline underline-offset-4"
                >
                  Blog
                </Link>
                <Link
                  href="/contact"
                  className="text-white/90 hover:text-vg-primary transition-colors underline underline-offset-4"
                >
                  Contact
                </Link>
              </div>
            </nav>
          </div>

          {/* ── Right Column: Project Info Sidebar ── */}
          <div className="lg:w-1/3">
            <div className="portfolio-info-sidebar border border-[#222] p-8">
              <h3 className="text-white font-heading font-bold text-[20px] mb-6 pb-4 border-b border-[#222]">
                Project Details
              </h3>

              <ul className="space-y-5">
                {portfolio.client && (
                  <li className="flex justify-between items-start">
                    <span className="text-vg-para text-[14px] uppercase tracking-[1px] min-w-[90px]">
                      Client
                    </span>
                    <span className="text-white text-[15px] text-right">
                      {portfolio.client}
                    </span>
                  </li>
                )}
                {portfolio.industry && (
                  <li className="flex justify-between items-start">
                    <span className="text-vg-para text-[14px] uppercase tracking-[1px] min-w-[90px]">
                      Industry
                    </span>
                    <span className="text-white text-[15px] text-right">
                      {portfolio.industry}
                    </span>
                  </li>
                )}
                <li className="flex justify-between items-start">
                  <span className="text-vg-para text-[14px] uppercase tracking-[1px] min-w-[90px]">
                    Images
                  </span>
                  <span className="text-white text-[15px] text-right">
                    {portfolio.images.length} Photo
                    {portfolio.images.length !== 1 ? "s" : ""}
                  </span>
                </li>
              </ul>

              {/* Decorative accent line */}
              <div className="w-12 h-[2px] bg-vg-primary mt-8" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
