/**
 * ServicesGrid — Responsive services grid for the /services page.
 * Accepts dynamic data from MongoDB (published services).
 * Falls back to an empty-state message when no services exist.
 * Server Component.
 */

import Link from "next/link";
import { ServiceCard } from "@/app/components/ui/ServiceCard";
import { getDefaultIcon } from "@/lib/services";
import type { PublishedServiceListItem } from "@/lib/services";

interface ServicesGridProps {
  services: PublishedServiceListItem[];
}

export function ServicesGrid({ services }: ServicesGridProps) {
  if (services.length === 0) {
    return (
      <section className="bg-vg-dark spad pb-[50px]">
        <div className="container mx-auto text-center">
          <p className="text-vg-para text-lg">
            No services available at the moment. Please check back soon.
          </p>
        </div>
      </section>
    );
  }

  return (
    <section className="bg-vg-dark spad pb-[50px]">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8">
          {services.map((service, index) => (
            <Link
              key={service.slug}
              href={`/services/${service.slug}`}
              className="block"
            >
              <ServiceCard
                icon={service.imageUrl || getDefaultIcon(index)}
                title={service.title}
                description={service.summary}
              />
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
