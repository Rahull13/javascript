/**
 * CallToAction — CTA banner section from the Videograph homepage
 * Server Component — accepts CMS overrides for text and background
 */

import Link from "next/link";
import type { CtaData } from "@/lib/pages";

interface CallToActionProps {
  data?: CtaData;
}

export function CallToAction({ data }: CallToActionProps) {
  const title = data?.title ?? "Fresh Ideas, Fresh Moments Giving Wings to your Stories.";
  const tagline = data?.tagline ?? "INC5000, Best places to work 2019";
  const buttonText = data?.buttonText ?? "Start your stories";
  const buttonHref = data?.buttonHref ?? "/contact";
  const backgroundImage = data?.backgroundImage ?? "/images/callto-bg.jpg";

  return (
    <section
      className="cta-section spad bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: `url(${backgroundImage})` }}
    >
      <div className="container mx-auto">
        <div className="max-w-2xl">
          <h2 className="text-white font-heading font-bold text-3xl md:text-[42px] leading-tight mb-5">
            {title}
          </h2>
          <p className="text-white/70 text-[15px] uppercase mb-14">
            {tagline}
          </p>
          <Link
            href={buttonHref}
            className="inline-block bg-vg-primary text-white font-heading font-bold text-[15px] tracking-[2px] uppercase px-8 py-3.5 hover:opacity-90 transition-opacity"
          >
            {buttonText}
          </Link>
        </div>
      </div>
    </section>
  );
}
