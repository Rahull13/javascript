"use client";

/**
 * ClientLogos — Sliding logo carousel for partner/client brands
 * Uses Swiper with loop mode. Logos are duplicated to meet Swiper's
 * minimum slide count requirement for smooth looping (2× slidesPerView).
 * Client Component.
 */

import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper/modules";
import "swiper/css";

import { CLIENT_LOGOS } from "@/lib/constants";

/* Duplicate logos so Swiper has enough slides for loop mode
   (needs at least 2× slidesPerView; 6 originals → 12 duplicated) */
const SLIDES = [...CLIENT_LOGOS, ...CLIENT_LOGOS];

export function ClientLogos() {
  return (
    <section className="bg-vg-dark py-[100px] px-5 overflow-hidden">
      <div className="container mx-auto">
        <Swiper
          modules={[Autoplay]}
          slidesPerView={2}
          spaceBetween={100}
          breakpoints={{
            480: { slidesPerView: 3, spaceBetween: 100 },
            768: { slidesPerView: 4, spaceBetween: 100 },
            992: { slidesPerView: 5, spaceBetween: 100 },
          }}
          autoplay={{ delay: 3000, disableOnInteraction: false }}
          speed={1200}
          loop
          className="client-logos-swiper"
        >
          {SLIDES.map((logo, i) => (
            <SwiperSlide
              key={`${logo.id}-${i}`}
              className="!flex items-center justify-center"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={logo.src}
                alt={logo.alt}
                className="w-auto h-auto inline-block opacity-60 hover:opacity-100 transition-opacity duration-300"
              />
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </section>
  );
}
