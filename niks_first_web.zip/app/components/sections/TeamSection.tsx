/**
 * TeamSection — Team members grid with hover reveal
 * Server Component (CSS-only hover animation, stagger via Tailwind)
 */

import Link from "next/link";
import { Facebook, Twitter, Dribbble, Instagram } from "lucide-react";
import { SectionTitle } from "@/app/components/ui/SectionTitle";
import { PrimaryButton } from "@/app/components/ui/PrimaryButton";
import { TEAM_MEMBERS } from "@/lib/constants";
import type { TeamMember } from "@/lib/pages";

const SOCIAL_ICONS = [
  { Icon: Facebook, label: "Facebook" },
  { Icon: Twitter, label: "Twitter" },
  { Icon: Dribbble, label: "Dribbble" },
  { Icon: Instagram, label: "Instagram" },
];

interface TeamSectionProps {
  members?: TeamMember[];
}

export function TeamSection({ members }: TeamSectionProps) {
  const data = members && members.length > 0 ? members : TEAM_MEMBERS;

  return (
    <section
      className="spad bg-cover bg-center bg-no-repeat pb-[90px] relative"
      style={{ backgroundImage: "url(/images/team-bg.jpg)" }}
    >
      <div className="container mx-auto">
        {/* Title */}
        <SectionTitle subtitle="Nice to meet" title="OUR Team" />

        {/* Team Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 relative gap-0">
          {data.map((member, i) => (
            <div
              key={i}
              className="px-0"
              /* Staggered offset for desktop using CSS custom properties */
              style={
                {
                  "--team-offset": `${-i * 60}px`,
                } as React.CSSProperties
              }
            >
              {/* Wrap in a div that applies offset only on lg+ */}
              <div className="lg:mt-[var(--team-offset)]">
                <div
                  className="team-card"
                  style={{ backgroundImage: `url(${member.image})` }}
                >
                  <div className="team-card-overlay">
                    <h4 className="text-white font-heading font-bold text-[22px] uppercase mb-2">
                      {member.name}
                    </h4>
                    <p className="text-white font-light mb-3">{member.role}</p>
                    <div className="flex justify-center gap-4">
                      {SOCIAL_ICONS.map(({ Icon, label }) => (
                        <Link
                          key={label}
                          href="#"
                          className="text-white hover:text-vg-primary transition-colors"
                          aria-label={label}
                        >
                          <Icon className="w-4 h-4" />
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {/* "Meet Our Team" button */}
          <div className="col-span-full flex justify-end mt-8 lg:absolute lg:right-0 lg:bottom-0 lg:mt-0">
            <PrimaryButton href="/about">Meet Our Team</PrimaryButton>
          </div>
        </div>
      </div>
    </section>
  );
}
