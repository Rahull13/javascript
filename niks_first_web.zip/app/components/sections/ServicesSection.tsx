/**
 * ServicesSection — "What We Do?" section from the Videograph homepage
 * Server Component — accepts CMS overrides for text content and services from DB.
 */

import { SERVICES } from "@/lib/constants";
import { SectionTitle } from "@/app/components/ui/SectionTitle";
import { PrimaryButton } from "@/app/components/ui/PrimaryButton";
import { ServiceCard } from "@/app/components/ui/ServiceCard";
import type { ServicesSectionData } from "@/lib/pages";
import type { PublishedServiceListItem } from "@/lib/services";
import { getDefaultIcon } from "@/lib/services";

interface ServicesSectionProps {
  /** CMS text overrides (subtitle, title, description, buttonText) */
  data?: ServicesSectionData;
  /** Published services from the DB — uses first 4 */
  dbServices?: PublishedServiceListItem[];
}

export function ServicesSection({ data, dbServices }: ServicesSectionProps) {
  const subtitle = data?.subtitle ?? "Our services";
  const title = data?.title ?? "What We do?";
  const description =
    data?.description ||
    "If you hire a videographer of our team you will get a video professional to make a custom video for your business and, once the project is over.";
  const buttonText = data?.buttonText ?? "View all services";

  // Use DB services if available; otherwise fall back to mock
  const hasDbServices = dbServices && dbServices.length > 0;

  return (
    <section className="bg-vg-dark pt-28 pb-16">
      <div className="container mx-auto">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Left: Title + CTA */}
          <div className="lg:w-1/3">
            <SectionTitle subtitle={subtitle} title={title} />
            <p className="text-vg-para mb-10 font-body">{description}</p>
            <PrimaryButton href="/services">{buttonText}</PrimaryButton>
          </div>

          {/* Right: Service Cards Grid */}
          <div className="lg:w-2/3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8">
              {hasDbServices
                ? dbServices.slice(0, 4).map((service, idx) => (
                    <ServiceCard
                      key={service.slug}
                      icon={service.imageUrl || getDefaultIcon(idx)}
                      title={service.title}
                      description={service.summary}
                    />
                  ))
                : SERVICES.slice(0, 4).map((service) => (
                    <ServiceCard
                      key={service.id}
                      icon={service.icon}
                      title={service.title}
                      description={service.description}
                    />
                  ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
