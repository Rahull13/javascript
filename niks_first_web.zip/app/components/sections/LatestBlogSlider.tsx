"use client";

/**
 * LatestBlogSlider — Blog posts carousel on the Home page
 * Uses Swiper for smooth sliding, responsive breakpoints, autoplay, and pagination.
 * Accepts CMS blog data from DB; falls back to mock constants.
 */

import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";
import "swiper/css";
import "swiper/css/pagination";

import { SectionTitle } from "@/app/components/ui/SectionTitle";
import { BlogCard } from "@/app/components/ui/BlogCard";
import { BLOG_POSTS } from "@/lib/constants";

interface BlogSlideItem {
  title: string;
  date: string;
  comments: number;
  excerpt: string;
  href: string;
}

interface LatestBlogSliderProps {
  blogs?: BlogSlideItem[];
}

export function LatestBlogSlider({ blogs }: LatestBlogSliderProps) {
  const data: BlogSlideItem[] =
    blogs && blogs.length > 0
      ? blogs
      : BLOG_POSTS.map((post) => ({
          title: post.title,
          date: post.date,
          comments: post.comments,
          excerpt: post.excerpt,
          href: post.href,
        }));

  return (
    <section className="bg-vg-dark spad pb-20 overflow-hidden">
      <div className="container mx-auto">
        {/* Title */}
        <SectionTitle subtitle="Our Blog" title="Blog Update" center />

        {/* Swiper Carousel */}
        <Swiper
          modules={[Autoplay, Pagination]}
          spaceBetween={30}
          slidesPerView={1}
          breakpoints={{
            640: { slidesPerView: 2 },
            1024: { slidesPerView: 3 },
          }}
          autoplay={{ delay: 4000, disableOnInteraction: false }}
          pagination={{
            clickable: true,
            el: ".blog-slider-dots",
            bulletClass: "blog-dot",
            bulletActiveClass: "blog-dot-active",
          }}
          className="blog-swiper"
        >
          {data.map((post, i) => (
            <SwiperSlide key={i}>
              <BlogCard
                title={post.title}
                date={post.date}
                comments={post.comments}
                excerpt={post.excerpt}
                href={post.href}
              />
            </SwiperSlide>
          ))}
        </Swiper>

        {/* Custom pagination dots */}
        <div className="blog-slider-dots flex justify-center gap-2.5 mt-9" />
      </div>
    </section>
  );
}
