/**
 * BlogDetailHero — Full-width hero banner for blog detail pages.
 * Shows title centred over a background image with author/date meta.
 * Supports Cloudinary URLs and a fallback default image.
 * Server Component.
 */

interface BlogDetailHeroProps {
  title: string;
  author: string;
  date: string;
  heroImage?: string;
}

export function BlogDetailHero({
  title,
  author,
  date,
  heroImage,
}: BlogDetailHeroProps) {
  const bgImage = heroImage || "/images/blog/blog-hero.jpg";

  return (
    <section
      className="blog-detail-hero bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: `url(${bgImage})` }}
    >
      <div className="container mx-auto">
        <div className="flex justify-center">
          <div className="max-w-[730px] text-center">
            <h1 className="text-white font-heading font-bold leading-[47px] uppercase mb-3">
              {title}
            </h1>
            <ul className="flex items-center justify-center gap-6 text-white text-sm font-light">
              <li className="blog-detail-meta">
                by <span className="uppercase">{author}</span>
              </li>
              <li>{date}</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
