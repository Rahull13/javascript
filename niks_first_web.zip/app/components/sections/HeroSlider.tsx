"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { HERO_SLIDES } from "@/lib/constants";
import type { HeroSlide } from "@/lib/pages";

interface HeroSliderProps {
  slides?: HeroSlide[];
}

export function HeroSlider({ slides }: HeroSliderProps) {
  const data = slides && slides.length > 0 ? slides : HERO_SLIDES;
  const [current, setCurrent] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const goTo = useCallback(
    (index: number) => {
      if (isAnimating) return;
      setIsAnimating(true);
      setCurrent(index);
      setTimeout(() => setIsAnimating(false), 1200);
    },
    [isAnimating],
  );

  // Auto-play
  useEffect(() => {
    const timer = setInterval(() => {
      goTo((current + 1) % data.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [current, goTo, data.length]);

  return (
    <section className="relative w-full h-[684px] overflow-hidden">
      {data.map((slide, i) => (
        <div
          key={i}
          className="absolute inset-0 transition-opacity duration-1000 ease-in-out bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url(${slide.image})`,
            opacity: i === current ? 1 : 0,
            zIndex: i === current ? 1 : 0,
          }}
        >
          <div className="container mx-auto h-full flex items-center pt-20">
            <div className="max-w-xl">
              {/* Staggered text animation */}
              <span
                className={`block text-white text-[15px] tracking-[2px] uppercase mb-4 font-body transition-all duration-300 ${
                  i === current
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-24"
                }`}
                style={{ transitionDelay: i === current ? "0.2s" : "0s" }}
              >
                {slide.subtitle}
              </span>
              <h2
                className={`text-white font-heading font-bold text-[40px] md:text-[60px] leading-tight uppercase mb-8 transition-all duration-500 ${
                  i === current
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-24"
                }`}
                style={{ transitionDelay: i === current ? "0.4s" : "0s" }}
              >
                {slide.title}
              </h2>
              <div
                className={`transition-all duration-700 ${
                  i === current
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-24"
                }`}
                style={{ transitionDelay: i === current ? "0.6s" : "0s" }}
              >
                <Link href={slide.ctaHref} className="primary-btn font-heading">
                  {slide.cta}
                </Link>
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Dots */}
      <div className="absolute left-0 right-0 bottom-11 z-10">
        <div className="container mx-auto">
          <div className="flex gap-4">
            {data.map((_, i) => (
              <button
                key={i}
                onClick={() => goTo(i)}
                className={`font-heading text-lg relative pb-2 transition-colors ${
                  i === current ? "text-white" : "text-vg-para"
                } after:absolute after:left-0 after:bottom-0 after:w-full after:h-[1px] ${
                  i === current
                    ? "after:bg-white after:h-[2px]"
                    : "after:bg-white/30"
                }`}
              >
                {String(i + 1).padStart(2, "0")}
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
