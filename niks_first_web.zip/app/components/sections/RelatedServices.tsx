/**
 * RelatedServices — Shows other services at the bottom of a service detail page.
 * Receives pre-filtered list of related services from the parent page.
 * Server Component.
 */

import Link from "next/link";
import { SectionTitle } from "@/app/components/ui/SectionTitle";
import { ServiceCard } from "@/app/components/ui/ServiceCard";
import { getDefaultIcon } from "@/lib/services";
import type { PublishedServiceListItem } from "@/lib/services";

interface RelatedServicesProps {
  services: PublishedServiceListItem[];
}

export function RelatedServices({ services }: RelatedServicesProps) {
  if (services.length === 0) return null;

  return (
    <section className="bg-vg-dark spad pt-0 pb-20">
      <div className="container mx-auto">
        {/* Divider */}
        <div className="border-t border-white/10 mb-16" />

        <SectionTitle subtitle="Explore more" title="Other Services" center />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8">
          {services.map((service, index) => (
            <Link
              key={service.slug}
              href={`/services/${service.slug}`}
              className="block hover:opacity-90 transition-opacity"
            >
              <ServiceCard
                icon={service.imageUrl || getDefaultIcon(index)}
                title={service.title}
                description={service.summary}
              />
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
