/**
 * AboutContent — "Who We Are?" section with image grid + service icons + description
 * Server Component — accepts CMS overrides for text, images, and mini services.
 */

import Image from "next/image";
import { SectionTitle } from "@/app/components/ui/SectionTitle";
import { ABOUT_SERVICES, ABOUT_IMAGES } from "@/lib/constants";
import type { AboutSectionData } from "@/lib/pages";

interface AboutContentProps {
  data?: AboutSectionData;
}

export function AboutContent({ data }: AboutContentProps) {
  const subtitle = data?.subtitle ?? "About videograph";
  const title = data?.title ?? "WHo we are?";
  const description =
    data?.description ||
    "Formed in 2006 by Matt Hobbs and Cael Jones, Videograph is an award-winning, full-service production company specializing in commercial, broadcast, tourism & action sport video production services has been featured.";
  const images = data?.images ?? ABOUT_IMAGES;
  const services =
    data?.services && data.services.length > 0 ? data.services : ABOUT_SERVICES;

  return (
    <section className="bg-vg-dark spad pb-[150px]">
      <div className="container mx-auto">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Left: Image Grid */}
          <div className="lg:w-1/2">
            <div className="grid grid-cols-2 gap-5">
              {/* Large image spanning full left column */}
              <div
                className="about-pic-large set-bg row-span-2"
                style={{ backgroundImage: `url(${images.large})` }}
              />
              {/* Two smaller images stacked on the right */}
              <div
                className="about-pic-small set-bg"
                style={{ backgroundImage: `url(${images.smallTop})` }}
              />
              <div
                className="about-pic-small set-bg"
                style={{ backgroundImage: `url(${images.smallBottom})` }}
              />
            </div>
          </div>

          {/* Right: Text Content */}
          <div className="lg:w-1/2 lg:pl-8">
            <SectionTitle subtitle={subtitle} title={title} />

            {/* Mini Service Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">
              {services.map((service, i) => (
                <div key={i} className="group">
                  {/* Icon box with animated border */}
                  <div className="relative h-[70px] w-[70px] leading-[70px] text-center mb-0">
                    <div className="absolute inset-0 border-2 border-[#281A3E] transition-transform duration-500 group-hover:rotate-45" />
                    <Image
                      src={service.icon}
                      alt={service.title}
                      width={36}
                      height={36}
                      className="inline-block relative z-10"
                    />
                  </div>
                  <h4 className="text-white font-heading font-bold text-[22px] mt-6 mb-3">
                    {service.title}
                  </h4>
                  <p className="text-vg-para text-base leading-relaxed">
                    {service.description}
                  </p>
                </div>
              ))}
            </div>

            {/* Description */}
            <div className="-mt-2">
              <p className="text-vg-para font-light leading-7">{description}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
