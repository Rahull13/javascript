/**
 * ServiceDetailContent — Main content area for a service detail page.
 * Works with real MongoDB data: renders content as rich HTML, shows
 * featured image, category badge, and summary lead.
 * Server Component.
 */

import Image from "next/image";
import Link from "next/link";
import type { PublishedServiceDetail } from "@/lib/services";

interface ServiceDetailContentProps {
  service: PublishedServiceDetail;
}

export function ServiceDetailContent({ service }: ServiceDetailContentProps) {
  return (
    <section className="bg-vg-dark spad">
      <div className="container mx-auto">
        <div className="flex justify-center">
          <div className="w-full max-w-[850px]">
            {/* Category Badge */}
            <div className="mb-6">
              <span className="inline-block bg-vg-primary/20 text-vg-primary text-xs font-heading font-bold uppercase tracking-[2px] px-4 py-1.5 rounded-sm">
                {service.category}
              </span>
            </div>

            {/* Featured Image */}
            {service.imageUrl && (
              <div className="relative w-full aspect-video mb-10 overflow-hidden">
                <Image
                  src={service.imageUrl}
                  alt={service.imageAlt || service.title}
                  fill
                  className="object-cover"
                  sizes="(max-width: 850px) 100vw, 850px"
                  priority
                />
              </div>
            )}

            {/* Summary / Lead */}
            <p className="text-white text-lg md:text-xl font-light leading-[32px] mb-8 border-l-4 border-vg-primary pl-6">
              {service.summary}
            </p>

            {/* Main Content (rendered as HTML) */}
            <div
              className="service-detail-body text-vg-para text-base md:text-lg font-light leading-[29px] space-y-5"
              dangerouslySetInnerHTML={{ __html: service.content }}
            />

            {/* Semantic internal links (lightweight, non-disruptive) */}
            <nav
              aria-label="Explore more content"
              className="mt-12 pt-8 border-t border-white/10"
            >
              <h2 className="text-white font-heading font-bold uppercase mb-4 text-center">
                Explore more
              </h2>
              <div className="flex flex-wrap items-center justify-center gap-4 text-sm">
                <Link
                  href="/services"
                  className="text-white/90 hover:text-vg-primary transition-colors underline underline-offset-4"
                >
                  All Services
                </Link>
                <Link
                  href="/blog"
                  className="text-white/90 hover:text-vg-primary transition-colors underline underline-offset-4"
                >
                  Blog Insights
                </Link>
                <Link
                  href="/portfolio"
                  className="text-white/90 hover:text-vg-primary transition-colors underline underline-offset-4"
                >
                  Portfolio Work
                </Link>
                <Link
                  href="/contact"
                  className="text-white/90 hover:text-vg-primary transition-colors underline underline-offset-4"
                >
                  Contact
                </Link>
              </div>
            </nav>
          </div>
        </div>
      </div>
    </section>
  );
}
