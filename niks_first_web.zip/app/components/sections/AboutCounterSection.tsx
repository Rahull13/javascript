"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { COUNTER_STATS } from "@/lib/constants";

/**
 * Flat counter grid used on the About page (not the diamond layout from the home page).
 * Client Component for IntersectionObserver-based count-up animation.
 */

// Counter background colours match the original theme per column
const BG_COLORS = ["#1a083d", "#20124d", "#29155e", "#321a6e"];

function useCountUp(target: number, duration = 2000) {
  const [count, setCount] = useState(0);
  const [started, setStarted] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started) setStarted(true);
      },
      { threshold: 0.3 },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [started]);

  useEffect(() => {
    if (!started) return;
    let start = 0;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.ceil(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [started, target, duration]);

  return { count, ref };
}

export function AboutCounterSection() {
  return (
    <section className="bg-vg-dark">
      <div className="container mx-auto">
        <div className="grid grid-cols-2 lg:grid-cols-4">
          {COUNTER_STATS.map((stat, i) => (
            <CounterCard
              key={stat.id}
              icon={stat.icon}
              value={stat.value}
              label={stat.label}
              bg={BG_COLORS[i] ?? BG_COLORS[0]}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

function CounterCard({
  icon,
  value,
  label,
  bg,
}: {
  icon: string;
  value: number;
  label: string;
  bg: string;
}) {
  const { count, ref } = useCountUp(value);

  return (
    <div
      ref={ref}
      className="flex flex-col items-center justify-center py-16 px-6 text-center"
      style={{ backgroundColor: bg }}
    >
      <Image src={icon} alt={label} width={40} height={40} />
      <h2 className="text-white font-heading font-bold text-5xl mt-5 mb-2">
        {count}
      </h2>
      <p className="text-white text-base mb-0">{label}</p>
    </div>
  );
}

