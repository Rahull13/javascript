"use client";

import { useState } from "react";
import { WORK_ITEMS } from "@/lib/constants";
import { PlayButton } from "@/app/components/ui/PlayButton";
import { X } from "lucide-react";
import type { WorkItem } from "@/lib/pages";

interface WorkGalleryProps {
  items?: WorkItem[];
}

export function WorkGallery({ items }: WorkGalleryProps) {
  const data = items && items.length > 0 ? items : WORK_ITEMS;
  const [videoUrl, setVideoUrl] = useState<string | null>(null);

  return (
    <>
      <section className="bg-vg-dark overflow-hidden">
        <div className="work-gallery">
          {data.map((item, i) => (
            <div
              key={i}
              className={`work-item ${item.size} group`}
              style={{ backgroundImage: `url(${item.image})` }}
            >
              {/* Play button */}
              <button onClick={() => setVideoUrl(item.videoUrl)}>
                <PlayButton />
              </button>

              {/* Hover overlay (only for items with title) */}
              {item.title && (
                <div className="absolute left-0 bottom-0 w-full px-7 py-5 bg-black/50 translate-y-full group-hover:translate-y-0 transition-transform duration-500">
                  <h4 className="text-white font-heading font-bold text-[22px]">
                    {item.title}
                  </h4>
                  {item.tags && item.tags.length > 0 && (
                    <ul className="flex gap-5 text-vg-para text-base">
                      {item.tags.map((tag: string, idx: number) => (
                        <li
                          key={tag}
                          className={`relative ${
                            idx < (item.tags?.length ?? 0) - 1
                              ? "after:content-['/'] after:absolute after:-right-4 after:top-0"
                              : ""
                          }`}
                        >
                          {tag}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Video Modal */}
      {videoUrl && (
        <div
          className="fixed inset-0 z-[9999] bg-black/80 flex items-center justify-center p-4"
          onClick={() => setVideoUrl(null)}
        >
          <div
            className="relative w-full max-w-4xl aspect-video"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setVideoUrl(null)}
              className="absolute -top-10 right-0 text-white hover:text-vg-primary transition-colors"
              aria-label="Close video"
            >
              <X className="w-8 h-8" />
            </button>
            <iframe
              src={videoUrl.replace("watch?v=", "embed/")}
              className="w-full h-full"
              allow="autoplay; encrypted-media"
              allowFullScreen
              title="Video"
            />
          </div>
        </div>
      )}
    </>
  );
}
