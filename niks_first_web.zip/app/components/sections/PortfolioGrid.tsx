"use client";

/**
 * PortfolioGrid — Filterable portfolio grid with industry tabs.
 * Accepts published portfolio data from MongoDB via props.
 * Client Component (needs useState for active filter).
 */

import { useState, useMemo } from "react";
import { PortfolioCard } from "@/app/components/ui/PortfolioCard";
import type { PublishedPortfolioListItem } from "@/lib/portfolio";

interface PortfolioGridProps {
  portfolios: PublishedPortfolioListItem[];
  industries: string[];
}

export function PortfolioGrid({ portfolios, industries }: PortfolioGridProps) {
  const [activeFilter, setActiveFilter] = useState("All");

  const categories = useMemo(() => ["All", ...industries], [industries]);

  const filteredItems = useMemo(() => {
    if (activeFilter === "All") return portfolios;
    return portfolios.filter((item) => item.industry === activeFilter);
  }, [activeFilter, portfolios]);

  if (portfolios.length === 0) {
    return (
      <section className="bg-vg-dark spad">
        <div className="container mx-auto text-center">
          <p className="text-vg-para text-lg">
            No portfolio items available at the moment. Please check back soon.
          </p>
        </div>
      </section>
    );
  }

  return (
    <section className="bg-vg-dark spad">
      <div className="container mx-auto">
        {/* Filter Tabs */}
        {industries.length > 0 && (
          <ul className="flex flex-wrap items-center justify-center gap-1 mb-10">
            {categories.map((category) => (
              <li key={category}>
                <button
                  onClick={() => setActiveFilter(category)}
                  className={`portfolio-filter-btn ${
                    activeFilter === category
                      ? "portfolio-filter-btn-active"
                      : ""
                  }`}
                >
                  {category}
                </button>
              </li>
            ))}
          </ul>
        )}

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8">
          {filteredItems.map((item) => (
            <PortfolioCard
              key={item.slug}
              title={item.title}
              slug={item.slug}
              coverImage={item.coverImage}
              tags={item.industry ? [item.industry] : []}
            />
          ))}
        </div>

        {/* Empty state for filtered view */}
        {filteredItems.length === 0 && (
          <div className="text-center py-20">
            <p className="text-vg-para text-lg">
              No portfolio items found in this category.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}
