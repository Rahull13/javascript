"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { COUNTER_STATS } from "@/lib/constants";
import type { CounterStat } from "@/lib/pages";

function useCountUp(target: number, duration = 2000) {
  const [count, setCount] = useState(0);
  const [started, setStarted] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started) {
          setStarted(true);
        }
      },
      { threshold: 0.3 },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [started]);

  useEffect(() => {
    if (!started) return;
    let start = 0;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.ceil(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [started, target, duration]);

  return { count, ref };
}

function CounterItem({
  icon,
  value,
  label,
  index,
}: {
  icon: string;
  value: number;
  label: string;
  index: number;
}) {
  const { count, ref } = useCountUp(value);

  // Staggered vertical offset for desktop diamond layout
  const offsets = [0, -185, 0, -185];
  const desktopMarginTop = offsets[index] ?? 0;

  return (
    <div
      ref={ref}
      className="flex justify-center"
      style={{ marginTop: `${desktopMarginTop}px` }}
    >
      <div className={`counter-diamond counter-diamond-pos-${index}`}>
        <div className="counter-diamond-inner">
          <Image src={icon} alt={label} width={40} height={40} />
          <h2 className="text-white font-heading font-bold text-[60px] mt-[18px] mb-1.5">
            {count}
          </h2>
          <p className="text-white mb-0 text-base">{label}</p>
        </div>
      </div>
    </div>
  );
}

interface CounterStatsProps {
  stats?: CounterStat[];
}

export function CounterStats({ stats }: CounterStatsProps) {
  const data = stats && stats.length > 0 ? stats : COUNTER_STATS;

  return (
    <section className="bg-vg-dark overflow-hidden hidden lg:block" style={{ height: 840, paddingTop: 380 }}>
      <div className="mx-auto" style={{ maxWidth: 1140, padding: '0 50px' }}>
        <div className="grid grid-cols-4" style={{ gap: 0 }}>
          {data.map((stat, i) => (
            <CounterItem
              key={i}
              icon={stat.icon}
              value={stat.value}
              label={stat.label}
              index={i}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

/* Mobile-friendly counter (no diamond rotation) */
export function CounterStatsMobile({ stats }: CounterStatsProps) {
  const data = stats && stats.length > 0 ? stats : COUNTER_STATS;

  return (
    <section className="bg-vg-dark py-24 lg:hidden">
      <div className="container mx-auto">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
          {data.map((stat, i) => (
            <MobileCounterItem key={i} {...stat} />
          ))}
        </div>
      </div>
    </section>
  );
}

function MobileCounterItem({
  icon,
  value,
  label,
}: {
  icon: string;
  value: number;
  label: string;
}) {
  const { count, ref } = useCountUp(value);
  return (
    <div ref={ref} className="bg-vg-card p-8 text-center">
      <Image src={icon} alt={label} width={40} height={40} className="mx-auto" />
      <h2 className="text-white font-heading font-bold text-4xl mt-4 mb-1">
        {count}
      </h2>
      <p className="text-white mb-0 text-sm">{label}</p>
    </div>
  );
}
