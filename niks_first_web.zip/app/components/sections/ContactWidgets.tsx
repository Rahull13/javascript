/**
 * ContactWidgets — Three contact info cards (address, phone, email)
 * Each has a circular icon and text block.
 * Server Component.
 */

import { MapPin, Phone, Mail } from "lucide-react";

const WIDGETS = [
  {
    icon: MapPin,
    title: "Address",
    text: "Los Angeles Gournadi, 1230 Bariasl",
  },
  {
    icon: Phone,
    title: "Hotline",
    text: "1-677-124-44227 • 1-688-356-66889",
  },
  {
    icon: Mail,
    title: "Email",
    text: "support@videograph.com",
  },
] as const;

export function ContactWidgets() {
  return (
    <section className="bg-vg-dark spad pb-[70px]">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {WIDGETS.map((widget) => (
            <div key={widget.title} className="flex items-start gap-7 mb-7 md:mb-0">
              {/* Circular icon */}
              <div className="flex-shrink-0 h-[70px] w-[70px] rounded-full border border-white/50 flex items-center justify-center">
                <widget.icon className="w-7 h-7 text-white" />
              </div>
              {/* Text */}
              <div className="pt-1.5">
                <h4 className="text-white font-heading font-bold text-[22px] mb-2.5">
                  {widget.title}
                </h4>
                <p className="text-vg-para mb-0">{widget.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

