/**
 * BlogDetailContent — Rich content area for the blog detail page.
 * Renders DB content as HTML, with tags, prev/next nav, recent posts,
 * and a comment form shell.
 * Server Component.
 */

import Image from "next/image";
import Link from "next/link";
import { Tag, ChevronLeft, ChevronRight } from "lucide-react";
import type { PublishedBlogDetail, AdjacentPost } from "@/lib/blogs";
import { JsonLd } from "@/app/components/seo/JsonLd";
import { faqPageJsonLd } from "@/lib/structured-data";
import { siteConfig } from "@/config/site";

interface BlogDetailContentProps {
  blog: PublishedBlogDetail;
  prevPost: AdjacentPost | null;
  nextPost: AdjacentPost | null;
  recentPosts: {
    title: string;
    slug: string;
    imageUrl?: string;
    publishedAt: string;
  }[];
}

export function BlogDetailContent({
  blog,
  prevPost,
  nextPost,
  recentPosts,
}: BlogDetailContentProps) {
  const { contentHtml, faqs } = extractFaqFromHtml(blog.content);
  const blogUrl = `${siteConfig.url.replace(/\/+$/, "")}/blog/${blog.slug}`;

  return (
    <section className="bg-vg-dark spad">
      <div className="container mx-auto">
        <div className="flex justify-center">
          <div className="w-full max-w-[730px]">
            {faqs.length > 0 && <JsonLd data={faqPageJsonLd({ url: blogUrl, faqs })} />}

            {/* Main content (rendered as HTML) */}
            <article
              className="blog-detail-body text-vg-para text-lg font-light leading-[29px] mb-12"
              dangerouslySetInnerHTML={{ __html: contentHtml }}
            />

            {/* Optional FAQ / Q&A block for featured snippets */}
            {faqs.length > 0 && (
              <section
                aria-labelledby="blog-faq-heading"
                className="pb-[60px] border-b border-white/10 mb-16"
              >
                <h2
                  id="blog-faq-heading"
                  className="text-white font-heading font-bold uppercase mb-6 text-center"
                >
                  Questions & Answers
                </h2>
                <dl className="space-y-6">
                  {faqs.map((f) => (
                    <div key={f.question}>
                      <dt className="text-white font-bold leading-[23px] mb-2">
                        {f.question}
                      </dt>
                      <dd className="text-vg-para font-light leading-[29px]">
                        {f.answer}
                      </dd>
                    </div>
                  ))}
                </dl>
              </section>
            )}

            {/* Tags */}
            {blog.keywords.length > 0 && (
              <div className="pb-[60px] border-b border-white/10 mb-16">
                <span className="inline-flex items-center gap-2 text-white text-[15px] font-light mr-6">
                  <Tag className="w-4 h-4" /> Tag:
                </span>
                {blog.keywords.map((tag) => (
                  <span
                    key={tag}
                    className="inline-block text-white text-base font-light px-4 py-2 mr-3 mb-1 bg-white/10"
                  >
                    {tag}
                  </span>
                ))}
                <div className="mt-6 text-sm">
                  <span className="text-vg-para font-light mr-3">
                    Explore related:
                  </span>
                  <Link
                    href="/services"
                    className="text-white/90 hover:text-vg-primary transition-colors underline underline-offset-4 mr-4"
                  >
                    Services
                  </Link>
                  <Link
                    href="/portfolio"
                    className="text-white/90 hover:text-vg-primary transition-colors underline underline-offset-4"
                  >
                    Portfolio
                  </Link>
                </div>
              </div>
            )}

            {/* Previous / Next Post Navigation */}
            {(prevPost || nextPost) && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-10">
                {/* Previous */}
                {prevPost ? (
                  <Link href={`/blog/${prevPost.slug}`} className="block group">
                    <h5 className="text-white text-[15px] font-bold uppercase mb-6 flex items-center gap-1.5">
                      <ChevronLeft className="w-5 h-5" /> Previous posts
                    </h5>
                    <div className="flex gap-6">
                      {prevPost.imageUrl && (
                        <Image
                          src={prevPost.imageUrl}
                          alt={prevPost.title}
                          width={100}
                          height={70}
                          className="object-cover flex-shrink-0"
                        />
                      )}
                      <div className="overflow-hidden">
                        <h6 className="text-white font-bold leading-[21px] mb-1 group-hover:text-vg-primary transition-colors">
                          {prevPost.title}
                        </h6>
                        <span className="text-[#777] text-sm font-light">
                          {prevPost.publishedAt}
                        </span>
                      </div>
                    </div>
                  </Link>
                ) : (
                  <div />
                )}

                {/* Next */}
                {nextPost ? (
                  <Link href={`/blog/${nextPost.slug}`} className="block group">
                    <h5 className="text-white text-[15px] font-bold uppercase mb-6 flex items-center justify-end gap-1.5">
                      Next posts <ChevronRight className="w-5 h-5" />
                    </h5>
                    <div className="flex flex-row-reverse gap-6">
                      {nextPost.imageUrl && (
                        <Image
                          src={nextPost.imageUrl}
                          alt={nextPost.title}
                          width={100}
                          height={70}
                          className="object-cover flex-shrink-0"
                        />
                      )}
                      <div className="overflow-hidden text-right">
                        <h6 className="text-white font-bold leading-[21px] mb-1 group-hover:text-vg-primary transition-colors">
                          {nextPost.title}
                        </h6>
                        <span className="text-[#777] text-sm font-light">
                          {nextPost.publishedAt}
                        </span>
                      </div>
                    </div>
                  </Link>
                ) : (
                  <div />
                )}
              </div>
            )}

            {/* Recent Posts */}
            {recentPosts.length > 0 && (
              <div className="mb-16">
                <h4 className="text-white font-heading font-bold uppercase mb-9 text-center">
                  Recent Posts
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                  {recentPosts.map((rp) => (
                    <Link
                      key={rp.slug}
                      href={`/blog/${rp.slug}`}
                      className="block group"
                    >
                      {rp.imageUrl && (
                        <Image
                          src={rp.imageUrl}
                          alt={rp.title}
                          width={360}
                          height={220}
                          className="w-full object-cover mb-5"
                        />
                      )}
                      <h5 className="text-white font-bold leading-[23px] mb-1 group-hover:text-vg-primary transition-colors">
                        {rp.title}
                      </h5>
                      <span className="text-[#777] text-sm font-light">
                        {rp.publishedAt}
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Comment Form (UI shell only) */}
            <CommentFormSection />
          </div>
        </div>
      </div>
    </section>
  );
}

function extractFaqFromHtml(html: string): {
  contentHtml: string;
  faqs: { question: string; answer: string }[];
} {
  /**
   * Optional editor format (inside blog HTML):
   * <!--faq:[{"question":"...","answer":"..."},{"question":"...","answer":"..."}]-->
   *
   * If present, we remove the marker from HTML and render a semantic Q&A block + FAQPage JSON-LD.
   */
  const pattern = /<!--\s*faq\s*:\s*([\s\S]*?)\s*-->/i;
  const match = html.match(pattern);
  if (!match) return { contentHtml: html, faqs: [] };

  const raw = match[1]?.trim();
  if (!raw) return { contentHtml: html.replace(pattern, ""), faqs: [] };

  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return { contentHtml: html.replace(pattern, ""), faqs: [] };
    const faqs = parsed
      .filter(
        (x: any) =>
          x &&
          typeof x === "object" &&
          typeof x.question === "string" &&
          typeof x.answer === "string",
      )
      .map((x: any) => ({ question: x.question.trim(), answer: x.answer.trim() }))
      .filter((x: any) => x.question && x.answer);

    return { contentHtml: html.replace(pattern, ""), faqs };
  } catch {
    return { contentHtml: html.replace(pattern, ""), faqs: [] };
  }
}

/* ─── Comment form (inlined as a server-rendered UI shell) ─── */
function CommentFormSection() {
  return (
    <div>
      <h4 className="text-white font-heading font-bold uppercase mb-9 text-center">
        Leave a comment
      </h4>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 mb-5">
        <input
          type="text"
          placeholder="Name"
          className="h-[50px] w-full border border-white/50 bg-transparent text-base text-vg-para pl-5 font-light placeholder:text-vg-para focus:outline-none focus:border-vg-primary transition-colors"
        />
        <input
          type="email"
          placeholder="Email"
          className="h-[50px] w-full border border-white/50 bg-transparent text-base text-vg-para pl-5 font-light placeholder:text-vg-para focus:outline-none focus:border-vg-primary transition-colors"
        />
        <input
          type="text"
          placeholder="Website"
          className="h-[50px] w-full border border-white/50 bg-transparent text-base text-vg-para pl-5 font-light placeholder:text-vg-para focus:outline-none focus:border-vg-primary transition-colors"
        />
      </div>
      <textarea
        placeholder="Comment"
        rows={4}
        className="w-full border border-white/50 bg-transparent text-base text-vg-para pt-3 pl-5 font-light placeholder:text-vg-para resize-none mb-4 focus:outline-none focus:border-vg-primary transition-colors"
      />
      <button
        type="button"
        className="inline-block bg-vg-primary text-white font-heading font-bold text-[15px] tracking-[2px] uppercase px-8 py-3.5 hover:opacity-90 transition-opacity"
      >
        Send Message
      </button>
    </div>
  );
}
