/**
 * RelatedPortfolio — Displays related portfolio items at the bottom of a detail page.
 * Accepts published portfolio items from MongoDB.
 * Server Component.
 */

import { PortfolioCard } from "@/app/components/ui/PortfolioCard";
import type { PublishedPortfolioListItem } from "@/lib/portfolio";

interface RelatedPortfolioProps {
  items: PublishedPortfolioListItem[];
}

export function RelatedPortfolio({ items }: RelatedPortfolioProps) {
  if (items.length === 0) return null;

  return (
    <section className="spad bg-vg-dark">
      <div className="container mx-auto px-4">
        {/* Section heading */}
        <div className="text-center mb-14">
          <span className="text-vg-primary font-heading text-[15px] tracking-[2px] uppercase block mb-3">
            Explore More
          </span>
          <h2 className="text-white font-heading font-bold text-2xl md:text-[36px]">
            Related Projects
          </h2>
        </div>

        {/* Grid of related items */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8">
          {items.map((item) => (
            <PortfolioCard
              key={item.slug}
              title={item.title}
              slug={item.slug}
              coverImage={item.coverImage}
              tags={item.industry ? [item.industry] : []}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
