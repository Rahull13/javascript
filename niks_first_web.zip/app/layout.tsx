import type { Metadata } from "next";
import { Play, Josefin_Sans } from "next/font/google";
import "./globals.css";
import { Header } from "./components/layout/Header";
import { Footer } from "./components/layout/Footer";
import { siteConfig } from "@/config/site";
import { Providers } from "./providers";
import { JsonLd } from "@/app/components/seo/JsonLd";
import { localBusinessJsonLd, organizationJsonLd } from "@/lib/structured-data";

/* ─── Font Setup (Videograph Theme: Play + Josefin Sans) ─── */
const play = Play({
  subsets: ["latin"],
  weight: ["400", "700"],
  variable: "--font-play",
  display: "swap",
});

const josefinSans = Josefin_Sans({
  subsets: ["latin"],
  weight: ["300", "400", "600", "700"],
  variable: "--font-josefin",
  display: "swap",
});

/* ─── Global SEO Metadata ─── */
export const metadata: Metadata = {
  title: {
    default: siteConfig.name,
    template: `%s | ${siteConfig.name}`,
  },
  description: siteConfig.description,
  keywords: [
    "video production",
    "videography",
    "motion graphics",
    "video editing",
    "commercial video",
    "broadcast production",
  ],
  authors: [{ name: siteConfig.name }],
  creator: siteConfig.name,
  metadataBase: new URL(siteConfig.url),
  openGraph: {
    type: "website",
    locale: "en_US",
    url: siteConfig.url,
    title: siteConfig.name,
    description: siteConfig.description,
    siteName: siteConfig.name,
    images: [
      {
        url: siteConfig.ogImage,
        width: 1200,
        height: 630,
        alt: siteConfig.name,
      },
    ],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${play.variable} ${josefinSans.variable}`}
      suppressHydrationWarning
    >
      <body className="min-h-screen font-body antialiased">
        <Providers>
          <JsonLd data={organizationJsonLd()} />
          <JsonLd data={localBusinessJsonLd()} />
          <Header />
          <main>{children}</main>
          <Footer />
        </Providers>
      </body>
    </html>
  );
}
