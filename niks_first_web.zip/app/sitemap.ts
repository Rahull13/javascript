import type { MetadataRoute } from "next";
import { siteConfig } from "@/config/site";
import { getPublishedServices } from "@/lib/services";
import { getPublishedBlogs } from "@/lib/blogs";
import { getPublishedPortfolios } from "@/lib/portfolio";

export const runtime = "nodejs";

function withBase(path: string) {
  const base = siteConfig.url.replace(/\/+$/, "");
  if (path === "/") return `${base}/`;
  return `${base}${path.startsWith("/") ? path : `/${path}`}`;
}

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const now = new Date();

  const [services, blogs, portfolios] = await Promise.all([
    getPublishedServices(),
    getPublishedBlogs(),
    getPublishedPortfolios(),
  ]);

  const entries: MetadataRoute.Sitemap = [
    // Home
    {
      url: withBase("/"),
      lastModified: now,
      changeFrequency: "weekly",
      priority: 1.0,
    },
    // About
    {
      url: withBase("/about"),
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.7,
    },
    // Services index
    {
      url: withBase("/services"),
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.9,
    },
    // Blog index
    {
      url: withBase("/blog"),
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.8,
    },
    // Portfolio index
    {
      url: withBase("/portfolio"),
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.7,
    },
  ];

  // Services detail
  for (const s of services) {
    entries.push({
      url: withBase(`/services/${s.slug}`),
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.9,
    });
  }

  // Blog detail
  for (const b of blogs) {
    entries.push({
      url: withBase(`/blog/${b.slug}`),
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.8,
    });
  }

  // Portfolio detail
  for (const p of portfolios) {
    entries.push({
      url: withBase(`/portfolio/${p.slug}`),
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.7,
    });
  }

  return entries;
}
