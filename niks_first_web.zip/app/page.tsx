/**
 * Home Page — Videograph Theme
 * Fetches Page CMS data (slug: "home") and passes section overrides to components.
 * Renders only when the "home" page is published; section-level data falls back to defaults.
 */

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { HeroSlider } from "./components/sections/HeroSlider";
import { ServicesSection } from "./components/sections/ServicesSection";
import { WorkGallery } from "./components/sections/WorkGallery";
import { CounterStats, CounterStatsMobile } from "./components/sections/CounterStats";
import { TeamSection } from "./components/sections/TeamSection";
import { LatestBlogSlider } from "./components/sections/LatestBlogSlider";
import { CallToAction } from "./components/sections/CallToAction";

import {
  getPublishedPage,
  extractHeroSlides,
  extractCounterStats,
  extractWorkItems,
  extractTeamMembers,
  extractCta,
  extractServicesSectionData,
} from "@/lib/pages";
import { getPublishedServices } from "@/lib/services";
import { getPublishedBlogs } from "@/lib/blogs";
import { generateMetadata as buildMetadata } from "@/lib/seo";
import { siteConfig } from "@/config/site";

export const runtime = "nodejs";

/* ─── Dynamic SEO Metadata ─── */
export async function generateMetadata(): Promise<Metadata> {
  const page = await getPublishedPage("home");
  if (!page) return {};

  const title = page.seo?.title || page.metaTitle || page.title || "Home";
  const description = page.seo?.description || page.metaDescription || undefined;
  const keywords = page.seo?.keywords || page.keywords || undefined;
  const image = page.seo?.ogImage || siteConfig.ogImage;

  return buildMetadata({
    title,
    description,
    keywords,
    image,
    url: `${siteConfig.url}/`,
    type: "website",
  });
}

export default async function HomePage() {
  const page = await getPublishedPage("home");
  if (!page) {
    return notFound();
  }

  const sections = page.sections ?? {};

  // Extract CMS overrides (undefined = use component defaults)
  const heroSlides = extractHeroSlides(sections);
  const servicesSectionData = extractServicesSectionData(sections);
  const workItems = extractWorkItems(sections);
  const counterStats = extractCounterStats(sections);
  const teamMembers = extractTeamMembers(sections);
  const ctaData = extractCta(sections);

  // Fetch published services from DB for the home services section
  const dbServices = await getPublishedServices();

  // Fetch published blogs from DB for the latest blog slider
  const dbBlogs = await getPublishedBlogs();
  const blogSlides = dbBlogs.length > 0
    ? dbBlogs.map((b) => ({
        title: b.title,
        date: b.publishedAt,
        comments: 0,
        excerpt: b.excerpt,
        href: `/blog/${b.slug}`,
      }))
    : undefined;

  return (
    <>
      {/* Hero Slider */}
      <HeroSlider slides={heroSlides} />

      {/* Services — "What We Do?" */}
      <ServicesSection data={servicesSectionData} dbServices={dbServices} />

      {/* Work Gallery / Portfolio */}
      <WorkGallery items={workItems} />

      {/* Counter Stats: Desktop diamond layout + Mobile card layout */}
      <CounterStats stats={counterStats} />
      <CounterStatsMobile stats={counterStats} />

      {/* Team Section */}
      <TeamSection members={teamMembers} />

      {/* Latest Blog Posts Slider */}
      <LatestBlogSlider blogs={blogSlides} />

      {/* Call to Action Banner */}
      <CallToAction data={ctaData} />
    </>
  );
}
