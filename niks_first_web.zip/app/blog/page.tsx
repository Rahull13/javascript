/**
 * Blog Listing Page — /blog
 * Fetches published blogs from MongoDB and displays in a responsive grid.
 * Falls back gracefully when no blogs are available.
 */

import { Breadcrumb } from "@/app/components/ui/Breadcrumb";
import { BlogCard } from "@/app/components/ui/BlogCard";
import { getPublishedBlogs } from "@/lib/blogs";
import { ChevronLeft, ChevronRight } from "lucide-react";

export const runtime = "nodejs";

export default async function BlogPage() {
  const blogs = await getPublishedBlogs();

  return (
    <>
      {/* Breadcrumb Hero Banner */}
      <Breadcrumb
        title="Our Blog"
        items={[
          { label: "Home", href: "/" },
          { label: "Blog" },
        ]}
      />

      {/* Blog Grid */}
      <section className="bg-vg-dark spad">
        <div className="container mx-auto">
          {blogs.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-vg-para text-lg">
                No blog posts available at the moment. Please check back soon.
              </p>
            </div>
          ) : (
            <>
              {/* Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8">
                {blogs.map((post) => (
                  <BlogCard
                    key={post.slug}
                    title={post.title}
                    date={post.publishedAt}
                    comments={0}
                    excerpt={post.excerpt}
                    href={`/blog/${post.slug}`}
                  />
                ))}
              </div>

              {/* Pagination (placeholder — pagination-ready, not functional yet) */}
              <div className="flex items-center justify-center gap-2 pt-5">
                <button className="inline-flex items-center gap-1 text-[15px] text-white uppercase mr-5 hover:text-vg-primary transition-colors">
                  <ChevronLeft className="w-4 h-4 opacity-50" />
                  Prev
                </button>
                <span className="inline-flex items-center justify-center h-[50px] w-[50px] bg-white/10 text-white text-lg">
                  1
                </span>
                <button className="inline-flex items-center gap-1 text-[15px] text-white uppercase ml-4 hover:text-vg-primary transition-colors">
                  Next
                  <ChevronRight className="w-4 h-4 opacity-50" />
                </button>
              </div>
            </>
          )}
        </div>
      </section>
    </>
  );
}
