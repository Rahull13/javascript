/**
 * Blog Detail Page — /blog/[slug]
 * Fetches a single published blog from MongoDB by slug.
 * Returns 404 if the blog doesn't exist or is in draft status.
 */

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { BlogDetailHero } from "@/app/components/sections/BlogDetailHero";
import { BlogDetailContent } from "@/app/components/sections/BlogDetailContent";
import { JsonLd } from "@/app/components/seo/JsonLd";
import {
  getPublishedBlogBySlug,
  getAdjacentBlogs,
  getRecentBlogs,
} from "@/lib/blogs";
import { generateMetadata as buildMetadata } from "@/lib/seo";
import { siteConfig } from "@/config/site";
import { articleJsonLd } from "@/lib/structured-data";

export const runtime = "nodejs";

interface BlogDetailPageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata(
  props: BlogDetailPageProps,
): Promise<Metadata> {
  const { slug } = await props.params;
  const blog = await getPublishedBlogBySlug(slug);
  if (!blog) return {};

  const title = blog.seo?.title || blog.title;
  const description = blog.seo?.description || blog.excerpt || undefined;
  const keywords = blog.seo?.keywords || blog.keywords || undefined;
  const image = blog.seo?.ogImage || blog.imageUrl || siteConfig.ogImage;

  return buildMetadata({
    title,
    description,
    keywords,
    image,
    url: `${siteConfig.url}/blog/${blog.slug}`,
    type: "article",
  });
}

export default async function BlogDetailPage({
  params,
}: BlogDetailPageProps) {
  const { slug } = await params;
  const blog = await getPublishedBlogBySlug(slug);

  if (!blog) {
    notFound();
  }

  // Fetch adjacent posts and recent posts in parallel
  const [adjacent, recentPosts] = await Promise.all([
    getAdjacentBlogs(slug),
    getRecentBlogs(slug, 3),
  ]);

  return (
    <>
      <JsonLd
        data={articleJsonLd({
          headline: blog.title,
          description: blog.seo?.description || blog.excerpt || undefined,
          slug: blog.slug,
          image: blog.seo?.ogImage || blog.imageUrl || siteConfig.ogImage,
          authorName: blog.author || undefined,
          datePublished: blog.publishedAtIso,
          dateModified: blog.updatedAtIso,
        })}
      />
      {/* Full-width Hero */}
      <BlogDetailHero
        title={blog.title}
        author={blog.author}
        date={blog.publishedAt}
        heroImage={blog.imageUrl}
      />

      {/* Content Area */}
      <BlogDetailContent
        blog={blog}
        prevPost={adjacent.prev}
        nextPost={adjacent.next}
        recentPosts={recentPosts}
      />
    </>
  );
}
