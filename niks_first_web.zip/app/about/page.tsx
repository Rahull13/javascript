/**
 * About Page — Videograph Theme
 * Fetches Page CMS data (slug: "about") and passes section overrides to components.
 * Renders only when the "about" page is published; section-level data falls back to defaults.
 */

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Breadcrumb } from "@/app/components/ui/Breadcrumb";
import { AboutContent } from "@/app/components/sections/AboutContent";
import { TestimonialSlider } from "@/app/components/sections/TestimonialSlider";
import { CounterStats, CounterStatsMobile } from "@/app/components/sections/CounterStats";
import { TeamSection } from "@/app/components/sections/TeamSection";
import { generateMetadata as buildMetadata } from "@/lib/seo";
import { siteConfig } from "@/config/site";

import {
  getPublishedPage,
  extractCounterStats,
  extractTeamMembers,
  extractTestimonials,
  extractAboutData,
} from "@/lib/pages";
 
export const runtime = "nodejs";

/* ─── Dynamic SEO Metadata ─── */
export async function generateMetadata(): Promise<Metadata> {
  const page = await getPublishedPage("about");
  if (!page) {
    return buildMetadata({
      title: "About Us",
      description:
        "Learn about our award-winning video production team and the services we offer.",
      url: `${siteConfig.url}/about`,
      type: "website",
    });
  }

  const title = page.seo?.title || page.metaTitle || page.title || "About Us";
  const description =
    page.seo?.description ||
    page.metaDescription ||
    "Learn about our award-winning video production team and the services we offer.";
  const keywords = page.seo?.keywords || page.keywords || undefined;
  const image = page.seo?.ogImage || siteConfig.ogImage;

  return buildMetadata({
    title,
    description,
    keywords,
    image,
    url: `${siteConfig.url}/about`,
    type: "website",
  });
}

export default async function AboutPage() {
  const page = await getPublishedPage("about");
  if (!page) {
    return notFound();
  }

  const sections = page.sections ?? {};

  // Extract CMS overrides
  const aboutData = extractAboutData(sections);
  const testimonials = extractTestimonials(sections);
  const counterStats = extractCounterStats(sections);
  const teamMembers = extractTeamMembers(sections);

  return (
    <>
      {/* Breadcrumb Hero Banner */}
      <Breadcrumb
        title="About us"
        items={[
          { label: "Home", href: "/" },
          { label: "About" },
        ]}
      />

      {/* Who We Are — Images + Text */}
      <AboutContent data={aboutData} />

      {/* Client Testimonials Slider */}
      <TestimonialSlider testimonials={testimonials} />

      {/* Counter Stats: Diamond layout (desktop) + Card grid (mobile) */}
      <CounterStats stats={counterStats} />
      <CounterStatsMobile stats={counterStats} />

      {/* Team Section (reused from Home page) */}
      <TeamSection members={teamMembers} />
    </>
  );
}
