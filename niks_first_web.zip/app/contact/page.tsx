/**
 * Contact Page — /contact
 * Composes: Breadcrumb → Contact Widgets → Map + Form
 * Server Component (ContactForm is a nested Client Component).
 */

import { Breadcrumb } from "@/app/components/ui/Breadcrumb";
import { ContactWidgets } from "@/app/components/sections/ContactWidgets";
import { ContactForm } from "@/app/components/sections/ContactForm";

export default function ContactPage() {
  return (
    <>
      {/* Breadcrumb Hero Banner */}
      <Breadcrumb
        title="Contact us"
        items={[
          { label: "Home", href: "/" },
          { label: "Contact" },
        ]}
      />

      {/* Contact Info Widgets (Address, Phone, Email) */}
      <ContactWidgets />

      {/* Map + Contact Form */}
      <section className="bg-vg-dark spad pt-0 overflow-hidden">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Google Map (UI-only placeholder) */}
            <div className="h-[450px]">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387190.2798902705!2d-74.25986790365917!3d40.697670067823786!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2sbd!4v1596152431947!5m2!1sen!2sbd"
                className="w-full h-full border-0"
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Location map"
              />
            </div>

            {/* Contact Form */}
            <ContactForm />
          </div>
        </div>
      </section>
    </>
  );
}
