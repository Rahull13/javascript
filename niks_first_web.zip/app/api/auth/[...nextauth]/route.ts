import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { connectToDatabase } from "@/lib/mongodb";
import User from "@/models/User";

export const runtime = "nodejs";

export const { handlers, signIn, signOut, auth } = NextAuth({
  providers: [
    Credentials({
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          console.log("[NextAuth] Missing credentials");
          return null;
        }

        // STATIC TEST LOGIN (for development/testing only)
        // Remove this in production!
        const TEST_EMAIL = "admin@moonrockfintax.com";
        const TEST_PASSWORD = "Admin@123";
        
        const emailMatch = (credentials.email as string).toLowerCase().trim() === TEST_EMAIL.toLowerCase().trim();
        const passwordMatch = (credentials.password as string) === TEST_PASSWORD;
        
        console.log("[NextAuth] Login attempt:", {
          email: credentials.email,
          emailMatch,
          passwordMatch,
        });
        
        if (emailMatch && passwordMatch) {
          // Return test admin user
          console.log("[NextAuth] Using static test login");
          return {
            id: "test-admin-id",
            email: TEST_EMAIL,
            name: "Test Admin",
            role: "admin",
          };
        }

        await connectToDatabase();

        // Normal database lookup with proper email normalization
        const email = (credentials.email as string).toLowerCase().trim();
        const user = await User.findOne({ email });

        if (!user) {
          console.error(`[NextAuth] User not found: ${email}`);
          return null;
        }

        const isPasswordValid = await user.comparePassword(credentials.password as string);

        if (!isPasswordValid) {
          console.error(`[NextAuth] Invalid password for user: ${email}`);
          return null;
        }

        if (user.role !== "admin") {
          console.error(`[NextAuth] User is not admin: ${email}, role: ${user.role}`);
          return null;
        }

        return {
          id: user._id.toString(),
          email: user.email,
          name: user.name,
          role: user.role,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.email = user.email;
        token.name = user.name;
        token.role = user.role;
        console.log("[NextAuth] JWT callback - user:", user);
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string;
        session.user.email = token.email as string;
        session.user.name = token.name as string;
        session.user.role = token.role as string;
        console.log("[NextAuth] Session callback - session:", session);
      }
      return session;
    },
  },
  pages: {
    signIn: "/admin/login",
  },
  session: {
    strategy: "jwt",
  },
  secret: process.env.NEXTAUTH_SECRET || "development-secret-key-change-in-production",
});

export const { GET, POST } = handlers;
