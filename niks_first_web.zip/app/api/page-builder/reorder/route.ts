import { NextResponse } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import PageBuilder from "@/models/PageBuilder";

export const runtime = "nodejs";

/**
 * PUT /api/page-builder/reorder
 *
 * Body:
 * {
 *   "page": "home",
 *   "order": ["hero1", "services1", "testimonials1"]
 * }
 *
 * Reorders sections for the given page based on the provided array of IDs.
 * Any sections not in the array keep their relative order and are appended after.
 */
export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const page = String(body.page || "").toLowerCase().trim();
    const orderIds: string[] = Array.isArray(body.order)
      ? body.order.map((id: any) => String(id))
      : [];

    if (!page) {
      return NextResponse.json({ error: "Missing page" }, { status: 400 });
    }

    await connectToDatabase();
    const doc = await PageBuilder.findOne({ page });

    if (!doc) {
      return NextResponse.json({ error: "Page not found" }, { status: 404 });
    }

    const sections = doc.sections || [];
    const byId = new Map(sections.map((s: any) => [String(s.id), s]));

    const reordered: any[] = [];

    // First, push sections in the explicit order
    for (const id of orderIds) {
      const section = byId.get(id);
      if (section) {
        reordered.push(section);
        byId.delete(id);
      }
    }

    // Then append any remaining sections, preserving their previous order
    for (const section of sections) {
      if (byId.has(String(section.id))) {
        reordered.push(section);
        byId.delete(String(section.id));
      }
    }

    const normalized = reordered.map((s, index) => ({
      ...s.toObject?.() ?? s,
      order: index + 1,
    }));

    doc.sections = normalized as any;
    await doc.save();

    return NextResponse.json(
      {
        page: doc.page,
        sections: doc.sections,
      },
      { status: 200 },
    );
  } catch (error: any) {
    console.error("[PageBuilder][PUT /reorder] Failed to reorder sections:", error);
    return NextResponse.json(
      { error: "Failed to reorder sections" },
      { status: 500 },
    );
  }
}

