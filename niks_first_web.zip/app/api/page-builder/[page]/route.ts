import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import PageBuilder from "@/models/PageBuilder";

export const runtime = "nodejs";

// GET /api/page-builder/[page]
export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ page: string }> },
) {
  const { page: rawPage } = await context.params;
  const page = rawPage.toLowerCase();

  try {
    await connectToDatabase();
    const doc = await PageBuilder.findOne({ page }).lean();

    if (!doc) {
      // Return an empty config so the UI can bootstrap defaults
      return NextResponse.json(
        {
          page,
          sections: [],
        },
        { status: 200 },
      );
    }

    return NextResponse.json(
      {
        page: doc.page,
        sections: (doc.sections || []).sort(
          (a: any, b: any) => (a.order ?? 0) - (b.order ?? 0),
        ),
      },
      { status: 200 },
    );
  } catch (error: any) {
    console.error("[PageBuilder][GET] Failed to fetch config:", error);
    return NextResponse.json(
      { error: "Failed to load page builder configuration" },
      { status: 500 },
    );
  }
}

// POST /api/page-builder/[page] — upsert full section configuration for a page
export async function POST(
  req: NextRequest,
  context: { params: Promise<{ page: string }> },
) {
  const { page: rawPage } = await context.params;
  const page = rawPage.toLowerCase();

  try {
    const body = await req.json();
    const sections = Array.isArray(body.sections) ? body.sections : [];

    const normalizedSections: {
      id: string;
      type: string;
      order: number;
      enabled: boolean;
      data: Record<string, any>;
    }[] = sections
      .map((s: any, index: number) => ({
        id: String(s.id ?? `section-${index + 1}`),
        type: String(s.type ?? "custom"),
        enabled: typeof s.enabled === "boolean" ? s.enabled : true,
        data: s.data && typeof s.data === "object" ? s.data : {},
        order:
          typeof s.order === "number"
            ? s.order
            : typeof s.order === "string"
              ? Number.parseInt(s.order, 10) || index + 1
              : index + 1,
      }))
      .sort(
        (
          a: { order: number },
          b: { order: number },
        ) => a.order - b.order,
      )
      .map(
        (
          s: {
            id: string;
            type: string;
            order: number;
            enabled: boolean;
            data: Record<string, any>;
          },
          index: number,
        ) => ({
          ...s,
          order: index + 1,
        }),
      );

    await connectToDatabase();

    const doc = await PageBuilder.findOneAndUpdate(
      { page },
      { page, sections: normalizedSections },
      { upsert: true, new: true },
    ).lean();

    return NextResponse.json(
      {
        page: doc.page,
        sections: doc.sections,
      },
      { status: 200 },
    );
  } catch (error: any) {
    console.error("[PageBuilder][POST] Failed to save config:", error);
    return NextResponse.json(
      { error: "Failed to save page builder configuration" },
      { status: 500 },
    );
  }
}

