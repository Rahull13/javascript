/**
 * Portfolio Listing Page — /portfolio
 * Fetches published portfolios from MongoDB and displays in a filterable grid.
 * Falls back gracefully when no items are available.
 */

import { Breadcrumb } from "@/app/components/ui/Breadcrumb";
import { PortfolioGrid } from "@/app/components/sections/PortfolioGrid";
import { getPublishedPortfolios, getPortfolioIndustries } from "@/lib/portfolio";
import { ChevronLeft, ChevronRight } from "lucide-react";

export const runtime = "nodejs";

export default async function PortfolioPage() {
  const [portfolios, industries] = await Promise.all([
    getPublishedPortfolios(),
    getPortfolioIndustries(),
  ]);

  return (
    <>
      {/* Breadcrumb Hero Banner */}
      <Breadcrumb
        title="Portfolio"
        items={[
          { label: "Home", href: "/" },
          { label: "Portfolio" },
        ]}
      />

      {/* Filterable Portfolio Grid — dynamic from MongoDB */}
      <PortfolioGrid portfolios={portfolios} industries={industries} />

      {/* Pagination (placeholder — CMS-ready, not functional yet) */}
      {portfolios.length > 0 && (
        <section className="bg-vg-dark pb-24">
          <div className="container mx-auto">
            <div className="flex items-center justify-center gap-2 pt-5">
              <button className="inline-flex items-center gap-1 text-[15px] text-white uppercase mr-5 hover:text-vg-primary transition-colors">
                <ChevronLeft className="w-4 h-4 opacity-50" />
                Prev
              </button>
              <span className="inline-flex items-center justify-center h-[50px] w-[50px] bg-white/10 text-white text-lg">
                1
              </span>
              <button className="inline-flex items-center gap-1 text-[15px] text-white uppercase ml-4 hover:text-vg-primary transition-colors">
                Next
                <ChevronRight className="w-4 h-4 opacity-50" />
              </button>
            </div>
          </div>
        </section>
      )}
    </>
  );
}
