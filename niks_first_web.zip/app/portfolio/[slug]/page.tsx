/**
 * Portfolio Detail Page — /portfolio/[slug]
 * Fetches a single published portfolio from MongoDB by slug.
 * Returns 404 if the item doesn't exist or is in draft status.
 */

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Breadcrumb } from "@/app/components/ui/Breadcrumb";
import { PortfolioDetailContent } from "@/app/components/sections/PortfolioDetailContent";
import { PortfolioGallery } from "@/app/components/sections/PortfolioGallery";
import { RelatedPortfolio } from "@/app/components/sections/RelatedPortfolio";
import { ServicesCTA } from "@/app/components/sections/ServicesCTA";
import { JsonLd } from "@/app/components/seo/JsonLd";
import {
  getPublishedPortfolioBySlug,
  getPublishedPortfolios,
} from "@/lib/portfolio";
import { generateMetadata as buildMetadata } from "@/lib/seo";
import { siteConfig } from "@/config/site";
import { creativeWorkJsonLd } from "@/lib/structured-data";

export const runtime = "nodejs";

interface PortfolioDetailPageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata(
  props: PortfolioDetailPageProps,
): Promise<Metadata> {
  const { slug } = await props.params;
  const portfolio = await getPublishedPortfolioBySlug(slug);
  if (!portfolio) return {};

  const title = portfolio.seo?.title || portfolio.title;
  const description =
    portfolio.seo?.description || portfolio.description || undefined;
  const keywords = portfolio.seo?.keywords || undefined;
  const image =
    portfolio.seo?.ogImage ||
    portfolio.images?.[0]?.url ||
    siteConfig.ogImage;

  return buildMetadata({
    title,
    description,
    keywords,
    image,
    url: `${siteConfig.url}/portfolio/${portfolio.slug}`,
    type: "website",
  });
}

export default async function PortfolioDetailPage({
  params,
}: PortfolioDetailPageProps) {
  const { slug } = await params;
  const portfolio = await getPublishedPortfolioBySlug(slug);

  if (!portfolio) {
    notFound();
  }

  // Fetch related items (exclude current, take 3)
  const allPortfolios = await getPublishedPortfolios();
  const relatedItems = allPortfolios
    .filter((p) => p.slug !== slug)
    .slice(0, 3);

  // Map DB images to gallery format {src, alt}
  const galleryImages = portfolio.images.map((img, idx) => ({
    src: img.url,
    alt: img.alt || `${portfolio.title} — Image ${idx + 1}`,
  }));

  return (
    <>
      <JsonLd
        data={creativeWorkJsonLd({
          name: portfolio.title,
          description:
            portfolio.seo?.description || portfolio.description || undefined,
          slug: portfolio.slug,
          images:
            portfolio.images && portfolio.images.length > 0
              ? portfolio.images.map((i) => i.url)
              : portfolio.seo?.ogImage
                ? [portfolio.seo.ogImage]
                : [siteConfig.ogImage],
        })}
      />
      {/* Breadcrumb Hero Banner */}
      <Breadcrumb
        title={portfolio.title}
        items={[
          { label: "Home", href: "/" },
          { label: "Portfolio", href: "/portfolio" },
          { label: portfolio.title },
        ]}
      />

      {/* Project Overview + Sidebar */}
      <PortfolioDetailContent portfolio={portfolio} />

      {/* Image Gallery with Lightbox */}
      {galleryImages.length > 0 && (
        <PortfolioGallery images={galleryImages} title={portfolio.title} />
      )}

      {/* CTA Banner */}
      <ServicesCTA />

      {/* Related Projects */}
      <RelatedPortfolio items={relatedItems} />
    </>
  );
}
