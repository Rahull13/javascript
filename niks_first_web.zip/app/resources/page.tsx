import { Metadata } from 'next';
import Link from 'next/link';
import { FileText, BookOpen, Calculator, TrendingUp, ArrowRight, Calendar } from 'lucide-react';

export const metadata: Metadata = {
  title: "Resources - Financial & Tax Resources | Moonrock Fintax",
  description: "Access valuable financial and tax resources including guides, articles, calculators, and tools to help you make informed financial decisions.",
  keywords: ["tax resources", "financial guides", "tax calculators", "financial planning resources", "tax tips"],
};

export default function ResourcesPage() {
  const resources = [
    {
      icon: <FileText className="w-8 h-8" />,
      title: "Tax Planning Guide 2024",
      description: "Comprehensive guide to tax planning strategies for individuals and businesses.",
      category: "Tax Planning",
      date: "January 15, 2024"
    },
    {
      icon: <Calculator className="w-8 h-8" />,
      title: "Tax Savings Calculator",
      description: "Calculate potential tax savings with our interactive calculator tool.",
      category: "Tools",
      date: "January 10, 2024"
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: "Financial Planning Best Practices",
      description: "Learn the essential strategies for effective financial planning and wealth management.",
      category: "Financial Planning",
      date: "January 5, 2024"
    },
    {
      icon: <BookOpen className="w-8 h-8" />,
      title: "Business Tax Deductions Guide",
      description: "Complete list of tax deductions available for small businesses and entrepreneurs.",
      category: "Business",
      date: "December 28, 2023"
    },
    {
      icon: <FileText className="w-8 h-8" />,
      title: "Year-End Tax Checklist",
      description: "Essential checklist to prepare for tax season and maximize your deductions.",
      category: "Tax Planning",
      date: "December 20, 2023"
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: "Investment Tax Strategies",
      description: "Learn how to optimize your investment portfolio for tax efficiency.",
      category: "Investments",
      date: "December 15, 2023"
    }
  ];

  const categories = ["All", "Tax Planning", "Financial Planning", "Business", "Investments", "Tools"];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Financial & Tax Resources
            </h1>
            <p className="text-xl text-blue-100">
              Access valuable guides, tools, and insights to help you make informed financial decisions
            </p>
          </div>
        </div>
      </section>

      {/* Resources Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          {/* Category Filter */}
          <div className="flex flex-wrap gap-4 mb-12 justify-center">
            {categories.map((category) => (
              <button
                key={category}
                className="px-6 py-2 rounded-full border-2 border-gray-300 text-gray-700 hover:border-blue-600 hover:text-blue-600 transition-all font-medium"
              >
                {category}
              </button>
            ))}
          </div>

          {/* Resources Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {resources.map((resource, index) => (
              <div
                key={index}
                className="bg-white border-2 border-gray-100 rounded-2xl p-6 hover:shadow-xl transition-all hover:border-blue-200"
              >
                <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center text-white mb-4">
                  {resource.icon}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                  <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full font-semibold text-xs">
                    {resource.category}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    {resource.date}
                  </span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{resource.title}</h3>
                <p className="text-gray-600 mb-4">{resource.description}</p>
                <Link
                  href="#"
                  className="inline-flex items-center gap-2 text-blue-600 font-semibold hover:text-purple-600 transition-colors"
                >
                  Read More
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto bg-white rounded-2xl p-12 shadow-xl text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Stay Updated with Financial Insights
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Subscribe to our newsletter for the latest tax tips, financial strategies, and industry updates
            </p>
            <form className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-6 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              />
              <button
                type="submit"
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3 rounded-lg font-semibold hover:shadow-xl transition-all"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}

