import { getContacts, updateContactStatus } from "./actions";

export const runtime = "nodejs";

export default async function ContactSubmissionsPage() {
  const contacts = await getContacts();

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Contact Submissions</h1>
        <p className="mt-1 text-sm text-gray-600">View and manage contact form submissions</p>
      </div>

      <div className="rounded-lg border border-gray-200 bg-white">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-gray-200 bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                  Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                  Email
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                  Subject
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                  Date
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium uppercase tracking-wider text-gray-500">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 bg-white">
              {contacts.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-sm text-gray-500">
                    No submissions yet.
                  </td>
                </tr>
              ) : (
                contacts.map((contact) => (
                  <tr key={contact.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{contact.name}</td>
                    <td className="px-6 py-4 text-sm text-gray-500">{contact.email}</td>
                    <td className="px-6 py-4 text-sm text-gray-500">{contact.subject}</td>
                    <td className="px-6 py-4">
                      <span
                        className={`inline-flex rounded-full px-2 py-1 text-xs font-medium ${
                          contact.status === "new"
                            ? "bg-blue-100 text-blue-800"
                            : contact.status === "read"
                            ? "bg-gray-100 text-gray-800"
                            : "bg-green-100 text-green-800"
                        }`}
                      >
                        {contact.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      {new Date(contact.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 text-right text-sm font-medium">
                      <details className="relative">
                        <summary className="cursor-pointer text-blue-600 hover:text-blue-900">
                          View
                        </summary>
                        <div className="absolute right-0 mt-2 w-96 bg-white border border-gray-200 rounded-lg shadow-lg p-4 z-10">
                          <div className="space-y-2 text-sm">
                            <div>
                              <span className="font-semibold">Phone:</span> {contact.phone || "N/A"}
                            </div>
                            <div>
                              <span className="font-semibold">Message:</span>
                              <p className="mt-1 text-gray-600">{contact.message}</p>
                            </div>
                            <div className="flex gap-2 pt-2">
                              <form action={async () => { "use server"; await updateContactStatus(contact.id, "read"); }}>
                                <button
                                  type="submit"
                                  className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded hover:bg-gray-200"
                                >
                                  Mark Read
                                </button>
                              </form>
                              <form action={async () => { "use server"; await updateContactStatus(contact.id, "replied"); }}>
                                <button
                                  type="submit"
                                  className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded hover:bg-green-200"
                                >
                                  Mark Replied
                                </button>
                              </form>
                            </div>
                          </div>
                        </div>
                      </details>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

