"use server";

import { connectToDatabase } from "@/lib/mongodb";
import Contact from "@/models/Contact";

export async function getContacts() {
  try {
    await connectToDatabase();
    const contacts = await Contact.find().sort({ createdAt: -1 });
    return contacts.map((contact) => ({
      id: contact._id.toString(),
      name: contact.name,
      email: contact.email,
      phone: contact.phone,
      subject: contact.subject,
      message: contact.message,
      status: contact.status,
      createdAt: contact.createdAt,
    }));
  } catch (error) {
    return [];
  }
}

export async function updateContactStatus(id: string, status: "new" | "read" | "replied") {
  try {
    await connectToDatabase();
    await Contact.findByIdAndUpdate(id, { status });
    return { success: true };
  } catch (error: any) {
    return { error: error.message || "Failed to update status" };
  }
}

