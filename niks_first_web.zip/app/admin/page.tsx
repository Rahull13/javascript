/**
 * Admin Dashboard
 * Main dashboard page for admin users
 */

export const runtime = "nodejs";

export default function AdminDashboardPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900 mb-4">Dashboard</h1>
      <p className="text-gray-600">
        Welcome to the admin dashboard. Use the sidebar to navigate to different sections.
      </p>
    </div>
  );
}

