import { z } from "zod";

// SEO sub-schema (shared structure)
export const seoSchema = z.object({
  title: z
    .string()
    .max(60, "SEO title must be less than 60 characters")
    .optional()
    .or(z.literal("")),
  description: z
    .string()
    .max(160, "SEO description must be less than 160 characters")
    .optional()
    .or(z.literal("")),
  keywords: z.array(z.string()).default([]),
  ogImage: z.string().url().optional().or(z.literal("")),
});

export const serviceSchema = z.object({
  title: z
    .string()
    .min(1, "Title is required")
    .max(200, "Title must be less than 200 characters"),
  slug: z
    .string()
    .min(1, "Slug is required")
    .max(200, "Slug must be less than 200 characters")
    .regex(
      /^[a-z0-9]+(?:-[a-z0-9]+)*$/,
      "Slug must be lowercase alphanumeric with hyphens",
    ),
  category: z
    .enum(["Digital Marketing", "Digital Transformation"])
    .default("Digital Marketing"),
  summary: z
    .string()
    .min(1, "Summary is required")
    .max(500, "Summary must be less than 500 characters"),
  content: z.string().min(1, "Content is required"),
  seo: seoSchema.default({ keywords: [] }),
  // Legacy flat SEO fields (backward compatibility with existing admin form)
  metaTitle: z
    .string()
    .max(60, "Meta title must be less than 60 characters")
    .optional(),
  metaDescription: z
    .string()
    .max(160, "Meta description must be less than 160 characters")
    .optional(),
  keywords: z.array(z.string()).default([]),
  status: z.enum(["draft", "published"]).default("draft"),
  imageUrl: z.string().url().optional().or(z.literal("")),
  imagePublicId: z.string().optional().or(z.literal("")),
  imageAlt: z
    .string()
    .max(200, "Alt text must be less than 200 characters")
    .optional()
    .or(z.literal("")),
  ogImage: z.string().url().optional().or(z.literal("")),
});

export type ServiceFormData = z.infer<typeof serviceSchema>;
