"use server";

import { revalidatePath } from "next/cache";
import { connectToDatabase } from "@/lib/mongodb";
import { uploadImage, deleteImage } from "@/lib/cloudinary";
import Service from "@/models/Service";
import { serviceSchema, type ServiceFormData } from "./schema";

export async function createService(data: ServiceFormData, imageFile?: File) {
  try {
    const validated = serviceSchema.parse(data);
    await connectToDatabase();

    const existingService = await Service.findOne({ slug: validated.slug });
    if (existingService) {
      return { error: "A service with this slug already exists" };
    }

    // Handle image upload if provided
    let imageUrl: string | undefined;
    let imagePublicId: string | undefined;

    if (imageFile && imageFile.size > 0) {
      try {
        const uploadResult = await uploadImage(imageFile, "services");
        imageUrl = uploadResult.secure_url;
        imagePublicId = uploadResult.public_id;
      } catch (uploadError: any) {
        return { error: `Image upload failed: ${uploadError.message}` };
      }
    } else if (validated.imageUrl) {
      imageUrl = validated.imageUrl || undefined;
      imagePublicId = validated.imagePublicId || undefined;
    }

    // Prepare SEO image metadata
    const imageAlt = validated.imageAlt || undefined;
    const ogImage = validated.ogImage || imageUrl || undefined;

    const service = await Service.create({
      ...validated,
      imageUrl,
      imagePublicId,
      imageAlt,
      ogImage,
    });
    revalidatePath("/admin/services");
    revalidatePath("/services");
    return { success: true, id: service._id.toString() };
  } catch (error: any) {
    return { error: error.message || "Failed to create service" };
  }
}

export async function updateService(
  slug: string,
  data: ServiceFormData,
  imageFile?: File,
) {
  try {
    const validated = serviceSchema.parse(data);
    await connectToDatabase();

    const service = await Service.findOne({ slug });
    if (!service) {
      return { error: "Service not found" };
    }

    const existingService = await Service.findOne({
      slug: validated.slug,
      _id: { $ne: service._id },
    });
    if (existingService) {
      return { error: "A service with this slug already exists" };
    }

    // Handle image upload if new image provided
    let imageUrl: string | undefined = service.imageUrl;
    let imagePublicId: string | undefined = service.imagePublicId;
    const oldImagePublicId = service.imagePublicId;

    if (imageFile && imageFile.size > 0) {
      try {
        const uploadResult = await uploadImage(imageFile, "services");
        imageUrl = uploadResult.secure_url;
        imagePublicId = uploadResult.public_id;

        if (oldImagePublicId) {
          try {
            await deleteImage(oldImagePublicId);
          } catch (deleteError: any) {
            console.error(
              `Failed to delete old Cloudinary image ${oldImagePublicId}:`,
              deleteError.message,
            );
          }
        }
      } catch (uploadError: any) {
        return { error: `Image upload failed: ${uploadError.message}` };
      }
    } else if (validated.imageUrl === "" && oldImagePublicId) {
      try {
        await deleteImage(oldImagePublicId);
      } catch (deleteError: any) {
        console.error(
          `Failed to delete Cloudinary image ${oldImagePublicId}:`,
          deleteError.message,
        );
      }
      imageUrl = undefined;
      imagePublicId = undefined;
    } else if (validated.imageUrl !== undefined) {
      imageUrl = validated.imageUrl || undefined;
      imagePublicId = validated.imagePublicId || undefined;
    }

    const imageAlt = validated.imageAlt || undefined;
    const ogImage = validated.ogImage || imageUrl || undefined;

    await Service.findByIdAndUpdate(service._id, {
      ...validated,
      imageUrl,
      imagePublicId,
      imageAlt,
      ogImage,
    });
    revalidatePath("/admin/services");
    revalidatePath(`/admin/services/${validated.slug}`);
    revalidatePath("/services");
    revalidatePath(`/services/${slug}`);
    if (slug !== validated.slug) {
      revalidatePath(`/services/${validated.slug}`);
    }
    return { success: true };
  } catch (error: any) {
    return { error: error.message || "Failed to update service" };
  }
}

export async function deleteService(slug: string) {
  try {
    await connectToDatabase();
    const service = await Service.findOne({ slug });
    if (!service) {
      return { error: "Service not found" };
    }

    if (service.imagePublicId) {
      try {
        await deleteImage(service.imagePublicId);
      } catch (imageError: any) {
        console.error(
          `Failed to delete Cloudinary image ${service.imagePublicId}:`,
          imageError.message,
        );
      }
    }

    await Service.findByIdAndDelete(service._id);
    revalidatePath("/admin/services");
    revalidatePath("/services");
    revalidatePath(`/services/${slug}`);
    return { success: true };
  } catch (error: any) {
    return { error: error.message || "Failed to delete service" };
  }
}

export async function toggleServiceStatus(slug: string) {
  try {
    await connectToDatabase();
    const service = await Service.findOne({ slug });
    if (!service) {
      return { error: "Service not found" };
    }

    service.status = service.status === "draft" ? "published" : "draft";
    await service.save();
    revalidatePath("/admin/services");
    revalidatePath("/services");
    revalidatePath(`/services/${slug}`);
    return { success: true, status: service.status };
  } catch (error: any) {
    return { error: error.message || "Failed to toggle service status" };
  }
}

export async function getService(slug: string) {
  try {
    await connectToDatabase();
    const service = await Service.findOne({ slug }).lean();
    if (!service) {
      return null;
    }
    return {
      id: (service._id as any).toString(),
      title: service.title ?? "",
      slug: service.slug ?? "",
      category: service.category ?? "Digital Marketing",
      summary: service.summary ?? "",
      content: service.content ?? "",
      seo: service.seo
        ? {
            title: service.seo.title ?? "",
            description: service.seo.description ?? "",
            keywords: service.seo.keywords ? [...service.seo.keywords] : [],
            ogImage: service.seo.ogImage ?? "",
          }
        : { title: "", description: "", keywords: [] as string[], ogImage: "" },
      metaTitle: service.metaTitle ?? "",
      metaDescription: service.metaDescription ?? "",
      keywords: service.keywords ? [...service.keywords] : [],
      status: (service.status ?? "draft") as "draft" | "published",
      imageUrl: service.imageUrl ?? "",
      imagePublicId: service.imagePublicId ?? "",
      imageAlt: service.imageAlt ?? "",
      ogImage: service.ogImage ?? "",
    };
  } catch (error) {
    return null;
  }
}

export async function getServices() {
  try {
    await connectToDatabase();
    const services = await Service.find().sort({ updatedAt: -1 }).lean();
    return services.map((service) => ({
      id: (service._id as any).toString(),
      title: service.title ?? "",
      slug: service.slug ?? "",
      category: service.category ?? "Digital Marketing",
      summary: service.summary ?? "",
      status: (service.status ?? "draft") as "draft" | "published",
      updatedAt: service.updatedAt ? new Date(service.updatedAt).toISOString() : new Date().toISOString(),
    }));
  } catch (error) {
    return [];
  }
}
