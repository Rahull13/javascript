import { ServiceForm } from "../ServiceForm";

export const runtime = "nodejs";

export default function NewServicePage() {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Create New Service</h1>
        <p className="mt-1 text-sm text-gray-600">Add a new service to your website</p>
      </div>
      <ServiceForm />
    </div>
  );
}

