import { redirect } from "next/navigation";
import { getService } from "../actions";
import { ServiceForm } from "../ServiceForm";

export const runtime = "nodejs";

export default async function EditServicePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const service = await getService(slug);

  if (!service) {
    redirect("/admin/services");
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Edit Service</h1>
        <p className="mt-1 text-sm text-gray-600">Update service content and settings</p>
      </div>
      <ServiceForm service={service} />
    </div>
  );
}

