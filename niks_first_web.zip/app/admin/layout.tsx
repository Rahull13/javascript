import { auth } from "@/app/api/auth/[...nextauth]/route";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { Sidebar } from "./components/Sidebar";
import { HeaderClient } from "./components/HeaderClient";

export const runtime = "nodejs";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Get the current pathname from headers (set by middleware)
  const headersList = await headers();
  const pathname = headersList.get("x-pathname") || "";
  
  // Skip auth check for login page - it has its own layout
  if (pathname === "/admin/login") {
    return <>{children}</>;
  }

  // For all other admin pages, check authentication
  const session = await auth();

  console.log("[AdminLayout] Session check:", {
    hasSession: !!session,
    user: session?.user,
    role: session?.user?.role,
    pathname,
  });

  if (!session) {
    console.log("[AdminLayout] No session, redirecting to login");
    redirect("/admin/login");
  }

  if (session.user.role !== "admin") {
    console.log("[AdminLayout] User is not admin, redirecting to login");
    redirect("/admin/login");
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />
      <div className="flex flex-1 flex-col overflow-hidden">
        <HeaderClient email={session.user.email} />
        <main className="flex-1 overflow-y-auto p-6">{children}</main>
      </div>
    </div>
  );
}
