"use client";

import { useEffect, useState } from "react";
import { DndContext, closestCenter, PointerSensor, useSensor, useSensors } from "@dnd-kit/core";
import {
  SortableContext,
  arrayMove,
  verticalListSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { GripVertical, Plus, Trash2, Edit2 } from "lucide-react";

type SectionType =
  | "hero"
  | "services"
  | "testimonials"
  | "portfolio"
  | "cta"
  | "blog"
  | "counter"
  | "team"
  | "faq"
  | "contact";

export interface PageBuilderSection {
  id: string;
  type: SectionType | string;
  order: number;
  enabled: boolean;
  data: Record<string, any>;
}

interface PageBuilderClientProps {
  page: string;
  initialSections: PageBuilderSection[];
}

const SECTION_TYPES: { value: SectionType; label: string }[] = [
  { value: "hero", label: "Hero" },
  { value: "services", label: "Services" },
  { value: "testimonials", label: "Testimonials" },
  { value: "portfolio", label: "Portfolio" },
  { value: "cta", label: "Call to Action" },
  { value: "blog", label: "Blog" },
  { value: "counter", label: "Counter" },
  { value: "team", label: "Team" },
  { value: "faq", label: "FAQ" },
  { value: "contact", label: "Contact" },
];

export function PageBuilderClient({ page, initialSections }: PageBuilderClientProps) {
  const [sections, setSections] = useState<PageBuilderSection[]>(() =>
    [...initialSections].sort((a, b) => a.order - b.order),
  );
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 5,
      },
    }),
  );

  // Refresh from API on mount to ensure latest
  useEffect(() => {
    const fetchConfig = async () => {
      setIsLoading(true);
      try {
        const res = await fetch(`/api/page-builder/${page}`, { cache: "no-store" });
        if (!res.ok) throw new Error("Failed to load page builder configuration");
        const json = await res.json();
        setSections(
          (json.sections || []).sort((a: PageBuilderSection, b: PageBuilderSection) => a.order - b.order),
        );
      } catch (e: any) {
        console.error(e);
        setError(e.message ?? "Failed to load page builder configuration");
      } finally {
        setIsLoading(false);
      }
    };
    fetchConfig();
  }, [page]);

  const saveSections = async (next: PageBuilderSection[]) => {
    setIsSaving(true);
    setError(null);
    const normalized = next
      .slice()
      .sort((a, b) => a.order - b.order)
      .map((s, index) => ({ ...s, order: index + 1 }));

    try {
      const res = await fetch(`/api/page-builder/${page}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ sections: normalized }),
      });
      if (!res.ok) {
        const json = await res.json().catch(() => ({}));
        throw new Error(json.error || "Failed to save configuration");
      }
      const json = await res.json();
      setSections(
        (json.sections || []).sort(
          (a: PageBuilderSection, b: PageBuilderSection) => a.order - b.order,
        ),
      );
    } catch (e: any) {
      console.error(e);
      setError(e.message ?? "Failed to save configuration");
    } finally {
      setIsSaving(false);
    }
  };

  const handleToggleEnabled = (id: string) => {
    const next = sections.map((s) =>
      s.id === id ? { ...s, enabled: !s.enabled } : s,
    );
    setSections(next);
    void saveSections(next);
  };

  const handleDelete = (id: string) => {
    const next = sections.filter((s) => s.id !== id);
    setSections(next);
    void saveSections(next);
  };

  const handleAddSection = (type: SectionType) => {
    const newId = `${type}-${Date.now().toString(36)}`;
    const next: PageBuilderSection[] = [
      ...sections,
      {
        id: newId,
        type,
        enabled: true,
        data: {},
        order: sections.length + 1,
      },
    ];
    setSections(next);
    setShowAddModal(false);
    void saveSections(next);
  };

  const handleDragEnd = async (event: any) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    const oldIndex = sections.findIndex((s) => s.id === active.id);
    const newIndex = sections.findIndex((s) => s.id === over.id);
    if (oldIndex === -1 || newIndex === -1) return;

    const moved = arrayMove(sections, oldIndex, newIndex).map((s, idx) => ({
      ...s,
      order: idx + 1,
    }));

    setSections(moved);

    // Persist new order via dedicated reorder endpoint
    try {
      await fetch("/api/page-builder/reorder", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          page,
          order: moved.map((s) => s.id),
        }),
      });
    } catch (e) {
      console.error(e);
      // Fallback: save full sections if reorder endpoint fails
      void saveSections(moved);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            Page Builder — <span className="uppercase">{page}</span>
          </h1>
          <p className="mt-1 text-sm text-gray-600">
            Configure the section order and visibility for this page.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 transition-colors"
        >
          <Plus className="h-4 w-4" />
          Add Section
        </button>
      </div>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
          {error}
        </div>
      )}

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={handleDragEnd}
      >
        <div className="rounded-lg border border-gray-200 bg-white">
          <div className="border-b border-gray-200 px-4 py-3 flex items-center justify-between">
            <p className="text-sm text-gray-600">
              {isLoading ? "Loading sections…" : `${sections.length} section(s)`}
            </p>
            {isSaving && (
              <p className="text-xs text-gray-500">Saving changes…</p>
            )}
          </div>

          {sections.length === 0 ? (
            <div className="px-6 py-10 text-center text-sm text-gray-500">
              No sections configured yet. Click{" "}
              <span className="font-medium text-gray-800">Add Section</span> to
              start building this page.
            </div>
          ) : (
            <SortableContext
              items={sections.map((s) => s.id)}
              strategy={verticalListSortingStrategy}
            >
              <ul className="divide-y divide-gray-200">
                {sections
                  .slice()
                  .sort((a, b) => a.order - b.order)
                  .map((section, index) => (
                    <SortableSectionItem
                      key={section.id}
                      section={section}
                      index={index}
                      onToggle={handleToggleEnabled}
                      onDelete={handleDelete}
                    />
                  ))}
              </ul>
            </SortableContext>
          )}
        </div>
      </DndContext>

      {/* Add Section Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="w-full max-w-md rounded-lg bg-white shadow-lg">
            <div className="border-b border-gray-200 px-4 py-3 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-gray-900">
                Add Section
              </h2>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                ×
              </button>
            </div>
            <div className="p-4 space-y-3">
              <p className="text-xs text-gray-600 mb-2">
                Choose the type of section you want to add to this page.
              </p>
              <div className="grid grid-cols-2 gap-2">
                {SECTION_TYPES.map((type) => (
                  <button
                    key={type.value}
                    type="button"
                    onClick={() => handleAddSection(type.value)}
                    className="rounded-md border border-gray-200 px-3 py-2 text-sm text-left hover:bg-blue-50 hover:border-blue-300"
                  >
                    {type.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
interface SortableSectionItemProps {
  section: PageBuilderSection;
  index: number;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

function SortableSectionItem({
  section,
  index,
  onToggle,
  onDelete,
}: SortableSectionItemProps) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({
    id: section.id,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const label =
    SECTION_TYPES.find((t) => t.value === section.type)?.label ?? section.type;

  return (
    <li
      ref={setNodeRef}
      style={style}
      className="flex items-center justify-between px-4 py-3 gap-4 cursor-move"
    >
      <div className="flex items-center gap-3">
        <button
          type="button"
          className="text-gray-400 cursor-grab active:cursor-grabbing"
          {...attributes}
          {...listeners}
        >
          <GripVertical className="h-4 w-4" />
        </button>
        <div>
          <p className="text-sm font-medium text-gray-900">{label}</p>
          <p className="text-xs text-gray-500">
            ID: {section.id} · Position {index + 1}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <label className="flex items-center gap-2 text-xs text-gray-600">
          <span>Enabled</span>
          <input
            type="checkbox"
            checked={section.enabled}
            onChange={() => onToggle(section.id)}
            className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
          />
        </label>
        <button
          type="button"
          className="text-gray-500 hover:text-gray-900"
          title="Edit section data (coming soon)"
        >
          <Edit2 className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={() => onDelete(section.id)}
          className="text-red-500 hover:text-red-700"
          title="Delete section"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>
    </li>
  );
}
