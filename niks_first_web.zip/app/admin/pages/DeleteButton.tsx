"use client";

import { Trash2 } from "lucide-react";
import { deletePage } from "./actions";
import { useRouter } from "next/navigation";

interface DeleteButtonProps {
  slug: string;
}

export function DeleteButton({ slug }: DeleteButtonProps) {
  const router = useRouter();

  const handleDelete = async () => {
    if (!confirm("Are you sure you want to delete this page?")) {
      return;
    }

    const result = await deletePage(slug);
    if (result.success) {
      router.refresh();
    } else {
      alert(result.error || "Failed to delete page");
    }
  };

  return (
    <button
      type="button"
      onClick={handleDelete}
      className="text-red-600 hover:text-red-900 transition-colors"
    >
      <Trash2 className="h-4 w-4" />
    </button>
  );
}

