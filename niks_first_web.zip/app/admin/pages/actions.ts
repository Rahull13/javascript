"use server";

import { revalidatePath } from "next/cache";
import { connectToDatabase } from "@/lib/mongodb";
import Page from "@/models/Page";
import { pageSchema, type PageFormData } from "./schema";

/* ─── Seed: ensure Home and About pages exist ─── */
export async function ensureDefaultPages() {
  try {
    await connectToDatabase();

    const defaults = [
      { title: "Home", slug: "home", status: "published" as const },
      { title: "About", slug: "about", status: "published" as const },
    ];

    for (const def of defaults) {
      const exists = await Page.findOne({ slug: def.slug }).lean();
      if (!exists) {
        await Page.create({
          title: def.title,
          slug: def.slug,
          content: "",
          sections: {},
          seo: {},
          status: def.status,
        });
      }
    }
  } catch (error) {
    console.error("Failed to seed default pages:", error);
  }
}

export async function createPage(data: PageFormData) {
  try {
    const validated = pageSchema.parse(data);
    await connectToDatabase();

    const existingPage = await Page.findOne({ slug: validated.slug });
    if (existingPage) {
      return { error: "A page with this slug already exists" };
    }

    // Parse sections JSON string
    let sections = {};
    if (validated.sectionsJson) {
      try {
        sections = JSON.parse(validated.sectionsJson);
      } catch {
        return { error: "Invalid JSON in Sections field" };
      }
    }

    const page = await Page.create({
      ...validated,
      sections,
    });
    revalidatePath("/admin/pages");
    revalidateFrontend(validated.slug);
    return { success: true, id: page._id.toString() };
  } catch (error: any) {
    return { error: error.message || "Failed to create page" };
  }
}

export async function updatePage(slug: string, data: PageFormData) {
  try {
    const validated = pageSchema.parse(data);
    await connectToDatabase();

    const page = await Page.findOne({ slug });
    if (!page) {
      return { error: "Page not found" };
    }

    const existingPage = await Page.findOne({
      slug: validated.slug,
      _id: { $ne: page._id },
    });
    if (existingPage) {
      return { error: "A page with this slug already exists" };
    }

    // Parse sections JSON string
    let sections = page.sections || {};
    if (validated.sectionsJson !== undefined) {
      if (validated.sectionsJson.trim() === "") {
        sections = {};
      } else {
        try {
          sections = JSON.parse(validated.sectionsJson);
        } catch {
          return { error: "Invalid JSON in Sections field" };
        }
      }
    }

    await Page.findByIdAndUpdate(page._id, {
      ...validated,
      sections,
    });
    revalidatePath("/admin/pages");
    revalidatePath(`/admin/pages/${validated.slug}`);
    revalidateFrontend(slug);
    if (slug !== validated.slug) {
      revalidateFrontend(validated.slug);
    }
    return { success: true };
  } catch (error: any) {
    return { error: error.message || "Failed to update page" };
  }
}

export async function deletePage(slug: string) {
  try {
    await connectToDatabase();
    const page = await Page.findOne({ slug });
    if (!page) {
      return { error: "Page not found" };
    }
    await Page.findByIdAndDelete(page._id);
    revalidatePath("/admin/pages");
    revalidateFrontend(slug);
    return { success: true };
  } catch (error: any) {
    return { error: error.message || "Failed to delete page" };
  }
}

export async function togglePageStatus(slug: string) {
  try {
    await connectToDatabase();
    const page = await Page.findOne({ slug });
    if (!page) {
      return { error: "Page not found" };
    }

    page.status = page.status === "draft" ? "published" : "draft";
    await page.save();
    revalidatePath("/admin/pages");
    revalidateFrontend(slug);
    return { success: true, status: page.status };
  } catch (error: any) {
    return { error: error.message || "Failed to toggle page status" };
  }
}

export async function getPage(slug: string) {
  try {
    await connectToDatabase();
    const page = await Page.findOne({ slug }).lean();
    if (!page) {
      return null;
    }

    // Serialize sections back to JSON string for the form
    let sectionsJson = "";
    if (page.sections && Object.keys(page.sections).length > 0) {
      try {
        sectionsJson = JSON.stringify(page.sections, null, 2);
      } catch {
        sectionsJson = "{}";
      }
    }

    return {
      id: (page._id as any).toString(),
      title: page.title ?? "",
      slug: page.slug ?? "",
      content: page.content ?? "",
      sectionsJson,
      seo: page.seo
        ? {
            title: page.seo.title ?? "",
            description: page.seo.description ?? "",
            keywords: page.seo.keywords ? [...page.seo.keywords] : [],
            ogImage: page.seo.ogImage ?? "",
          }
        : { title: "", description: "", keywords: [] as string[], ogImage: "" },
      metaTitle: page.metaTitle ?? "",
      metaDescription: page.metaDescription ?? "",
      keywords: page.keywords ? [...page.keywords] : [],
      status: (page.status ?? "draft") as "draft" | "published",
    };
  } catch (error) {
    return null;
  }
}

export async function getPages() {
  try {
    await connectToDatabase();
    // Seed defaults on every list call (idempotent)
    await ensureDefaultPages();
    const pages = await Page.find().sort({ updatedAt: -1 }).lean();
    return pages.map((page) => ({
      id: (page._id as any).toString(),
      title: page.title ?? "",
      slug: page.slug ?? "",
      status: (page.status ?? "draft") as "draft" | "published",
      updatedAt: page.updatedAt
        ? new Date(page.updatedAt).toISOString()
        : new Date().toISOString(),
    }));
  } catch (error) {
    return [];
  }
}

/* ─── Helper: revalidate frontend paths based on slug ─── */
function revalidateFrontend(slug: string) {
  if (slug === "home") {
    revalidatePath("/");
  } else if (slug === "about") {
    revalidatePath("/about");
  } else {
    revalidatePath(`/${slug}`);
  }
}
