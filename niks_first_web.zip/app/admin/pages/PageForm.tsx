"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createPage, updatePage } from "./actions";
import { pageSchema, type PageFormData } from "./schema";

interface PageFormProps {
  page?: {
    id: string;
    title: string;
    slug: string;
    content: string;
    sectionsJson: string;
    seo: {
      title?: string;
      description?: string;
      keywords?: string[];
      ogImage?: string;
    };
    metaTitle?: string;
    metaDescription?: string;
    keywords: string[];
    status: "draft" | "published";
  };
}

export function PageForm({ page }: PageFormProps) {
  const router = useRouter();
  const [isPending, setIsPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [keywordInput, setKeywordInput] = useState("");
  const [jsonError, setJsonError] = useState<string | null>(null);

  const [formData, setFormData] = useState<PageFormData>({
    title: page?.title || "",
    slug: page?.slug || "",
    content: page?.content || "",
    sectionsJson: page?.sectionsJson || "",
    seo: {
      title: page?.seo?.title || "",
      description: page?.seo?.description || "",
      keywords: page?.seo?.keywords || [],
      ogImage: page?.seo?.ogImage || "",
    },
    metaTitle: page?.metaTitle || "",
    metaDescription: page?.metaDescription || "",
    keywords: page?.keywords || [],
    status: page?.status || "draft",
  });

  const handleSectionsChange = (value: string) => {
    setFormData({ ...formData, sectionsJson: value });
    if (value.trim() === "") {
      setJsonError(null);
      return;
    }
    try {
      JSON.parse(value);
      setJsonError(null);
    } catch {
      setJsonError("Invalid JSON syntax");
    }
  };

  const formatJson = () => {
    if (!formData.sectionsJson.trim()) return;
    try {
      const parsed = JSON.parse(formData.sectionsJson);
      setFormData({
        ...formData,
        sectionsJson: JSON.stringify(parsed, null, 2),
      });
      setJsonError(null);
    } catch {
      setJsonError("Cannot format — invalid JSON");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsPending(true);

    if (jsonError) {
      setError("Please fix the JSON syntax error in Sections before saving.");
      setIsPending(false);
      return;
    }

    try {
      const validation = pageSchema.safeParse(formData);
      if (!validation.success) {
        setError(validation.error.issues[0].message);
        setIsPending(false);
        return;
      }

      const result = page
        ? await updatePage(page.slug, validation.data)
        : await createPage(validation.data);

      if (result.error) {
        setError(result.error);
        setIsPending(false);
      } else {
        router.push("/admin/pages");
        router.refresh();
      }
    } catch (err: any) {
      setError(err.message || "An error occurred");
      setIsPending(false);
    }
  };

  const addKeyword = () => {
    if (
      keywordInput.trim() &&
      !formData.keywords.includes(keywordInput.trim())
    ) {
      setFormData({
        ...formData,
        keywords: [...formData.keywords, keywordInput.trim()],
      });
      setKeywordInput("");
    }
  };

  const removeKeyword = (keyword: string) => {
    setFormData({
      ...formData,
      keywords: formData.keywords.filter((k) => k !== keyword),
    });
  };

  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");
  };

  const isProtectedSlug = page?.slug === "home" || page?.slug === "about";

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <div className="rounded-lg bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-800">
          {error}
        </div>
      )}

      {/* ─── Basic Info ─── */}
      <div className="rounded-lg border border-gray-200 bg-white p-6 space-y-6">
        <h3 className="text-lg font-semibold text-gray-900 border-b pb-3">
          Page Settings
        </h3>

        <div>
          <label
            htmlFor="title"
            className="block text-sm font-medium text-gray-700 mb-2"
          >
            Title *
          </label>
          <input
            type="text"
            id="title"
            value={formData.title}
            onChange={(e) => {
              const title = e.target.value;
              setFormData({
                ...formData,
                title,
                slug: formData.slug || generateSlug(title),
              });
            }}
            className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            required
          />
        </div>

        <div>
          <label
            htmlFor="slug"
            className="block text-sm font-medium text-gray-700 mb-2"
          >
            Slug *
          </label>
          <input
            type="text"
            id="slug"
            value={formData.slug}
            onChange={(e) =>
              setFormData({
                ...formData,
                slug: e.target.value
                  .toLowerCase()
                  .replace(/[^a-z0-9-]/g, ""),
              })
            }
            disabled={isProtectedSlug}
            className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 disabled:bg-gray-100 disabled:cursor-not-allowed"
            required
          />
          {isProtectedSlug && (
            <p className="mt-1 text-xs text-amber-600">
              This is a system page — slug cannot be changed.
            </p>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label
              htmlFor="status"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              Status
            </label>
            <select
              id="status"
              value={formData.status}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  status: e.target.value as "draft" | "published",
                })
              }
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="draft">Draft</option>
              <option value="published">Published</option>
            </select>
          </div>
        </div>
      </div>

      {/* ─── Sections JSON ─── */}
      <div className="rounded-lg border border-gray-200 bg-white p-6 space-y-4">
        <div className="flex items-center justify-between border-b pb-3">
          <h3 className="text-lg font-semibold text-gray-900">
            Page Sections (JSON)
          </h3>
          <button
            type="button"
            onClick={formatJson}
            className="rounded bg-gray-100 px-3 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-200 transition-colors"
          >
            Format JSON
          </button>
        </div>

        <p className="text-xs text-gray-500">
          Edit the page sections as JSON. Each key represents a section (e.g.
          &quot;hero&quot;, &quot;counter&quot;, &quot;cta&quot;, &quot;team&quot;).
          Leave empty to use default content.
        </p>

        <textarea
          id="sectionsJson"
          value={formData.sectionsJson}
          onChange={(e) => handleSectionsChange(e.target.value)}
          rows={16}
          spellCheck={false}
          className={`w-full rounded-lg border px-3 py-2 text-sm font-mono focus:outline-none focus:ring-1 ${
            jsonError
              ? "border-red-400 focus:border-red-500 focus:ring-red-500"
              : "border-gray-300 focus:border-blue-500 focus:ring-blue-500"
          }`}
          placeholder='{\n  "hero": { "slides": [...] },\n  "counter": { "stats": [...] }\n}'
        />
        {jsonError && (
          <p className="text-xs text-red-600">{jsonError}</p>
        )}
      </div>

      {/* ─── SEO ─── */}
      <div className="rounded-lg border border-gray-200 bg-white p-6 space-y-6">
        <h3 className="text-lg font-semibold text-gray-900 border-b pb-3">
          SEO Settings
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label
              htmlFor="metaTitle"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              Meta Title
            </label>
            <input
              type="text"
              id="metaTitle"
              value={formData.metaTitle}
              onChange={(e) =>
                setFormData({ ...formData, metaTitle: e.target.value })
              }
              maxLength={60}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
            <p className="mt-1 text-xs text-gray-500">
              {formData.metaTitle?.length || 0}/60
            </p>
          </div>

          <div>
            <label
              htmlFor="seoOgImage"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              Open Graph Image URL
            </label>
            <input
              type="url"
              id="seoOgImage"
              value={formData.seo.ogImage}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  seo: { ...formData.seo, ogImage: e.target.value },
                })
              }
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>

        <div>
          <label
            htmlFor="metaDescription"
            className="block text-sm font-medium text-gray-700 mb-2"
          >
            Meta Description
          </label>
          <textarea
            id="metaDescription"
            value={formData.metaDescription}
            onChange={(e) =>
              setFormData({ ...formData, metaDescription: e.target.value })
            }
            rows={3}
            maxLength={160}
            className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
          <p className="mt-1 text-xs text-gray-500">
            {formData.metaDescription?.length || 0}/160
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Keywords
          </label>
          <div className="flex gap-2 mb-2">
            <input
              type="text"
              value={keywordInput}
              onChange={(e) => setKeywordInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  addKeyword();
                }
              }}
              placeholder="Add keyword and press Enter"
              className="flex-1 rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
            <button
              type="button"
              onClick={addKeyword}
              className="rounded-lg bg-gray-100 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-200 transition-colors"
            >
              Add
            </button>
          </div>
          {formData.keywords.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {formData.keywords.map((keyword) => (
                <span
                  key={keyword}
                  className="inline-flex items-center gap-1 rounded-full bg-blue-100 px-3 py-1 text-sm text-blue-800"
                >
                  {keyword}
                  <button
                    type="button"
                    onClick={() => removeKeyword(keyword)}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ─── Actions ─── */}
      <div className="flex items-center justify-end gap-4">
        <Link
          href="/admin/pages"
          className="rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
        >
          Cancel
        </Link>
        <button
          type="submit"
          disabled={isPending || !!jsonError}
          className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {isPending ? "Saving..." : page ? "Update Page" : "Create Page"}
        </button>
      </div>
    </form>
  );
}
