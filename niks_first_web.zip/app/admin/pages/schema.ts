import { z } from "zod";

// SEO sub-schema (shared structure)
export const seoSchema = z.object({
  title: z
    .string()
    .max(60, "SEO title must be less than 60 characters")
    .optional()
    .or(z.literal("")),
  description: z
    .string()
    .max(160, "SEO description must be less than 160 characters")
    .optional()
    .or(z.literal("")),
  keywords: z.array(z.string()).default([]),
  ogImage: z.string().url().optional().or(z.literal("")),
});

export const pageSchema = z.object({
  title: z
    .string()
    .min(1, "Title is required")
    .max(200, "Title must be less than 200 characters"),
  slug: z
    .string()
    .min(1, "Slug is required")
    .max(200, "Slug must be less than 200 characters")
    .regex(
      /^[a-z0-9]+(?:-[a-z0-9]+)*$/,
      "Slug must be lowercase alphanumeric with hyphens",
    ),
  content: z.string().default(""),
  // Sections as a JSON string (parsed server-side)
  sectionsJson: z.string().default(""),
  seo: seoSchema.default({ keywords: [] }),
  // Legacy flat SEO fields
  metaTitle: z
    .string()
    .max(60, "Meta title must be less than 60 characters")
    .optional(),
  metaDescription: z
    .string()
    .max(160, "Meta description must be less than 160 characters")
    .optional(),
  keywords: z.array(z.string()).default([]),
  status: z.enum(["draft", "published"]).default("draft"),
});

export type PageFormData = z.infer<typeof pageSchema>;
