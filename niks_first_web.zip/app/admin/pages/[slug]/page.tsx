import { redirect } from "next/navigation";
import { getPage } from "../actions";
import { PageForm } from "../PageForm";

export const runtime = "nodejs";

export default async function EditPagePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const page = await getPage(slug);

  if (!page) {
    redirect("/admin/pages");
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Edit Page</h1>
        <p className="mt-1 text-sm text-gray-600">Update page content and settings</p>
      </div>
      <PageForm page={page} />
    </div>
  );
}

