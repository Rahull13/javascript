import { redirect } from "next/navigation";
import { getPage } from "@/app/admin/pages/actions";
import { PageBuilderClient } from "@/app/admin/pages/PageBuilderClient";
import { connectToDatabase } from "@/lib/mongodb";
import PageBuilder from "@/models/PageBuilder";

export const runtime = "nodejs";

interface BuilderPageProps {
  params: Promise<{ slug: string }>;
}

export default async function PageBuilderRoute({ params }: BuilderPageProps) {
  const { slug } = await params;

  const page = await getPage(slug);
  if (!page) {
    redirect("/admin/pages");
  }

  await connectToDatabase();
  const config = await PageBuilder.findOne({ page: slug.toLowerCase() })
    .select("sections")
    .lean();

  const initialSections =
    config?.sections?.map((s: any) => ({
      id: s.id,
      type: s.type,
      order: s.order,
      enabled: s.enabled,
      data: s.data || {},
    })) ?? [];

  return (
    <div className="space-y-6">
      <PageBuilderClient page={slug.toLowerCase()} initialSections={initialSections} />
    </div>
  );
}

