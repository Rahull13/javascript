import { PageForm } from "../PageForm";

export const runtime = "nodejs";

export default function NewPagePage() {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Create New Page</h1>
        <p className="mt-1 text-sm text-gray-600">Add a new page to your website</p>
      </div>
      <PageForm />
    </div>
  );
}

