import { BlogForm } from "../BlogForm";

export const runtime = "nodejs";

export default function NewBlogPage() {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Create New Blog Post</h1>
        <p className="mt-1 text-sm text-gray-600">Add a new blog post to your website</p>
      </div>
      <BlogForm />
    </div>
  );
}

