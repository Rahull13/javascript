"use server";

import { revalidatePath } from "next/cache";
import { connectToDatabase } from "@/lib/mongodb";
import { uploadImage, deleteImage } from "@/lib/cloudinary";
import Blog from "@/models/Blog";
import { blogSchema, type BlogFormData } from "./schema";

export async function createBlog(data: BlogFormData, imageFile?: File) {
  try {
    const validated = blogSchema.parse(data);
    await connectToDatabase();

    const existingBlog = await Blog.findOne({ slug: validated.slug });
    if (existingBlog) {
      return { error: "A blog post with this slug already exists" };
    }

    // Handle image upload if provided
    let imageUrl: string | undefined;
    let imagePublicId: string | undefined;

    if (imageFile && imageFile.size > 0) {
      try {
        const uploadResult = await uploadImage(imageFile, "blogs");
        imageUrl = uploadResult.secure_url;
        imagePublicId = uploadResult.public_id;
      } catch (uploadError: any) {
        return { error: `Image upload failed: ${uploadError.message}` };
      }
    } else if (validated.imageUrl) {
      imageUrl = validated.imageUrl || undefined;
      imagePublicId = validated.imagePublicId || undefined;
    }

    // Prepare SEO image metadata
    const imageAlt = validated.imageAlt || undefined;
    const ogImage = validated.ogImage || imageUrl || undefined;

    // Parse publishedAt date
    const publishedAt = validated.publishedAt
      ? new Date(validated.publishedAt)
      : undefined;

    const blog = await Blog.create({
      ...validated,
      imageUrl,
      imagePublicId,
      imageAlt,
      ogImage,
      publishedAt,
    });
    revalidatePath("/admin/blogs");
    revalidatePath("/blog");
    return { success: true, id: blog._id.toString() };
  } catch (error: any) {
    // Handle database case sensitivity error more gracefully
    if (
      error.message &&
      error.message.includes("already exists with different case")
    ) {
      await new Promise((resolve) => setTimeout(resolve, 500));
      try {
        const validated = blogSchema.parse(data);
        const existingBlog = await Blog.findOne({ slug: validated.slug });
        if (existingBlog) {
          return { error: "A blog post with this slug already exists" };
        }

        let imageUrl: string | undefined;
        let imagePublicId: string | undefined;

        if (imageFile && imageFile.size > 0) {
          try {
            const uploadResult = await uploadImage(imageFile, "blogs");
            imageUrl = uploadResult.secure_url;
            imagePublicId = uploadResult.public_id;
          } catch (uploadError: any) {
            return { error: `Image upload failed: ${uploadError.message}` };
          }
        } else if (validated.imageUrl) {
          imageUrl = validated.imageUrl || undefined;
          imagePublicId = validated.imagePublicId || undefined;
        }

        const imageAlt = validated.imageAlt || undefined;
        const ogImage = validated.ogImage || imageUrl || undefined;
        const publishedAt = validated.publishedAt
          ? new Date(validated.publishedAt)
          : undefined;

        const blog = await Blog.create({
          ...validated,
          imageUrl,
          imagePublicId,
          imageAlt,
          ogImage,
          publishedAt,
        });
        revalidatePath("/admin/blogs");
        revalidatePath("/blog");
        return { success: true, id: blog._id.toString() };
      } catch (retryError: any) {
        return {
          error:
            retryError.message ||
            "Failed to create blog post. Please check your database connection.",
        };
      }
    }
    return { error: error.message || "Failed to create blog post" };
  }
}

export async function updateBlog(
  slug: string,
  data: BlogFormData,
  imageFile?: File,
) {
  try {
    const validated = blogSchema.parse(data);
    await connectToDatabase();

    const blog = await Blog.findOne({ slug });
    if (!blog) {
      return { error: "Blog post not found" };
    }

    const existingBlog = await Blog.findOne({
      slug: validated.slug,
      _id: { $ne: blog._id },
    });
    if (existingBlog) {
      return { error: "A blog post with this slug already exists" };
    }

    // Handle image upload if new image provided
    let imageUrl: string | undefined = blog.imageUrl;
    let imagePublicId: string | undefined = blog.imagePublicId;
    const oldImagePublicId = blog.imagePublicId;

    if (imageFile && imageFile.size > 0) {
      try {
        const uploadResult = await uploadImage(imageFile, "blogs");
        imageUrl = uploadResult.secure_url;
        imagePublicId = uploadResult.public_id;

        if (oldImagePublicId) {
          try {
            await deleteImage(oldImagePublicId);
          } catch (deleteError: any) {
            console.error(
              `Failed to delete old Cloudinary image ${oldImagePublicId}:`,
              deleteError.message,
            );
          }
        }
      } catch (uploadError: any) {
        return { error: `Image upload failed: ${uploadError.message}` };
      }
    } else if (validated.imageUrl === "" && oldImagePublicId) {
      try {
        await deleteImage(oldImagePublicId);
      } catch (deleteError: any) {
        console.error(
          `Failed to delete Cloudinary image ${oldImagePublicId}:`,
          deleteError.message,
        );
      }
      imageUrl = undefined;
      imagePublicId = undefined;
    } else if (validated.imageUrl !== undefined) {
      imageUrl = validated.imageUrl || undefined;
      imagePublicId = validated.imagePublicId || undefined;
    }

    const imageAlt = validated.imageAlt || undefined;
    const ogImage = validated.ogImage || imageUrl || undefined;
    const publishedAt = validated.publishedAt
      ? new Date(validated.publishedAt)
      : blog.publishedAt;

    await Blog.findByIdAndUpdate(blog._id, {
      ...validated,
      imageUrl,
      imagePublicId,
      imageAlt,
      ogImage,
      publishedAt,
    });
    revalidatePath("/admin/blogs");
    revalidatePath(`/admin/blogs/${validated.slug}`);
    revalidatePath("/blog");
    revalidatePath(`/blog/${slug}`);
    if (slug !== validated.slug) {
      revalidatePath(`/blog/${validated.slug}`);
    }
    return { success: true };
  } catch (error: any) {
    return { error: error.message || "Failed to update blog post" };
  }
}

export async function deleteBlog(slug: string) {
  try {
    await connectToDatabase();
    const blog = await Blog.findOne({ slug });
    if (!blog) {
      return { error: "Blog post not found" };
    }

    if (blog.imagePublicId) {
      try {
        await deleteImage(blog.imagePublicId);
      } catch (imageError: any) {
        console.error(
          `Failed to delete Cloudinary image ${blog.imagePublicId}:`,
          imageError.message,
        );
      }
    }

    await Blog.findByIdAndDelete(blog._id);
    revalidatePath("/admin/blogs");
    revalidatePath("/blog");
    revalidatePath(`/blog/${slug}`);
    return { success: true };
  } catch (error: any) {
    return { error: error.message || "Failed to delete blog post" };
  }
}

export async function toggleBlogStatus(slug: string) {
  try {
    await connectToDatabase();
    const blog = await Blog.findOne({ slug });
    if (!blog) {
      return { error: "Blog post not found" };
    }

    blog.status = blog.status === "draft" ? "published" : "draft";

    // Auto-set publishedAt when publishing for the first time
    if (blog.status === "published" && !blog.publishedAt) {
      blog.publishedAt = new Date();
    }

    await blog.save();
    revalidatePath("/admin/blogs");
    revalidatePath("/blog");
    revalidatePath(`/blog/${slug}`);
    return { success: true, status: blog.status };
  } catch (error: any) {
    return { error: error.message || "Failed to toggle blog post status" };
  }
}

export async function getBlog(slug: string) {
  try {
    await connectToDatabase();
    const blog = await Blog.findOne({ slug }).lean();
    if (!blog) {
      return null;
    }
    return {
      id: (blog._id as any).toString(),
      title: blog.title ?? "",
      slug: blog.slug ?? "",
      excerpt: blog.excerpt ?? "",
      content: blog.content ?? "",
      author: blog.author ?? "",
      publishedAt: blog.publishedAt
        ? new Date(blog.publishedAt).toISOString().split("T")[0]
        : "",
      seo: blog.seo
        ? {
            title: blog.seo.title ?? "",
            description: blog.seo.description ?? "",
            keywords: blog.seo.keywords ? [...blog.seo.keywords] : [],
            ogImage: blog.seo.ogImage ?? "",
          }
        : { title: "", description: "", keywords: [] as string[], ogImage: "" },
      metaTitle: blog.metaTitle ?? "",
      metaDescription: blog.metaDescription ?? "",
      keywords: blog.keywords ? [...blog.keywords] : [],
      status: (blog.status ?? "draft") as "draft" | "published",
      imageUrl: blog.imageUrl ?? "",
      imagePublicId: blog.imagePublicId ?? "",
      imageAlt: blog.imageAlt ?? "",
      ogImage: blog.ogImage ?? "",
    };
  } catch (error) {
    return null;
  }
}

export async function getBlogs() {
  try {
    await connectToDatabase();
    const blogs = await Blog.find().sort({ updatedAt: -1 }).lean();
    return blogs.map((blog) => ({
      id: (blog._id as any).toString(),
      title: blog.title ?? "",
      slug: blog.slug ?? "",
      excerpt: blog.excerpt ?? "",
      author: blog.author ?? "",
      status: (blog.status ?? "draft") as "draft" | "published",
      publishedAt: blog.publishedAt
        ? new Date(blog.publishedAt).toISOString()
        : null,
      updatedAt: blog.updatedAt
        ? new Date(blog.updatedAt).toISOString()
        : new Date().toISOString(),
    }));
  } catch (error) {
    return [];
  }
}
