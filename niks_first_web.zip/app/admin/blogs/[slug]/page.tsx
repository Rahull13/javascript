import { redirect } from "next/navigation";
import { getBlog } from "../actions";
import { BlogForm } from "../BlogForm";

export const runtime = "nodejs";

export default async function EditBlogPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const blog = await getBlog(slug);

  if (!blog) {
    redirect("/admin/blogs");
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Edit Blog Post</h1>
        <p className="mt-1 text-sm text-gray-600">Update blog post content and settings</p>
      </div>
      <BlogForm blog={blog} />
    </div>
  );
}

