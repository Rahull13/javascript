"use server";

import { revalidatePath } from "next/cache";
import { connectToDatabase } from "@/lib/mongodb";
import { uploadImage, deleteImage } from "@/lib/cloudinary";
import Portfolio from "@/models/Portfolio";
import { portfolioSchema, type PortfolioFormData } from "./schema";

export async function createPortfolio(
  data: PortfolioFormData,
  imageFiles?: File[],
) {
  try {
    const validated = portfolioSchema.parse(data);
    await connectToDatabase();

    const existing = await Portfolio.findOne({ slug: validated.slug });
    if (existing) {
      return { error: "A portfolio item with this slug already exists" };
    }

    // Handle image uploads if provided
    const images = [...validated.images];
    if (imageFiles && imageFiles.length > 0) {
      for (const file of imageFiles) {
        if (file.size > 0) {
          try {
            const uploadResult = await uploadImage(file, "portfolio");
            images.push({
              url: uploadResult.secure_url,
              publicId: uploadResult.public_id,
              alt: "",
            });
          } catch (uploadError: any) {
            return { error: `Image upload failed: ${uploadError.message}` };
          }
        }
      }
    }

    const portfolio = await Portfolio.create({
      ...validated,
      images,
    });
    revalidatePath("/admin/portfolio");
    revalidatePath("/portfolio");
    return { success: true, id: portfolio._id.toString() };
  } catch (error: any) {
    return { error: error.message || "Failed to create portfolio item" };
  }
}

export async function updatePortfolio(
  slug: string,
  data: PortfolioFormData,
  imageFiles?: File[],
) {
  try {
    const validated = portfolioSchema.parse(data);
    await connectToDatabase();

    const portfolio = await Portfolio.findOne({ slug });
    if (!portfolio) {
      return { error: "Portfolio item not found" };
    }

    const existingPortfolio = await Portfolio.findOne({
      slug: validated.slug,
      _id: { $ne: portfolio._id },
    });
    if (existingPortfolio) {
      return { error: "A portfolio item with this slug already exists" };
    }

    // Start with images from form data (may have removed some)
    const images = [...validated.images];

    // Handle new image uploads
    if (imageFiles && imageFiles.length > 0) {
      for (const file of imageFiles) {
        if (file.size > 0) {
          try {
            const uploadResult = await uploadImage(file, "portfolio");
            images.push({
              url: uploadResult.secure_url,
              publicId: uploadResult.public_id,
              alt: "",
            });
          } catch (uploadError: any) {
            return { error: `Image upload failed: ${uploadError.message}` };
          }
        }
      }
    }

    // Delete removed images from Cloudinary
    const removedImages = portfolio.images.filter(
      (oldImg: { publicId?: string }) =>
        oldImg.publicId &&
        !images.some(
          (newImg: { publicId?: string }) =>
            newImg.publicId === oldImg.publicId,
        ),
    );
    for (const removed of removedImages) {
      if (removed.publicId) {
        try {
          await deleteImage(removed.publicId);
        } catch (deleteError: any) {
          console.error(
            `Failed to delete Cloudinary image ${removed.publicId}:`,
            deleteError.message,
          );
        }
      }
    }

    await Portfolio.findByIdAndUpdate(portfolio._id, {
      ...validated,
      images,
    });
    revalidatePath("/admin/portfolio");
    revalidatePath(`/admin/portfolio/${validated.slug}`);
    revalidatePath("/portfolio");
    revalidatePath(`/portfolio/${slug}`);
    if (slug !== validated.slug) {
      revalidatePath(`/portfolio/${validated.slug}`);
    }
    return { success: true };
  } catch (error: any) {
    return { error: error.message || "Failed to update portfolio item" };
  }
}

export async function deletePortfolio(slug: string) {
  try {
    await connectToDatabase();
    const portfolio = await Portfolio.findOne({ slug });
    if (!portfolio) {
      return { error: "Portfolio item not found" };
    }

    // Delete all images from Cloudinary
    for (const image of portfolio.images) {
      if (image.publicId) {
        try {
          await deleteImage(image.publicId);
        } catch (imageError: any) {
          console.error(
            `Failed to delete Cloudinary image ${image.publicId}:`,
            imageError.message,
          );
        }
      }
    }

    await Portfolio.findByIdAndDelete(portfolio._id);
    revalidatePath("/admin/portfolio");
    revalidatePath("/portfolio");
    revalidatePath(`/portfolio/${slug}`);
    return { success: true };
  } catch (error: any) {
    return { error: error.message || "Failed to delete portfolio item" };
  }
}

export async function togglePortfolioStatus(slug: string) {
  try {
    await connectToDatabase();
    const portfolio = await Portfolio.findOne({ slug });
    if (!portfolio) {
      return { error: "Portfolio item not found" };
    }

    portfolio.status = portfolio.status === "draft" ? "published" : "draft";
    await portfolio.save();
    revalidatePath("/admin/portfolio");
    revalidatePath("/portfolio");
    revalidatePath(`/portfolio/${slug}`);
    return { success: true, status: portfolio.status };
  } catch (error: any) {
    return { error: error.message || "Failed to toggle portfolio status" };
  }
}

export async function getPortfolio(slug: string) {
  try {
    await connectToDatabase();
    const portfolio = await Portfolio.findOne({ slug }).lean();
    if (!portfolio) {
      return null;
    }
    return {
      id: (portfolio._id as any).toString(),
      title: portfolio.title ?? "",
      slug: portfolio.slug ?? "",
      description: portfolio.description ?? "",
      images: portfolio.images
        ? portfolio.images.map(
            (img: { url: string; publicId?: string; alt?: string }) => ({
              url: img.url ?? "",
              publicId: img.publicId ?? "",
              alt: img.alt ?? "",
            }),
          )
        : [],
      client: portfolio.client ?? "",
      industry: portfolio.industry ?? "",
      seo: portfolio.seo
        ? {
            title: portfolio.seo.title ?? "",
            description: portfolio.seo.description ?? "",
            keywords: portfolio.seo.keywords ? [...portfolio.seo.keywords] : [],
            ogImage: portfolio.seo.ogImage ?? "",
          }
        : { title: "", description: "", keywords: [] as string[], ogImage: "" },
      status: (portfolio.status ?? "draft") as "draft" | "published",
    };
  } catch (error) {
    return null;
  }
}

export async function getPortfolios() {
  try {
    await connectToDatabase();
    const portfolios = await Portfolio.find().sort({ updatedAt: -1 }).lean();
    return portfolios.map((portfolio) => ({
      id: (portfolio._id as any).toString(),
      title: portfolio.title ?? "",
      slug: portfolio.slug ?? "",
      client: portfolio.client ?? "",
      industry: portfolio.industry ?? "",
      status: (portfolio.status ?? "draft") as "draft" | "published",
      imageCount: portfolio.images ? portfolio.images.length : 0,
      updatedAt: portfolio.updatedAt
        ? new Date(portfolio.updatedAt).toISOString()
        : new Date().toISOString(),
    }));
  } catch (error) {
    return [];
  }
}

