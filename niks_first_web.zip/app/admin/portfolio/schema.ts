import { z } from "zod";

// SEO sub-schema (shared structure)
export const seoSchema = z.object({
  title: z
    .string()
    .max(60, "SEO title must be less than 60 characters")
    .optional()
    .or(z.literal("")),
  description: z
    .string()
    .max(160, "SEO description must be less than 160 characters")
    .optional()
    .or(z.literal("")),
  keywords: z.array(z.string()).default([]),
  ogImage: z.string().url().optional().or(z.literal("")),
});

// Portfolio image sub-schema
export const portfolioImageSchema = z.object({
  url: z.string().min(1, "Image URL is required"),
  publicId: z.string().optional().or(z.literal("")),
  alt: z.string().max(200, "Alt text must be less than 200 characters").optional().or(z.literal("")),
});

export const portfolioSchema = z.object({
  title: z
    .string()
    .min(1, "Title is required")
    .max(200, "Title must be less than 200 characters"),
  slug: z
    .string()
    .min(1, "Slug is required")
    .max(200, "Slug must be less than 200 characters")
    .regex(
      /^[a-z0-9]+(?:-[a-z0-9]+)*$/,
      "Slug must be lowercase alphanumeric with hyphens",
    ),
  description: z.string().default(""),
  images: z.array(portfolioImageSchema).default([]),
  client: z
    .string()
    .max(200, "Client name must be less than 200 characters")
    .optional()
    .or(z.literal("")),
  industry: z
    .string()
    .max(200, "Industry must be less than 200 characters")
    .optional()
    .or(z.literal("")),
  seo: seoSchema.default({ keywords: [] }),
  status: z.enum(["draft", "published"]).default("draft"),
});

export type PortfolioFormData = z.infer<typeof portfolioSchema>;

