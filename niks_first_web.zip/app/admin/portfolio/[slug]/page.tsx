import { redirect } from "next/navigation";
import { getPortfolio } from "../actions";
import { PortfolioForm } from "../PortfolioForm";

export const runtime = "nodejs";

export default async function EditPortfolioPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const portfolio = await getPortfolio(slug);

  if (!portfolio) {
    redirect("/admin/portfolio");
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">
          Edit Portfolio Item
        </h1>
        <p className="mt-1 text-sm text-gray-600">
          Update portfolio content and settings
        </p>
      </div>
      <PortfolioForm portfolio={portfolio} />
    </div>
  );
}

