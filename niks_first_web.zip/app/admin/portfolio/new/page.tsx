import { PortfolioForm } from "../PortfolioForm";

export const runtime = "nodejs";

export default function NewPortfolioPage() {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">
          Create New Portfolio Item
        </h1>
        <p className="mt-1 text-sm text-gray-600">
          Add a new project to your portfolio
        </p>
      </div>
      <PortfolioForm />
    </div>
  );
}

