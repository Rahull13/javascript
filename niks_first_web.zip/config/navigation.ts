/**
 * Navigation Configuration
 * Defines the main navigation structure matching the Videograph theme
 */

export interface NavItem {
  title: string;
  href: string;
  children?: NavItem[];
}

export const NAV_ITEMS: NavItem[] = [
  { title: "Home", href: "/" },
  { title: "About", href: "/about" },
  { title: "Portfolio", href: "/portfolio" },
  { title: "Services", href: "/services" },
  {
    title: "Pages",
    href: "#",
    children: [
      { title: "About", href: "/about" },
      { title: "Portfolio", href: "/portfolio" },
      { title: "Blog", href: "/blog" },
      { title: "Blog Details", href: "/blog/sample-post" },
    ],
  },
  { title: "Contact", href: "/contact" },
];

export const SOCIAL_LINKS = [
  { name: "Facebook", icon: "facebook", href: "https://facebook.com" },
  { name: "Twitter", icon: "twitter", href: "https://twitter.com" },
  { name: "Dribbble", icon: "dribbble", href: "https://dribbble.com" },
  { name: "Instagram", icon: "instagram", href: "https://instagram.com" },
  { name: "YouTube", icon: "youtube", href: "https://youtube.com" },
] as const;

