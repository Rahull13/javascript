/**
 * Site Configuration
 * Centralized configuration for site metadata, branding, and constants
 * Adapted from Videograph theme
 */

export const siteConfig = {
  name: "Videograph",
  shortName: "Videograph",
  description:
    "Award-winning, full-service video production company specializing in commercial, broadcast, tourism & action sport video production.",
  url: "https://www.videograph.com",
  ogImage: "/images/hero/hero-1.jpg",
  links: {
    facebook: "https://facebook.com",
    twitter: "https://twitter.com",
    dribbble: "https://dribbble.com",
    instagram: "https://instagram.com",
    youtube: "https://youtube.com",
  },
  contact: {
    phone: "1-677-124-44227",
    phone2: "1-688-356-66889",
    email: "Support@gmail.com",
    address: {
      street: "Los Angeles Gournadi",
      city: "Barisal",
      zip: "1230",
      country: "United States",
    },
  },
} as const;

export type SiteConfig = typeof siteConfig;
