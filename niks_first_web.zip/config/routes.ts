/**
 * Route Configuration
 * Centralized route definitions for type-safe navigation
 */

export const routes = {
  public: {
    home: "/",
    about: "/about",
    services: "/services",
    service: (slug: string) => `/services/${slug}`,
    resources: "/resources",
    resource: (slug: string) => `/resources/${slug}`,
    contact: "/contact",
  },
  admin: {
    dashboard: "/dashboard",
    clients: "/dashboard/clients",
    client: (id: string) => `/dashboard/clients/${id}`,
    projects: "/dashboard/projects",
    project: (id: string) => `/dashboard/projects/${id}`,
    settings: "/dashboard/settings",
  },
  api: {
    auth: {
      login: "/api/auth/login",
      logout: "/api/auth/logout",
      callback: "/api/auth/callback",
    },
    clients: "/api/clients",
    projects: "/api/projects",
  },
} as const;

export type Routes = typeof routes;

